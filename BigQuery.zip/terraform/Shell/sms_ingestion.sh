if [ ! -f /home/listEngage_smsdata/*.csv ]; then
    echo "File not found!"
    exit 0
fi

list_file=$(ls /home/listEngage_smsdata)
echo 'Moving Data to GCS'
gsutil cp /home/listEngage_smsdata/*.csv gs://hmp-emea-reporting-us-sms_data_ingestion
echo 'Archiving data in GCS'
gsutil cp /home/listEngage_smsdata/*.csv gs://hmp-emea-reporting-us-sms_data_ingestion_archive
echo 'Removing Data from Base Location'
rm /home/listEngage_smsdata/*.csv

