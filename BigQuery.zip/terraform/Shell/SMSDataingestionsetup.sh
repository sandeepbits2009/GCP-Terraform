#!/bin/sh
# Automation for Steps 2,3,4 needs to be figured out as they are manual processes for now
# 1. User creation
USERID="listEngage_smsdata"
/bin/egrep  -i "^${USERID}:" /etc/passwd
if [ $? -eq 0 ]; then
   echo "User $USERID exists in /etc/passwd"
else 
   sudo adduser listEngage_smsdata
   echo "listEngage_smsdata:KC*QAtesting1" | sudo chpasswd
   sudo sed -re 's/^(PasswordAuthentication)([[:space:]]+)no/\1\2yes/' -i.`date -I` /etc/ssh/sshd_config
fi
#5.go to home directory and create another directorynamed smsvmdetails. Change permissions to 777.
if [ -d "/home/smsvmdetails" ] 
then
    echo "Directory /home/smsvmdetails exists." 
else
    sudo mkdir /home/smsvmdetails
    sudo chmod 777 /home/smsvmdetails
fi
# 3.Place the bashscript sent to you inside this location. 
cp /tmp/sms_ingestion.sh /home/smsvmdetails
#Place the python and requirments files in the home directory. 
cp -R /tmp/csv_clean /home/smsvmdetails
# 4.Create new cronjobs
crontab -l > mycron
#echo new cron into cron file
echo "0 12 * * 2  /bin/bash /home/smsvmdetails/bash sms_ingestion.sh" >> mycron
#install new cron file
crontab mycron

