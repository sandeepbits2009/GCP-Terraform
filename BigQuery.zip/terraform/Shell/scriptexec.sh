#! /bin/sh

cd /tmp/csv_clean
chmod +x *.py 

cd /tmp/

for i in *
do
  echo "Changing $i file permissions..."
  chmod +x *.sh
done
rm -rf terraform*.sh
echo "Executing the Shell Scripts"
sh ./SMSDataingestionsetup.sh
