WITH step1 AS ( 
#Generate dates between Campaign_start_date and Campaign_end_date  
SELECT 
    campaign_name, 
    working, 
    shopper, 
    fluidity, 
    channel, 
    ola_olv, 
    retailer, 
    brand_name, 
    planned_cost, 
    date,
    DATE(PARSE_DATE("%F", SUBSTRING(campaign_start_date, 0,10))) campaign_start_date, 
    DATE(PARSE_DATE("%F", SUBSTRING(campaign_end_date, 0,10))) campaign_end_date 
	FROM `mindshare_baseline.mus_plan_baseline` , UNNEST( GENERATE_DATE_ARRAY(DATE(PARSE_DATE("%F", SUBSTRING(campaign_start_date, 0,10))), DATE(PARSE_DATE("%F", SUBSTRING(campaign_end_date,            0,10))), INTERVAL 1 DAY) ) AS date 
), 
step2 AS (
#Create calculated columns days_between and  sector
SELECT 
    campaign_name, 
    working, 
    shopper, 
    fluidity, 
    channel, 
    ola_olv, 
    retailer, 
    brand_name, 
    planned_cost, 
    date,
    campaign_start_date,
    campaign_end_date,
    CASE
      WHEN LOWER(TRIM(brand_name))='kotex' OR LOWER(TRIM(brand_name))='poise' OR LOWER(TRIM(brand_name))='depend' OR LOWER(TRIM(brand_name))='u by kotex' OR LOWER(TRIM(brand_name))='lavie' THEN  'AFC' 
      WHEN LOWER(TRIM(brand_name))='cottonelle' OR LOWER(TRIM(brand_name))='kleenex' OR LOWER(TRIM(brand_name))='scott' OR LOWER(TRIM(brand_name))='viva' THEN  'FC'  
      WHEN LOWER(TRIM(brand_name))='huggies' OR LOWER(TRIM(brand_name))='pull-ups' OR LOWER(TRIM(brand_name))='goodnites' THEN 'BCC' 
      ELSE 'Others'
    END AS sector,
    DATE_DIFF(campaign_end_date, campaign_start_date, DAY) + 1 AS days_between 
  FROM step1
), 
step3 AS ( 
#Create calculated column cost_per_day
 SELECT 
   campaign_name, 
    working, 
    shopper, 
    fluidity, 
    channel, 
    ola_olv, 
    retailer, 
    sector,
    brand_name, 
    planned_cost, 
    date,
    campaign_start_date,
    campaign_end_date,
    days_between,
    IF(Days_between=0, 0, planned_cost/Days_between) AS cost_per_day 
  FROM step2
), 
final_step AS (
#Select the required columns for the final view and perform aggregation 
SELECT 
    brand_name AS BRAND_NAME, 
    campaign_end_date AS CAMPAIGN_END_DATE, 
    campaign_name AS CAMPAIGN_NAME, 
    campaign_start_date AS CAMPAIGN_START_DATE, 
    channel AS CHANNEL, 
    date AS DATE, 
    days_between AS DAYS_BETWEEN, 
    fluidity AS FLUIDITY, 
    ola_olv AS OLA_OLV, 
    retailer AS RETAILER, 
    sector AS SECTOR,
    shopper AS SHOPPER, 
    working AS WORKING, 
    SUM(cost_per_day) AS COST_PER_DAY, 
    SUM(planned_cost) AS PLANNED_COST 
	FROM step3 
	GROUP BY BRAND_NAME, CAMPAIGN_END_DATE, CAMPAIGN_NAME, CAMPAIGN_START_DATE, CHANNEL, DATE, DAYS_BETWEEN, FLUIDITY, OLA_OLV, RETAILER, SECTOR, SHOPPER, WORKING
) 
#final query to prepare the processed table for the final view
SELECT BRAND_NAME, CAMPAIGN_END_DATE, CAMPAIGN_NAME, CAMPAIGN_START_DATE, CHANNEL, DATE, DAYS_BETWEEN, FLUIDITY, OLA_OLV, RETAILER, SECTOR, SHOPPER, WORKING, COST_PER_DAY, PLANNED_COST FROM final_step
