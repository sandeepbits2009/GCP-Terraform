
--insert into sfmc_email.F_EMAIL_METRICS_INTERMEDIATE_GLOBAL
------------------------------------ Sends Base Dataset -------------------------------------------
With Sends as
(
select
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, Date(EVENT_DATE) as EVENTDATE,EVENT_DATE as TIMESTAMP, DOMAIN, 
upper(COUNTRY_CODE) as COUNTRYCODE, 
EMAIL_NAME, JOURNEY_NAME, 
Case when upper(REGION)="AUS" then "APAC" else REGION end as REGION,
Case when UPPER(BRAND)='GOODNITES' then 'GoodNites'
when UPPER(BRAND)='PULL-UPS' then 'Pull-Ups'
when UPPER(BRAND)='VIVA' then 'Viva'
when UPPER(BRAND)='SCOTT' then 'Scott'
when UPPER(BRAND)='KLEENEX' then 'Kleenex'
when UPPER(BRAND)='COTTONELLE' then 'Cottonelle'
when UPPER(BRAND)='DEPEND' then 'Depend'
when UPPER(BRAND)='POISE' then 'Poise'
when UPPER(BRAND)='UBYKOTEX' then 'UByKotex'
when UPPER(BRAND)='HUGGIES' then 'Huggies'
when UPPER(BRAND)='PLENITUD' then 'Plenitud'
when UPPER(BRAND)='ANDREX' then 'Andrex'
when UPPER(BRAND)='SHIKMA' then 'Shikma'
when UPPER(BRAND)='TITULIM' then 'Titulim'
when UPPER(BRAND)='MOLETT' then 'Molett'
when UPPER(BRAND)='LILY' then 'Lily'
when UPPER(BRAND)='NIKOL' then 'Nikol'
when UPPER(BRAND)='INTIMUS' then 'Intimus'
when UPPER(BRAND)='HAKLE' then 'Hakle'
when UPPER(BRAND)='SCOTTEX' then 'Scottex'
when UPPER(BRAND)='LAVIE' then 'Lavie'
when UPPER(BRAND)='NALAVIE' then 'Lavie'
when UPPER(BRAND)='NEVE' then 'Neve'
when UPPER(BRAND)='SUAVE' then 'Suave'      
when UPPER(BRAND)='KOTEX' then 'Kotex'
when UPPER(BRAND)='DURAMAX' then 'Duramax'
when UPPER(BRAND)='DRYNITES' then 'DryNites'
when BRAND='LaVie' then 'Lavie'
when BRAND='nalavie' then 'Lavie'
when BRAND='PullUps' then 'Pull-Ups'
else BRAND end as BRAND, 
case when BRAND in ('Molett','Lily') then 'FC' else SECTOR end as SECTOR, 
TOUCH_ID, CAMPAIGN, SUBJECT_LINE, SUBJECTLINE_GENERAL

FROM sfmc_email.sends

where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)

group by JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, EVENTDATE, TIMESTAMP, DOMAIN, upper(COUNTRY_CODE), EMAIL_NAME, JOURNEY_NAME, REGION, BRAND, SECTOR, TOUCH_ID, CAMPAIGN, SUBJECT_LINE, SUBJECTLINE_GENERAL
),

------------------------------------ Clicks Base Dataset -------------------------------------------
Clicks as
(
SELECT 
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, URL,
sum(TOTAL_CLICK) as TOTAL_CLICK, 
sum(NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED
 
FROM 
	(
	SELECT 
	JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, URL, IS_UNIQUE,
	1 as TOTAL_CLICK, --Total CLICK
	CASE WHEN SUBSCRIBER_ID is not null and IS_UNIQUE=True THEN 1 ELSE 0 END as NUM_SUBSCRIBERS_CLICKED --Calculation of measure 'NUM_SUBSCRIBERS_CLICKED'
	
	FROM sfmc_email.clicks 
	where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)

	)
group by
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, URL
),

------------------------------------ Bounce Base Dataset -------------------------------------------
Bounce as
(
SELECT JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, BOUNCE_CATEGORY

FROM sfmc_email.bounces
where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)

group by
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, BOUNCE_CATEGORY
),

------------------------------------ Opens Base Dataset -------------------------------------------
Opens as
(
select 
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, 
sum(TOTAL_OPENS) as TOTAL_OPENS

from (
SELECT 
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, IS_UNIQUE, 
1 as TOTAL_OPENS

FROM sfmc_email.open
where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)
)
group by
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID
),

------------------------------------ Unsubs Base Dataset -------------------------------------------
Unsubs as
(
SELECT JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID

FROM sfmc_email.unsubscribe
where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)
group by JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID
)
------------------------------------- Final View query ---------------------------------------------------
-- Abbreviation used
-- snds : Sends Base Dataset
-- clks : Clicks Base Dataset
-- bnc : Bounce Base Dataset
-- Unsubs : unsubscribes base dataset
-- S_C : Resultant intermediate of Sends and Clicks join
-- S_C_B : Resultant intermediate of Sends , Clicks and bounce join
-- S_C_B_O : Resultant intermediate of Sends , Clicks , bounce and Unsubscribe join


select 
REGION, 
CASE WHEN REGION='LAO' and BRAND like 'LAO - AFC%' THEN 'Multi-Brand' ELSE BRAND END as BRAND, 
CASE WHEN REGION='LAO' and BRAND like 'LAO - AFC%' THEN 'Multi-Sector' ELSE SECTOR END as SECTOR,
EMAIL_NAME, JOURNEY_NAME, DOMAIN,TIMESTAMP, TIME_STAMP,BOUNCE_CATEGORY,TOUCH_ID,CAMPAIGN,COUNTRYCODE,SUBJECT_LINE, SUBJECTLINE_GENERAL,
CAST(sum(SENDS)-sum(BOUNCES) as NUMERIC) as DELIVERED,
CAST(sum(TOTAL_CLICK) as NUMERIC) as TOTAL_CLICK, 
CAST(sum(NUM_SUBSCRIBERS_CLICKED) as NUMERIC) as NUM_SUBSCRIBERS_CLICKED, 
CAST(sum(UNIQUE_CLICKS) as NUMERIC) as UNIQUE_CLICKS,
CAST(sum(TOTAL_OPENS) as NUMERIC) as TOTAL_OPENS, 
CAST(sum(UNIQUE_OPENS) as NUMERIC) as UNIQUE_OPENS,
CAST(sum(BOUNCES) as NUMERIC) as BOUNCES,
CAST(sum(UNSUBSCRIBES) as NUMERIC) as UNSUBSCRIBES, 
CAST(sum(SENDS) as NUMERIC) as SENDS,
CAST(sum(UNIQUE_CLICKS_NEW) as NUMERIC) as UNIQUE_CLICKS_NEW
from
	(
		select 
		S_C_B_O.EVENTDATE as TIMESTAMP, S_C_B_O.TIMESTAMP as TIME_STAMP, S_C_B_O.DOMAIN,  CASE WHEN S_C_B_O.COUNTRYCODE='UK' THEN 'GB' ELSE S_C_B_O.COUNTRYCODE END as COUNTRYCODE, S_C_B_O.EMAIL_NAME, S_C_B_O.JOURNEY_NAME, S_C_B_O.REGION, S_C_B_O.BRAND, S_C_B_O.SECTOR, S_C_B_O.TOUCH_ID, S_C_B_O.CAMPAIGN, S_C_B_O.SUBJECT_LINE, S_C_B_O.SUBJECTLINE_GENERAL, S_C_B_O.BOUNCE_CATEGORY,
		sum(S_C_B_O.TOTAL_CLICK) as TOTAL_CLICK, sum(S_C_B_O.NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED, sum(S_C_B_O.UNIQUE_CLICKS) as UNIQUE_CLICKS, sum(S_C_B_O.UNIQUE_CLICKS_NEW) as UNIQUE_CLICKS_NEW, sum(S_C_B_O.BOUNCES) as BOUNCES, sum(S_C_B_O.TOTAL_OPENS) as TOTAL_OPENS, sum(S_C_B_O.UNIQUE_OPENS) as UNIQUE_OPENS,count(S_C_B_O.SUBSCRIBER_ID) as SENDS,
		sum(CASE WHEN Unsubs.SUBSCRIBER_ID is not null THEN 1 ELSE 0 END) as UNSUBSCRIBES--Calculation of measure 'UNSUBSCRIBES',
		
		from	
				(
				select 
				S_C_B.JOB_ID, S_C_B.LIST_ID, S_C_B.BATCH_ID, S_C_B.SUBSCRIBER_ID, S_C_B.EVENTDATE, S_C_B.TIMESTAMP, S_C_B.DOMAIN, S_C_B.COUNTRYCODE, S_C_B.EMAIL_NAME, S_C_B.JOURNEY_NAME, S_C_B.REGION, S_C_B.BRAND, S_C_B.SECTOR, S_C_B.TOUCH_ID, S_C_B.CAMPAIGN, S_C_B.SUBJECT_LINE, S_C_B.SUBJECTLINE_GENERAL,S_C_B.BOUNCE_CATEGORY,
				sum(S_C_B.TOTAL_CLICK) as TOTAL_CLICK, sum(S_C_B.NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED, sum(S_C_B.UNIQUE_CLICKS) as UNIQUE_CLICKS,sum(S_C_B.UNIQUE_CLICKS_NEW) as UNIQUE_CLICKS_NEW, sum(S_C_B.BOUNCES) as BOUNCES,
				sum(Opens.TOTAL_OPENS) as TOTAL_OPENS, sum(CASE WHEN Opens.SUBSCRIBER_ID is not null THEN 1 ELSE 0 END) as UNIQUE_OPENS --Calculation of measure 'UNIQUE_OPENS'
				
					from	
						(
						select 
						S_C.JOB_ID, S_C.LIST_ID, S_C.BATCH_ID, S_C.SUBSCRIBER_ID, CLKS_SUBSCRIBER_ID,S_C.EVENTDATE, S_C.TIMESTAMP, S_C.DOMAIN, S_C.COUNTRYCODE, S_C.EMAIL_NAME, S_C.JOURNEY_NAME, S_C.REGION, S_C.BRAND, S_C.SECTOR, S_C.TOUCH_ID, S_C.CAMPAIGN, S_C.SUBJECT_LINE, S_C.SUBJECTLINE_GENERAL,
						sum(S_C.TOTAL_CLICK) as TOTAL_CLICK, sum(S_C.NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED, sum(S_C.UNIQUE_CLICKS) as UNIQUE_CLICKS,
						CASE WHEN CLKS_SUBSCRIBER_ID is not null THEN 1 ELSE 0 END as UNIQUE_CLICKS_NEW, --Calculation of measure 'NUM_SUBSCRIBERS_CLICKED'

						bnc.BOUNCE_CATEGORY, sum(CASE WHEN bnc.SUBSCRIBER_ID is not null THEN 1 ELSE 0 END) as BOUNCES --Calculation of measure 'BOUNCES'
						from		
								(
								select 
								snds.JOB_ID, snds.LIST_ID, snds.BATCH_ID, snds.SUBSCRIBER_ID as SUBSCRIBER_ID, clks.SUBSCRIBER_ID as CLKS_SUBSCRIBER_ID,snds.EVENTDATE, snds.TIMESTAMP, snds.DOMAIN, snds.COUNTRYCODE, snds.EMAIL_NAME, snds.JOURNEY_NAME, snds.REGION, snds.BRAND, snds.SECTOR, snds.TOUCH_ID, snds.CAMPAIGN, snds.SUBJECT_LINE, snds.SUBJECTLINE_GENERAL,
								sum(clks.TOTAL_CLICK) as TOTAL_CLICK, sum(clks.NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED, sum(CASE WHEN clks.SUBSCRIBER_ID||clks.URL is not null THEN 1 ELSE 0 END) as UNIQUE_CLICKS
							
									from 
									Sends as snds
									left outer join
									Clicks as clks
									
									on
										snds.JOB_ID=clks.JOB_ID
									and snds.LIST_ID=clks.LIST_ID
									and snds.BATCH_ID=clks.BATCH_ID
									and snds.SUBSCRIBER_ID=clks.SUBSCRIBER_ID
							
								group by
								snds.JOB_ID, snds.LIST_ID, snds.BATCH_ID, snds.SUBSCRIBER_ID, clks.SUBSCRIBER_ID,snds.EVENTDATE, snds.TIMESTAMP, snds.DOMAIN, snds.COUNTRYCODE, snds.EMAIL_NAME, snds.JOURNEY_NAME, snds.REGION, snds.BRAND, snds.SECTOR, snds.TOUCH_ID, snds.CAMPAIGN, snds.SUBJECT_LINE, snds.SUBJECTLINE_GENERAL
					
								)S_C	--END of: Aggregation of measures after joining with Clicks table
						left outer join
						Bounce as bnc
						on 
							S_C.JOB_ID=bnc.JOB_ID
						and S_C.LIST_ID=bnc.LIST_ID
						and S_C.BATCH_ID=bnc.BATCH_ID
						and S_C.SUBSCRIBER_ID=bnc.SUBSCRIBER_ID
						
						group by
						S_C.JOB_ID, S_C.LIST_ID, S_C.BATCH_ID, S_C.SUBSCRIBER_ID, S_C.CLKS_SUBSCRIBER_ID,S_C.EVENTDATE, S_C.TIMESTAMP, S_C.DOMAIN, S_C.COUNTRYCODE, S_C.EMAIL_NAME, S_C.JOURNEY_NAME, S_C.REGION, S_C.BRAND, S_C.SECTOR, S_C.TOUCH_ID, S_C.CAMPAIGN, S_C.SUBJECT_LINE, S_C.SUBJECTLINE_GENERAL,bnc.BOUNCE_CATEGORY
					
						) S_C_B --END of: Aggregation of measures after joining with BOUNCE table
					left outer join
					Opens
					on 
						S_C_B.JOB_ID=Opens.JOB_ID
					and S_C_B.LIST_ID=Opens.LIST_ID
					and S_C_B.BATCH_ID=Opens.BATCH_ID
					and S_C_B.SUBSCRIBER_ID=Opens.SUBSCRIBER_ID
					
				group by
				S_C_B.JOB_ID, S_C_B.LIST_ID, S_C_B.BATCH_ID, S_C_B.SUBSCRIBER_ID, S_C_B.EVENTDATE, S_C_B.TIMESTAMP, S_C_B.DOMAIN, S_C_B.COUNTRYCODE, S_C_B.EMAIL_NAME, S_C_B.JOURNEY_NAME, S_C_B.REGION, S_C_B.BRAND, S_C_B.SECTOR, S_C_B.TOUCH_ID, S_C_B.CAMPAIGN, S_C_B.SUBJECT_LINE, S_C_B.SUBJECTLINE_GENERAL,S_C_B.BOUNCE_CATEGORY
		
				
				)S_C_B_O --END of: Aggregation of measures after joining with OPENS table
			left outer join 
			Unsubs
			on 
				S_C_B_O.JOB_ID=Unsubs.JOB_ID
			and S_C_B_O.LIST_ID=Unsubs.LIST_ID
			and S_C_B_O.BATCH_ID=Unsubs.BATCH_ID
			and S_C_B_O.SUBSCRIBER_ID=Unsubs.SUBSCRIBER_ID
			
		group by
		S_C_B_O.EVENTDATE,S_C_B_O.TIMESTAMP,S_C_B_O.DOMAIN,CASE WHEN S_C_B_O.COUNTRYCODE='UK' THEN 'GB' ELSE S_C_B_O.COUNTRYCODE END,S_C_B_O.EMAIL_NAME,S_C_B_O.JOURNEY_NAME,S_C_B_O.REGION, S_C_B_O.BRAND, S_C_B_O.SECTOR, S_C_B_O.TOUCH_ID, S_C_B_O.CAMPAIGN, S_C_B_O.SUBJECT_LINE, S_C_B_O.SUBJECTLINE_GENERAL,S_C_B_O.BOUNCE_CATEGORY
			
		--END of: Aggregation of measures after after joining with UNSUBSCRIBE table join
	)
group by
TIMESTAMP, TIME_STAMP, DOMAIN, COUNTRYCODE, EMAIL_NAME, JOURNEY_NAME, REGION, BRAND, SECTOR, TOUCH_ID, CAMPAIGN, SUBJECT_LINE, SUBJECTLINE_GENERAL, BOUNCE_CATEGORY


