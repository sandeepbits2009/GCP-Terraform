DELETE FROM `mindshare_baseline.mus_paid_search_us_keywords_baseline_processed` WHERE DATE IN ( SELECT
  DATE
 FROM
    `amazon_criteo_feed.amzn_ams_kc_ecom_keywords_fivetran`, (SELECT  FORMAT_DATE('%m-%d-%Y', MAX(file_date)) as LAST_DATE FROM (
  SELECT PARSE_DATE('%m-%d-%Y', REGEXP_EXTRACT(_file, r'[0-9]{2}-[0-9]{2}-[0-9]{4}')) as file_date, _file FROM `amazon_criteo_feed.amzn_ams_kc_ecom_keywords_fivetran`))
  WHERE 
    REGEXP_CONTAINS(_file, LAST_DATE) GROUP BY 1)
