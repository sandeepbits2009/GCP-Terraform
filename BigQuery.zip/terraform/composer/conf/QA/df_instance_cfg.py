LOCATION = "us-central1"
inst_name = ''
def func(inst_name):
    INSTANCE = {
        "type": "BASIC",
        "displayName": inst_name,
        # Enable Private IP
        "privateInstance": "true",
        "networkConfig": {
            "network": "hmp-custom-vpc",
            "ipAllocation": "10.128.0.0/20"
        },
        "version": "6.5.1",
        "dataprocServiceAccount":"data-fusion-service-account@qa-hmpemea-reporting.iam.gserviceaccount.com"
    }
    return INSTANCE
