from datetime import datetime, timedelta
from airflow import models
#from airflow.utils.trigger_rule import TriggerRule
#from airflow.models import Variable
from airflow.providers.google.cloud.operators.datafusion import (
    CloudDataFusionCreatePipelineOperator,
    CloudDataFusionCreateInstanceOperator,
    CloudDataFusionDeleteInstanceOperator,
    CloudDataFusionDeletePipelineOperator,
    CloudDataFusionListPipelinesOperator,
    CloudDataFusionGetInstanceOperator,
    CloudDataFusionRestartInstanceOperator,
    CloudDataFusionStartPipelineOperator,
    CloudDataFusionStopPipelineOperator,
    CloudDataFusionUpdateInstanceOperator,
)
from airflow.providers.google.cloud.sensors.datafusion import CloudDataFusionPipelineStateSensor
#from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.gcs import GCSSynchronizeBucketsOperator
from airflow.utils.task_group import TaskGroup

from conf.df_instance_cfg import *
#from utils.common import *

import yaml
import os
dst_bucket = os.environ.get('GCS_BUCKET')

from google.cloud import logging
from airflow.sensors.python import PythonSensor

# environment can be dev, qa, or prod
#deployment = Variable.get('environment')

default_args = {
    #'start_date': datetime(2022, 9, 14),
    # when we run with permanent composer setup, uncomment above line and edit the date, and comment below line
    'start_date': datetime.today().replace(hour = 0, minute = 0),
    #'email': ['sayeedahmed.mohammed@kcc.com'],
    #'email_on_failure': True,
    #'email_on_retry': True,
    #'retry_exponential_backoff': True,
    #'retry_delay': timedelta(seconds=300),
    'retry_delay': timedelta(seconds=5),
    'retries': 0
}

#with open('/home/airflow/gcs/dags/utils/dag_conf.yaml') as f:
    #dag_config = list(yaml.safe_load_all(f))

with open('/home/airflow/gcs/dags/conf/conf.yaml') as fn:
    config = list(yaml.safe_load_all(fn))

with models.DAG(
    dag_id = 'baseline_6w_weekly',
    default_args=default_args,
    schedule_interval = config[0].get('baseline_weekly').get('schedule').get('interval'),
    #schedule_interval = dag_config[0].get('dev').get('baseline_weekly').get('interval'),
    #schedule_interval=None,  # Override to match your needs
    #schedule_interval='@once',  # Override to match your needs
    catchup=False,
) as dag:

    def check_logs1():
        # Instantiate a client
        #logging_client = logging.Client(project="dev-hmpemea-reporting")
        logging_client = logging.Client()

        # Set the filter to apply to the logs
        FILTER = 'resource.labels.function_name="load_mus_6w_baseline" severity="DEBUG"'
        #FILTER = 'resource.labels.function_name="load_mus_6w_baseline"'

        t = datetime.now()
        #t = datetime(2022, 5, 11)
        t1 = t.replace(hour = 3, minute = 0, second = 0) 
        #t1 = t.replace(hour = 3, minute = 15, second = 0) #dev
        now = t1.isoformat()

        for entry in logging_client.list_entries(filter_=FILTER):  # API call
            if entry.timestamp.isoformat() > now:
	            if "finished with status: 'ok'" in entry.payload:
		            return True
		        #else:
		            #time.sleep(20)
			        #check_function()

                #print(entry.severity, entry.timestamp.isoformat(), entry.payload) 

    cloud_fun1 = PythonSensor(
        task_id='cf_load_mus_6w_status',
        poke_interval=120,
        timeout= 900, #15 mins
        mode="reschedule",
        python_callable = check_logs1,
        #on_failure_callback=_failure_callback,
        #soft_fail=True #Set to true to mark the task as SKIPPED on failure
    )

    def check_logs2():
        # Instantiate a client
        #logging_client = logging.Client(project="dev-hmpemea-reporting")
        logging_client = logging.Client()
        # Set the filter to apply to the logs
        FILTER = 'resource.labels.function_name="load_mus_plan_baseline" severity="DEBUG"'
        #FILTER = 'resource.labels.function_name="load_mus_plan_baseline"'

        t = datetime.now()
        #t = datetime(2022, 5, 11)
        t1 = t.replace(hour = 3, minute = 0, second = 0)
        #t1 = t.replace(hour = 3, minute = 15, second = 0) #dev
        now = t1.isoformat()

        for entry in logging_client.list_entries(filter_=FILTER):  # API call
            if entry.timestamp.isoformat() > now:
	            if "finished with status: 'ok'" in entry.payload:
		            return True
		        #else:
		            #time.sleep(20)
			        #check_function()

                #print(entry.severity, entry.timestamp.isoformat(), entry.payload) 

    cloud_fun2 = PythonSensor(
        task_id='cf_load_mus_plan_status',
        poke_interval=120,
        timeout= 900, #15 mins
        mode="reschedule",
        python_callable = check_logs2,
        #on_failure_callback=_failure_callback,
        #soft_fail=True #Set to true to mark the task as SKIPPED on failure
    )

    def get_obj_name(job, type, name):
        #return config[0].get('dev').get('baseline_weekly').get('sqls').get('media_spend_baseline_delete')[0]
        if type == 'sqls':
            return 'sql/' + config[0].get(job).get(type).get(name)[0]
        else:
            return config[0].get(job).get(type).get(name)[0]

    def get_bucket(job, name):
        type = 'buckets'
        return get_obj_name(job, type, name)

    job_name = 'baseline_weekly'
    INSTANCE_NAME = "df-" + job_name.replace('_', '-')[:27]
    INSTANCE = func(INSTANCE_NAME)
    src_bucket = get_bucket('common', 'src')
    #dst_bucket = get_bucket('common', 'dst')
    temp_bucket = get_bucket(job_name, 'temp_bucket')

    with TaskGroup("mindshare_validation_6w_baseline_DF_job") as df_job:
        create_t = CloudDataFusionCreateInstanceOperator(
            task_id="create_instance",
            location=LOCATION,
            instance_name=INSTANCE_NAME,
            instance=INSTANCE,
        )

        delete_t = CloudDataFusionDeleteInstanceOperator(
            task_id="delete_instance",
            location=LOCATION,
            instance_name=INSTANCE_NAME,
        )

        def get_pipeline_code(pipeline):
            from google.cloud import storage
            import json
            storage_client = storage.Client()
            bucket = storage_client.get_bucket(src_bucket)
            blob = bucket.blob('datafusion/' + pipeline)
            data = json.loads(blob.download_as_string(client=None))
            return data

        pipeline = get_obj_name(job_name, 'dfjobs', 'JOB_MINDSHARE_VALIDATION_6W_BASELINE_FINAL')
        pipeline_code = get_pipeline_code(pipeline)
        p_name = pipeline_code['name']

        create_pipeline = CloudDataFusionCreatePipelineOperator(
            #task_id='create_pipeline_{0}'.format(pipeline.split('.')[0]),
            task_id='create_pipeline_{0}'.format(p_name),
            location=LOCATION,
            pipeline_name=p_name,
            pipeline=pipeline_code,
            instance_name=INSTANCE_NAME,
        )

        # https://airflow.apache.org/docs/apache-airflow-providers-google/stable/operators/cloud/datafusion.html#sensors
        # When start pipeline is triggered asynchronously sensors may be used to run checks
        # and verify that the pipeline in correct state.
    
        # asynchronous -- Flag to return after submitting the pipeline Id to the Data Fusion API.
        # This is useful for submitting long running pipelines and waiting on them asynchronously using the CloudDataFusionPipelineStateSensor
        
        start_pipeline_async = CloudDataFusionStartPipelineOperator(
            task_id='start_pipeline_{0}'.format(p_name),
            location=LOCATION,
            runtime_args={'temp_bucket': temp_bucket},
            pipeline_name=p_name,
            instance_name=INSTANCE_NAME,
            asynchronous=True,
        )

        start_pipeline_sensor = CloudDataFusionPipelineStateSensor(
            task_id='state_sensor_{0}'.format(p_name),
            dag=dag,
            pipeline_name=p_name,
            pipeline_id=start_pipeline_async.output,
            expected_statuses=["COMPLETED"],
            failure_statuses=["FAILED"],
            instance_name=INSTANCE_NAME,
            location=LOCATION,
        )

        create_t >> create_pipeline >> \
            start_pipeline_async >> start_pipeline_sensor >> delete_t

    
    gcs_sync = GCSSynchronizeBucketsOperator(
        task_id='gcs_sync',
        source_bucket = src_bucket,
        source_object='sql/',
        destination_bucket = dst_bucket,
        destination_object='dags/sql/',
        allow_overwrite=True,
    )

    with TaskGroup("mindshare_baseline_weekly_SQLs") as sql_job:
        job_name = 'baseline_weekly'
        SQL = 'sqls'
        task_media_spend_baseline_delete = BigQueryExecuteQueryOperator(
            task_id='media_spend_baseline_delete_6w',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_baseline_delete'),
            use_legacy_sql=False,
        )

        task_media_spend_baseline_process = BigQueryExecuteQueryOperator(
            task_id='media_spend_baseline_process_6w',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_baseline_process'),
            destination_dataset_table = "mindshare_baseline.mus_baseline_media_spend_processed",
            write_disposition = "WRITE_APPEND",
            use_legacy_sql=False,
        )

        task_media_spend_baseline_delete >> task_media_spend_baseline_process

        task_media_spend_us_baseline_delete = BigQueryExecuteQueryOperator(
            task_id='media_spend_us_baseline_delete_6w',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_us_baseline_delete'),
            use_legacy_sql=False,
        )

        task_media_spend_us_baseline_process = BigQueryExecuteQueryOperator(
            task_id='media_spend_us_baseline_process_6w',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_us_baseline_process'),
            destination_dataset_table = "mindshare_baseline.mus_baseline_media_spend_us_processed",
            write_disposition = "WRITE_APPEND",          
            use_legacy_sql=False,
        )

        task_media_spend_us_baseline_delete >> task_media_spend_us_baseline_process

        task_paid_search_us_keywords_baseline_delete = BigQueryExecuteQueryOperator(
            task_id='paid_search_us_keywords_baseline_delete',
            sql = get_obj_name(job_name, SQL, name = 'paid_search_us_keywords_baseline_delete'),
            use_legacy_sql=False,
        )

        task_paid_search_us_keywords_baseline_process = BigQueryExecuteQueryOperator(
            task_id='paid_search_us_keywords_baseline_process',
            sql = get_obj_name(job_name, SQL, name = 'paid_search_us_keywords_baseline_process'),
            destination_dataset_table = "mindshare_baseline.mus_paid_search_us_keywords_baseline_processed",
            write_disposition = "WRITE_APPEND",                     
            use_legacy_sql=False,
        )

        task_paid_search_us_keywords_baseline_delete >> task_paid_search_us_keywords_baseline_process

        task_media_plan_baseline = BigQueryExecuteQueryOperator(
            task_id='media_plan_baseline',
            sql = get_obj_name(job_name, SQL, name = 'media_plan_baseline'),
            destination_dataset_table = "mindshare_baseline.mus_plan_baseline_processed",
            write_disposition = "WRITE_TRUNCATE",
            use_legacy_sql=False,
        )

        task_media_plan_baseline

    [cloud_fun1, cloud_fun2] >> gcs_sync >> df_job >> sql_job