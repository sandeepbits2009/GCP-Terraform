from datetime import datetime, timedelta
from airflow import models
#from airflow.utils.trigger_rule import TriggerRule
#from airflow.models import Variable
from airflow.providers.google.cloud.operators.datafusion import (
    CloudDataFusionCreatePipelineOperator,
    CloudDataFusionCreateInstanceOperator,
    CloudDataFusionDeleteInstanceOperator,
    CloudDataFusionDeletePipelineOperator,
    CloudDataFusionListPipelinesOperator,
    CloudDataFusionGetInstanceOperator,
    CloudDataFusionRestartInstanceOperator,
    CloudDataFusionStartPipelineOperator,
    CloudDataFusionStopPipelineOperator,
    CloudDataFusionUpdateInstanceOperator,
)
from airflow.providers.google.cloud.sensors.datafusion import CloudDataFusionPipelineStateSensor
#from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.gcs import GCSSynchronizeBucketsOperator
from airflow.utils.task_group import TaskGroup
from airflow.providers.google.cloud.sensors.gcs import GCSObjectUpdateSensor
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import GCSToBigQueryOperator

from conf.df_instance_cfg import *
#from utils.common import *

import yaml
import os
dst_bucket = os.environ.get('GCS_BUCKET')

from google.cloud import logging
from airflow.sensors.python import PythonSensor
from airflow.operators.bash import BashOperator

# environment can be dev, qa, or prod
#deployment = Variable.get('environment')

default_args = {
    #'start_date': datetime(2022, 7, 14),
    # when we run with permanent composer setup, uncomment above line and edit the date, and comment below line
    'start_date': datetime.today().replace(hour = 0, minute = 0),    
    #'email': ['sayeedahmed.mohammed@kcc.com'],
    #'email_on_failure': True,
    #'email_on_retry': True,
    #'retry_exponential_backoff': True,
    #'retry_delay': timedelta(seconds=300),
    'retry_delay': timedelta(seconds=5),
    'retries': 0
}

#with open('/home/airflow/gcs/dags/utils/dag_conf.yaml') as f:
    #dag_config = list(yaml.safe_load_all(f))

with open('/home/airflow/gcs/dags/conf/conf.yaml') as fn:
    config = list(yaml.safe_load_all(fn))

with models.DAG(
    dag_id = 'baseline_6m_monthly',
    default_args=default_args,
    schedule_interval = config[0].get('baseline_monthly').get('schedule').get('interval'),
    #schedule_interval = dag_config[0].get('dev').get('baseline_weekly').get('interval'),
    #schedule_interval=None,  # Override to match your needs
    #schedule_interval='@once',  # Override to match your needs
    catchup=False,
) as dag:

    def get_obj_name(job, type, name):
        #return config[0].get('dev').get('baseline_monthly').get('sqls').get('media_spend_baseline_delete')[0]
        if type == 'sqls':
            return 'sql/' + config[0].get(job).get(type).get(name)[0]
        else:
            return config[0].get(job).get(type).get(name)[0]

    def get_bucket(job, name):
        type = 'buckets'
        return get_obj_name(job, type, name)

    # for loading the source file (csv) data into bq table, mus_6m_baseline
    #BUCKET_NAME_SRC = "dev-hmpemea-reporting-us-mindshare-baseline-6m"
    #BUCKET_NAME_DST = "dev-hmpemea-reporting-us-mindshare-baseline-archive"
    #FILE_NAME = "GBQ_MUS_6M_BASELINE.csv"
    #FILE_NAME = "GBQ_MUS_6M_BASELINE.txt.gz"
    #DATASET_NAME = "mindshare_baseline"
    #TABLE_NAME = "mus_6m_baseline"
   
    BUCKET_NAME_SRC = get_bucket('baseline_monthly', 'bq_src')
    BUCKET_NAME_DST = get_bucket('baseline_monthly', 'bq_src_archive')
    FILE_NAME = get_obj_name('baseline_monthly', 'gcs_to_bq', 'file_name')
    DATASET_NAME = get_obj_name('baseline_monthly', 'gcs_to_bq', 'dataset_name')
    TABLE_NAME = get_obj_name('baseline_monthly', 'gcs_to_bq', 'table_name')

    # 2nd thursday can fall between dates 8 to 14.
    # this task will fail, if the task run date is not between 8th to 14th.
    cmd = """D=`date`;day=$(date -d "$D" '+%d');[ $day -ge 8 ] && [ $day -le 14 ]"""
    check_date = BashOperator(
        task_id="check_2nd_thur",
        bash_command=cmd
    )

    gcs_update_object = GCSObjectUpdateSensor(
        task_id='gcs_object_update_sensor_task',
        bucket=BUCKET_NAME_SRC,
        object=FILE_NAME,
    )

    destination_file_name = "{}{}{}{}".format(FILE_NAME.split(".")[0], "_", datetime.today().strftime('%Y%m%d'), ".txt.gz")
    archive_source = GCSToGCSOperator(
        task_id="archive_source_file",
        source_bucket=BUCKET_NAME_SRC,
        source_object=FILE_NAME,
        destination_bucket=BUCKET_NAME_DST,  # If not supplied the source_bucket value will be used
        destination_object="baseline_6m/" + destination_file_name,  # If not supplied the source_object value will be used
    )    

    gcs_to_bigquery = GCSToBigQueryOperator(
        task_id='gcs_to_mus_6m_baseline',
        bucket = BUCKET_NAME_SRC,
        #source_objects=['bigquery/us-states/us-states.csv'],
        source_objects=[FILE_NAME],
        destination_project_dataset_table=f"{DATASET_NAME}.{TABLE_NAME}",
        #schema_object = 'bqschema/mus_6m_baseline.json',
        schema_object = 'bqschema/' + get_obj_name('baseline_monthly', 'gcs_to_bq', 'schema_object'),
        # schema_fields=[
            # {'name': 'Date', 'type': 'STRING', 'mode': 'NULLABLE'}, ...
            # {'name': '_18_Plus_Trps', 'type': 'STRING', 'mode': 'NULLABLE'},
        # ],
        source_format = "CSV",
        compression = "GZIP",
        skip_leading_rows = 1,
        write_disposition='WRITE_TRUNCATE',
        field_delimiter = ",",
    )

    job_name = 'baseline_monthly'
    # instance name can be lowercase alphanumeric characters and hyphen
    # name must start with a letter and must not end with hyphen. It can have maximum 30 characters
    INSTANCE_NAME = "df-" + job_name.replace('_', '-')[:27]
    INSTANCE = func(INSTANCE_NAME)
    src_bucket = get_bucket('common', 'src')
    #dst_bucket = get_bucket('common', 'dst')
    temp_bucket = get_bucket(job_name, 'temp_bucket')

    with TaskGroup("mindshare_validation_6m_baseline_DF_job") as df_job:
        create_t = CloudDataFusionCreateInstanceOperator(
            task_id="create_instance",
            location=LOCATION,
            instance_name=INSTANCE_NAME,
            instance=INSTANCE,
        )

        delete_t = CloudDataFusionDeleteInstanceOperator(
            task_id="delete_instance",
            location=LOCATION,
            instance_name=INSTANCE_NAME,
        )

        def get_pipeline_code(pipeline):
            from google.cloud import storage
            import json
            storage_client = storage.Client()
            bucket = storage_client.get_bucket(src_bucket)
            blob = bucket.blob('datafusion/' + pipeline)
            data = json.loads(blob.download_as_string(client=None))
            return data

        pipeline = get_obj_name(job_name, 'dfjobs', 'JOB_MINDSHARE_VALIDATION_6M_BASELINE_FINAL')
        pipeline_code = get_pipeline_code(pipeline)
        p_name = pipeline_code['name']

        create_pipeline = CloudDataFusionCreatePipelineOperator(
            #task_id='create_pipeline_{0}'.format(pipeline.split('.')[0]),
            task_id='create_pipeline_{0}'.format(p_name),
            location=LOCATION,
            pipeline_name=p_name,
            pipeline=pipeline_code,
            instance_name=INSTANCE_NAME,
        )

        # https://airflow.apache.org/docs/apache-airflow-providers-google/stable/operators/cloud/datafusion.html#sensors
        # When start pipeline is triggered asynchronously sensors may be used to run checks
        # and verify that the pipeline in correct state.
    
        # asynchronous -- Flag to return after submitting the pipeline Id to the Data Fusion API.
        # This is useful for submitting long running pipelines and waiting on them asynchronously using the CloudDataFusionPipelineStateSensor
        
        start_pipeline_async = CloudDataFusionStartPipelineOperator(
            task_id='start_pipeline_{0}'.format(p_name),
            location=LOCATION,
            runtime_args={'temp_bucket': temp_bucket},
            pipeline_name=p_name,
            instance_name=INSTANCE_NAME,
            asynchronous=True,
        )

        start_pipeline_sensor = CloudDataFusionPipelineStateSensor(
            task_id='state_sensor_{0}'.format(p_name),
            dag=dag,
            pipeline_name=p_name,
            pipeline_id=start_pipeline_async.output,
            expected_statuses=["COMPLETED"],
            failure_statuses=["FAILED"],
            instance_name=INSTANCE_NAME,
            location=LOCATION,
        )

        create_t >> create_pipeline >> \
            start_pipeline_async >> start_pipeline_sensor >> delete_t

    
    gcs_sync = GCSSynchronizeBucketsOperator(
        task_id='gcs_sync',
        source_bucket = src_bucket,
        source_object='sql/',
        destination_bucket = dst_bucket,
        destination_object='dags/sql/',
        allow_overwrite=True,
    )

    with TaskGroup("mindshare_baseline_monthly_SQLs") as sql_job:
        #job_name = 'baseline_monthly'
        SQL = 'sqls'
        task_media_spend_baseline_delete = BigQueryExecuteQueryOperator(
            task_id='media_spend_baseline_delete_6m',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_baseline_delete'),
            use_legacy_sql=False,
        )

        task_media_spend_baseline_process = BigQueryExecuteQueryOperator(
            task_id='media_spend_baseline_process_6m',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_baseline_process'),
            destination_dataset_table = "mindshare_baseline.mus_baseline_media_spend_processed",
            write_disposition = "WRITE_APPEND",
            use_legacy_sql=False,
        )

        task_media_spend_baseline_delete >> task_media_spend_baseline_process

        task_media_spend_us_baseline_delete = BigQueryExecuteQueryOperator(
            task_id='media_spend_us_baseline_delete_6m',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_us_baseline_delete'),
            use_legacy_sql=False,
        )

        task_media_spend_us_baseline_process = BigQueryExecuteQueryOperator(
            task_id='media_spend_us_baseline_process_6m',
            sql = get_obj_name(job_name, SQL, name = 'media_spend_us_baseline_process'),
            destination_dataset_table = "mindshare_baseline.mus_baseline_media_spend_us_processed",
            write_disposition = "WRITE_APPEND",          
            use_legacy_sql=False,
        )

        task_media_spend_us_baseline_delete >> task_media_spend_us_baseline_process

    check_date >> gcs_update_object >> archive_source >> gcs_to_bigquery >> gcs_sync >> df_job >> sql_job