import time
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
from airflow import models
#from airflow.utils.trigger_rule import TriggerRule
#from airflow.models import Variable
from airflow.providers.google.cloud.operators.datafusion import (
    CloudDataFusionCreatePipelineOperator,
    CloudDataFusionCreateInstanceOperator,
    CloudDataFusionDeleteInstanceOperator,
    CloudDataFusionDeletePipelineOperator,
    CloudDataFusionListPipelinesOperator,
    CloudDataFusionGetInstanceOperator,
    CloudDataFusionRestartInstanceOperator,
    CloudDataFusionStartPipelineOperator,
    CloudDataFusionStopPipelineOperator,
    CloudDataFusionUpdateInstanceOperator,
)
from airflow.providers.google.cloud.sensors.datafusion import CloudDataFusionPipelineStateSensor
#from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.gcs import GCSSynchronizeBucketsOperator
from airflow.utils.task_group import TaskGroup

from conf.df_instance_cfg import *

import yaml
import os
dst_bucket = os.environ.get('GCS_BUCKET')


from google.cloud import logging
from airflow.sensors.python import PythonSensor

# environment can be dev, qa, or prod
#deployment = Variable.get('environment')

default_args = {
    #'start_date': datetime(2022, 9, 19),
    # when we run with permanent composer setup, uncomment above line and edit the date, and comment below line
    'start_date': datetime.today().replace(hour = 0, minute = 0),
    #'email': ['sayeedahmed.mohammed@kcc.com'],
    #'email_on_failure': True,
    #'email_on_retry': True,
    #'retry_exponential_backoff': True,
    #'retry_delay': timedelta(seconds=300),
    'retry_delay': timedelta(seconds=5),
    'retries': 0
}

#with open('/home/airflow/gcs/dags/utils/dag_conf.yaml') as f:
    #dag_config = list(yaml.safe_load_all(f))

with open('/home/airflow/gcs/dags/conf/conf.yaml') as fn:
    config = list(yaml.safe_load_all(fn))

with models.DAG(
    dag_id = 'sfmc_global_detailed_email',
    default_args=default_args,
    schedule_interval = config[0].get('sfmc_global_detailed_email').get('schedule').get('interval'),
    #schedule_interval = dag_config[0].get('dev').get('baseline_6w_weekly_job').get('interval'),
    #schedule_interval=None,  # Override to match your needs
    #schedule_interval='@once',  # Override to match your needs
    catchup=False,
) as dag:

    def get_obj_name(job, type, name):
        #return config[0].get('dev').get('baseline_weekly').get('sqls').get('media_spend_baseline_delete')[0]
        if type == 'sqls':
            return 'sql/' + config[0].get(job).get(type).get(name)[0]
        else:
            return config[0].get(job).get(type).get(name)[0]

    def get_bucket(job, name):
        type = 'buckets'
        return get_obj_name(job, type, name)

    job_name = 'email'
    # instance name can be lowercase alphanumeric characters and hyphen
    # name must start with a letter and must not end with hyphen. It can have maximum 30 characters
    INSTANCE_NAME = "df-" + job_name.replace('_', '-')[:27]
    INSTANCE = func(INSTANCE_NAME)
    
    # same for 3 jobs (old, global, and detailed email)
    src_bucket = get_bucket('common', 'src')
    #dst_bucket = get_bucket('common', 'dst')

    gcs_sync = GCSSynchronizeBucketsOperator(
        task_id='gcs_sync',
        source_bucket = src_bucket,
        source_object='sql/',
        destination_bucket = dst_bucket,
        destination_object='dags/sql/',
        allow_overwrite=True,
    )

    delay_task = PythonOperator(
        task_id = "delay_2min",
        python_callable=lambda: time.sleep(120)
        )

    with TaskGroup("sfmc_email_SQL") as sql_job:
        SQL = 'sqls'
        #job_name = 'global_email'
        task_sfmc_email_etl_global = BigQueryExecuteQueryOperator(
            task_id = 'sfmc_email_etl_global_Incremental',
            sql = get_obj_name('global_email', SQL, name = 'sfmc_email_etl_global'),
            destination_dataset_table = "sfmc_email.F_EMAIL_METRICS_INTERMEDIATE_GLOBAL",
            write_disposition = "WRITE_TRUNCATE",
            use_legacy_sql=False,
        )
        task_sfmc_email_etl_global

        #job_name = 'detailed_email'
        task_detailed_email_activity = BigQueryExecuteQueryOperator(
            task_id = 'detailed_email_activity',
            sql = get_obj_name('detailed_email', SQL, name = 'detailed_email_activity'),
            destination_dataset_table = "sfmc_email.F_DETAILED_EMAIL_ACTIVITY_INTERMEDIATE",
            write_disposition = "WRITE_TRUNCATE",
            use_legacy_sql=False,
        )
        task_detailed_email_activity
        
        #job_name = 'old_email'
        task_old_email_activity = BigQueryExecuteQueryOperator(
            task_id = 'old_email_activity',
            sql = get_obj_name('old_email', SQL, name = 'sfmc_email_final'),
            destination_dataset_table = "sfmc_email.F_EMAIL_METRICS_INTERMEDIATE",
            write_disposition = "WRITE_TRUNCATE",
            use_legacy_sql=False,
        )
        task_old_email_activity

    with TaskGroup("sfmc_email_DF") as df_job:
        create_t = CloudDataFusionCreateInstanceOperator(
            task_id="create_instance",
            location=LOCATION,
            instance_name=INSTANCE_NAME,
            instance=INSTANCE,
        )

        delete_t = CloudDataFusionDeleteInstanceOperator(
            task_id="delete_instance",
            location=LOCATION,
            instance_name=INSTANCE_NAME,
        )

        def get_pipeline_code(pipeline):
            from google.cloud import storage
            import json
            storage_client = storage.Client()
            bucket = storage_client.get_bucket(src_bucket)
            blob = bucket.blob('datafusion/' + pipeline)
            data = json.loads(blob.download_as_string(client=None))
            return data

        for jobn in ['global_email', 'detailed_email', 'old_email']:
            if jobn == 'global_email':
                pipeline = get_obj_name(jobn, 'dfjobs', 'JOB_HMP_SFMC_EMAIL_METRICS_GLOBAL')
                pipeline_code = get_pipeline_code(pipeline)
                p_name = pipeline_code['name']
                input_bucket_email = get_bucket(jobn, 'input_bucket_email')
                output_bucket_email = get_bucket(jobn, 'output_bucket_email')             
            elif jobn == 'detailed_email':
                pipeline = get_obj_name(jobn, 'dfjobs', 'JOB_HMP_SFMC_DETAILED_EMAIL_ACTIV')
                pipeline_code = get_pipeline_code(pipeline)
                p_name = pipeline_code['name']       
                input_bucket_email = get_bucket(jobn, 'input_bucket_email')
                output_bucket_email = get_bucket(jobn, 'output_bucket_email')
            elif jobn == 'old_email':
                pipeline = get_obj_name(jobn, 'dfjobs', 'JOB_HMP_SFMC_EMAIL_METRIC_UPDATED_BRAND_NAME')
                pipeline_code = get_pipeline_code(pipeline)
                p_name = pipeline_code['name']       
                input_bucket_email = get_bucket(jobn, 'input_bucket_email')
                output_bucket_email = get_bucket(jobn, 'output_bucket_email')

            create_pipeline = CloudDataFusionCreatePipelineOperator(
                #task_id='create_pipeline_{0}'.format(pipeline.split('.')[0]),
                task_id='create_pipeline_{0}'.format(p_name),
                location=LOCATION,
                pipeline_name=p_name,
                pipeline=pipeline_code,
                instance_name=INSTANCE_NAME,
            )

            # https://airflow.apache.org/docs/apache-airflow-providers-google/stable/operators/cloud/datafusion.html#sensors
            # When start pipeline is triggered asynchronously sensors may be used to run checks
            # and verify that the pipeline in correct state.
    
            # asynchronous -- Flag to return after submitting the pipeline Id to the Data Fusion API.
            # This is useful for submitting long running pipelines and waiting on them asynchronously using the CloudDataFusionPipelineStateSensor
        
            start_pipeline_async = CloudDataFusionStartPipelineOperator(
                task_id='start_pipeline_{0}'.format(p_name),
                location=LOCATION,
                runtime_args={'input_bucket_email': input_bucket_email, 'output_bucket_email': output_bucket_email},
                pipeline_name=p_name,
                instance_name=INSTANCE_NAME,
                asynchronous=True,
            )

            start_pipeline_sensor = CloudDataFusionPipelineStateSensor(
                task_id='state_sensor_{0}'.format(p_name),
                dag=dag,
                pipeline_name=p_name,
                pipeline_id=start_pipeline_async.output,
                expected_statuses=["COMPLETED"],
                failure_statuses=["FAILED"],
                instance_name=INSTANCE_NAME,
                location=LOCATION,
            )

            create_t >> create_pipeline >> \
                start_pipeline_async >> start_pipeline_sensor >> delete_t  

    gcs_sync >> delay_task >> sql_job >> df_job