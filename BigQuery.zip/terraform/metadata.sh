#! /bin/bash

sudo chmod 700 /home/*/.ssh
sudo chmod 600 /home/*/.ssh/authorized_keys