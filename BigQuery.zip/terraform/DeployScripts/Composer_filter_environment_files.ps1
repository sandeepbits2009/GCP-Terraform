<#
Parameter:
$Folder_name = should be "QA" for QA artifact and "PROD" for PROD artifact.

What this script do?
First it will search for ‘QA’ and ‘PROD’ folder all over the repo. 
Then, it will move all the files from “QA” folder to the parent folder where “QA” folder is placed. Similarly, it will move all the files from “PROD” folder to the parent folder where “PROD” folder is placed. 
For example:  
’k/QA’ -> ‘k’ (for drop_QA) 
‘k/PROD’ -> ‘k’ (for drop_PROD) 
Then it will delete both “QA” and “PROD” so the unnecessary folder should not be present in both the build artifact.  
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][String]$Folder_name
)

begin {
Write-Host "*****************#Begin Step#*********************"

}

process {
    $folder = Get-ChildItem -Path "$env:Build_SourcesDirectory\*" -Include "$Folder_name" -Depth 10
    foreach ($sourcepath in $folder)
    {
        write-host "Source Path: $sourcepath"   
        $targetpath = "$sourcepath".Replace("\$Folder_name","")
        write-host "Target Path: $targetpath"
        robocopy "$sourcepath" "$targetpath"
        Remove-Item -Path $sourcepath -Verbose -Recurse -Force -ErrorAction SilentlyContinue
    }
    if($Folder_name -eq "QA")
    {
      $Folder_name = "PROD"  
    }
    else
    {
        $Folder_name = "QA"
    }

    $folder = Get-ChildItem -Path "$env:Build_SourcesDirectory\*" -Include "$Folder_name" -Depth 10
    foreach ($sourcepath in $folder)
    {
        Remove-Item -Path $sourcepath -Verbose -Recurse -Force -ErrorAction SilentlyContinue
    }
    if ($lastexitcode -lt 8) { $lastexitcode = 0 }
}
end{
Write-Host "*****************#End Steps#*********************"
}