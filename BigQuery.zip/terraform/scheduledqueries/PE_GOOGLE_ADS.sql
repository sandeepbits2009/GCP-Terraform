
WITH pe_google_ads as (

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_huggies.keyword_peru_huggies_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_kotex_ecommerce.keyword_peru_kotex_ecommerce_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_kotex.keyword_peru_kotex_checker --No Data

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_fam_sem.keyword_peru_fam_sem_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_suave.keyword_peru_suave_checker --No Data

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_fam_youtube.keyword_peru_fam_youtube_checker --No Data

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_peru_plenitud_seasonal.keyword_peru_plenitud_seasonal_checker --No Data
)

select 
customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, account_descriptive_name, impressions
from pe_google_ads 