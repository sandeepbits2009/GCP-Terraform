



--insert into sfmc_crm_onepd.CV_MAP_UTILIZATION_UNIQUE_COUNTRY

with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),

unique_consumer 
as
(   Select sum(TOT_CONSUMER) TOT_CONSUMER,REGION,COUNTRYCODE from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,TOT_CONSUMER from sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED 
    where 
    ((region = 'KCNA' and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')) or (region <> 'KCNA' and upper(IS_CONTACTABLE) in ('Y','TRUE')))
    AND TIMESTAMP = last_day(date_sub(current_date(), interval 1 month))
    )
    group by REGION,COUNTRYCODE
),

db_acq_epsi 
as
(
    Select sum(NO_OF_CONSUMERS) TOT_CONSUMER,REGION,COUNTRYCODE from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,NO_OF_CONSUMERS from sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    where 
    timestamp >= '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')
	AND BRAND = 'NA'
    AND SECTOR = 'NA'
    AND TIMESTAMP = last_day(date_sub(current_date(), interval 1 month))
    )
    group by REGION,COUNTRYCODE

),

epsi_unique_cons as
(
    select TOT_CONSUMER,REGION,COUNTRYCODE from unique_consumer
    union all 
    select TOT_CONSUMER,REGION,COUNTRYCODE from db_acq_epsi
),


sends_base as
(
SELECT 
distinct
Region, 
country_code, 
subscriber_id , 
date(Event_date) Event_date
from sfmc_email.sends 
where date(Event_date) <= last_day(date_sub(CURRENT_DATE(), interval 1 month)) 
------union on email_subscriber will happen here.
union all 
SELECT 
distinct
Region, 
countrycode, 
subscriberid , 
date(Eventdate) Event_date
from sfmc_crm_onepd.email_subscriber 
where date(Eventdate) <= last_day(date_sub(CURRENT_DATE(), interval 1 month))
),

sends_rolling as
(
select count(distinct subscriber_id) sends_rolling_12months, region, country_code from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 13 month)) and last_day(date_sub(CURRENT_DATE(), interval 1 month)) 
group by region, country_code
),

sends as
(
select count(distinct subscriber_id) sends, region, country_code from 
sends_base 
group by region, country_code  
),


email_sends as
(
Select 
sends_rolling_12months,
sends.sends as sends,
sends.country_code as country_code,
sends.region as region
from 
sends left join sends_rolling 
on sends.country_code = sends_rolling.country_code 
and sends.region = sends_rolling.region
)

Select 
			  cast(base_country.TOT_CONSUMER as INT64) as TOT_CONSUMER,
              base_country.sends_rolling_12months as Sends_rolling_12_months,
              base_country.sends as Sends,
              base_country.country_code as Countrycode,
              base_country.region as Region,
              case 
              when base_country.country_code in ('UK','GB') then 'United Kingdom' 
              when base_country.country_code ='UN' then 'Unknown' else base_country.country_code_desc end as COUNTRYCODE_DESC,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends/base_country.TOT_CONSUMER,2) end as Utilization,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends_rolling_12months/base_country.TOT_CONSUMER,2) end as Utilization_rolling_12_months,
              from
              (
                    SELECT 
                    base.TOT_CONSUMER ,
                    base.sends_rolling_12months,
                    base.sends,
                    base.country_code,
                    base.region   ,
                    country_desc.country_code_desc as country_code_desc
                    from   
                    (
						Select 
							epsi_unique_cons.TOT_CONSUMER ,
							email_sends.sends_rolling_12months,
							email_sends.sends,
							email_sends.country_code,
							email_sends.region
							from 
							email_sends 
						inner join 
						epsi_unique_cons 
						on email_sends.country_code = epsi_unique_cons.COUNTRYCODE 
						and email_sends.region = epsi_unique_cons.region
                     ) base 
                left join 
                country_desc country_desc 
                ON base.country_code =  country_desc.country_code 
)base_country


