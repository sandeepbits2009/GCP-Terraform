


--insert into sfmc_crm_onepd.CV_MAP_UTILIZATION_1PD

with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
sends_base as
(
SELECT 
distinct
case when country_code in ('AU','NZ') then 'APAC' else Region end as Region, 
case when country_code='UK' then 'GB' else country_code end as country_code, 
subscriber_id , 
Case when UPPER(BRAND)='GOODNITES' then 'GoodNites'
when UPPER(BRAND)='PULL-UPS' then 'Pull-Ups'
when UPPER(BRAND)='VIVA' then 'Viva'
when UPPER(BRAND)='SCOTT' then 'Scott'
when UPPER(BRAND)='KLEENEX' then 'Kleenex'
when UPPER(BRAND)='COTTONELLE' then 'Cottonelle'
when UPPER(BRAND)='DEPEND' then 'Depend'
when UPPER(BRAND)='POISE' then 'Poise'
when UPPER(BRAND)='UBYKOTEX' then 'UByKotex'
when UPPER(BRAND)='HUGGIES' then 'Huggies'
when UPPER(BRAND)='PLENITUD' then 'Plenitud'
when UPPER(BRAND)='ANDREX' then 'Andrex'
when UPPER(BRAND)='SHIKMA' then 'Shikma'
when UPPER(BRAND)='TITULIM' then 'Titulim'
when UPPER(BRAND)='MOLETT' then 'Molett'
when UPPER(BRAND)='LILY' then 'Lily'
when UPPER(BRAND)='NIKOL' then 'Nikol'
when UPPER(BRAND)='INTIMUS' then 'Intimus'
when UPPER(BRAND)='HAKLE' then 'Hakle'
when UPPER(BRAND)='SCOTTEX' then 'Scottex'
when UPPER(BRAND)='LAVIE' then 'Lavie'
when UPPER(BRAND)='NALAVIE' then 'Lavie'
when UPPER(BRAND)='NEVE' then 'Neve'
when UPPER(BRAND)='SUAVE' then 'Suave'      
when UPPER(BRAND)='KOTEX' then 'Kotex'
when UPPER(BRAND)='DURAMAX' then 'Duramax'
when UPPER(BRAND)='DRYNITES' then 'DryNites'
when BRAND='LaVie' then 'Lavie'
when BRAND='nalavie' then 'Lavie'
when BRAND='PullUps' then 'Pull-Ups'
else BRAND end as BRAND,
sector,
date(Event_date) Event_date
from sfmc_email.sends
where date(Event_date) <= last_day(date_sub(current_date(), interval 1 month)) 
------union on email_subscriber will happen here.
union all 
SELECT 
distinct
Region, 
countrycode, 
subscriberid , 
brand,
sector,
date(Eventdate) Event_date
from sfmc_crm_onepd.email_subscriber 
where date(Eventdate) <= last_day(date_sub(current_date(), interval 1 month))
),
sends_rolling as
(
select count(distinct subscriber_id) sends_rolling_12months, region, country_code, brand, sector from 
sends_base 
where Event_date between last_day(date_sub(current_date(), interval 13 month)) and last_day(date_sub(current_date(), interval 1 month)) 
group by region, country_code, brand, sector
),
sends as
(
select count(distinct subscriber_id) sends, region, country_code, brand, sector from 
sends_base 
group by region, country_code, brand, sector
),
email_sends as
(
Select 
sends_rolling_12months,
sends.sends as sends,
sends.country_code as country_code,
sends.region as region,
sends.brand,
sends.sector
from 
sends left join sends_rolling 
on sends.country_code = sends_rolling.country_code 
and sends.region = sends_rolling.region
and sends.brand = sends_rolling.brand
and sends.sector = sends_rolling.sector
),
db_health_monthly 
as
(   Select sum(TOT_CONSUMER) TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,TOT_CONSUMER,brand, sector from sfmc_crm_onepd.F_DB_HEALTH_MONTHLY_VALIDATED
    where 
    (
    (region = 'KCNA'  and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and countrycode = 'US' and upper(brand) <> 'HUGGIES')  or
    (region = 'KCNA'  and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and sector <> 'BCC' and countrycode<> 'US')  or
    (region = 'KCNA'  and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and Age_in_months = 9999 and countrycode <> 'US') or
    (region <> 'KCNA' and upper(IS_CONTACTABLE) in ('Y','TRUE'))  
    )
    AND TIMESTAMP = last_day(date_sub(current_date(), interval 1 month))
    )
    group by REGION,COUNTRYCODE,brand, sector 
),
db_acq_epsi 
as
(
    Select sum(NO_OF_CONSUMERS) TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector  from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,
    case when countrycode = 'US' and upper(brand)='HUGGIES' then 0 else NO_OF_CONSUMERS end as NO_OF_CONSUMERS,brand, sector  from sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    where 
    timestamp >= '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and 
    (
    (upper(REGION)='KCNA' and SECTOR='BCC' and AGE_IN_MONTHS=9999) OR 
    (upper(REGION)='KCNA' and SECTOR<>'BCC')
    )
    AND TIMESTAMP = last_day(date_sub(current_date(), interval 1 month))
	AND BRAND <> 'NA'
    AND SECTOR <> 'NA'
    )
    where NO_OF_CONSUMERS<>0
    group by REGION,COUNTRYCODE,brand, sector 

),
KCNA_HUGGIES_1PD as
(   
    SELECT 
    SUM(TOT_CONSUMER_US_HUGGIES) AS TOT_CONSUMER,
    COUNTRYCODE,REGION,SECTOR,BRAND FROM
    (
    select 
    IN_AGE_CONSUMERS + CATEGORY_PURCHASE_CONSUMERS + PRE_CATEGORY_PURCHASE_CONSUMERS as TOT_CONSUMER_US_HUGGIES ,
    'BCC' as SECTOR,
    'Huggies' as BRAND ,
    COUNTRY_CODE AS COUNTRYCODE,
    REGION
    from 
    (
    SELECT * FROM sfmc_crm_onepd.CV_MAP_ACQ_KCNA_HUGGIES_1PD_EPSI
    UNION ALL 
    SELECT * FROM sfmc_crm_onepd.CV_MAP_ACQ_KCNA_HUGGIES_1PD_OVEN
    )KCNA_HUGGIES_1PD
    where 
    DATE = last_day(date_sub(current_date(), interval 1 month)) and  ---made changes here, removed hard coded value '2021-07-31'
    COUNTRY_CODE = 'US'
    )KCNA_HUGGIES_1PD_AGG

    GROUP BY COUNTRYCODE,REGION, SECTOR,BRAND 
),
epsi_unique_cons as
(
    select TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from db_health_monthly
    union all 
    select TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from db_acq_epsi
    union all 
    select TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from KCNA_HUGGIES_1PD 

)

Select 
			  cast(base_country.TOT_CONSUMER as INT64) as TOT_CONSUMER,
              base_country.sends_rolling_12months as Sends_rolling_12_months,
              base_country.sends as Sends,
              base_country.country_code as Countrycode,
              base_country.region as Region,
              base_country.brand as Brand,
              base_country.sector as Sector,
              case 
              when base_country.country_code in ('UK','GB') then 'United Kingdom' 
              when base_country.country_code ='UN' then 'Unknown' else base_country.country_code_desc end as COUNTRYCODE_DESC,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends/base_country.TOT_CONSUMER,2) end as Utilization,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends_rolling_12months/base_country.TOT_CONSUMER,2) end as Utilization_rolling_12_months,
              from
              (
                    SELECT 
                    base.TOT_CONSUMER ,
                    base.sends_rolling_12months,
                    base.sends,
                    base.country_code,
                    base.region   ,
                    base.brand,
                    base.sector,
                    country_desc.Country_Code_Desc  as country_code_desc
                    from   
                    (
						Select 
							epsi_unique_cons.TOT_CONSUMER ,
							email_sends.sends_rolling_12months,
							email_sends.sends,
							epsi_unique_cons.COUNTRYCODE country_code,
							epsi_unique_cons.region,
                            epsi_unique_cons.brand,
                            epsi_unique_cons.sector
							from 
							email_sends 
						inner join 
						epsi_unique_cons 
						on email_sends.country_code = epsi_unique_cons.COUNTRYCODE 
						and email_sends.region = epsi_unique_cons.region
						and email_sends.brand = epsi_unique_cons.brand
						and email_sends.sector = epsi_unique_cons.sector
              ) base 
                left join 
                country_desc country_desc 
                ON base.country_code =  country_desc.country_code 
)base_country
