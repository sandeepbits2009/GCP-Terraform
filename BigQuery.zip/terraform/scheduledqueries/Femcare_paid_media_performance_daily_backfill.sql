

WITH brazil_dv360 as (
SELECT
  date AS Date,
  "LAO" as Region,
  "Brazil" As Country,
  CASE
    WHEN REGEXP_CONTAINS(Campaign, 'Huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign, 'Intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign, 'Plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign, 'Duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign, 'Kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign, 'Neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign, 'huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign, 'intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign, 'plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign, 'duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign, 'kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign, 'neve') THEN 'Neve'
    ELSE 'Unknown'
  END as Brand,
  CASE
    WHEN REGEXP_CONTAINS(Campaign, 'Huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign, 'Intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'Plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'Duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'Kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'Neve') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign, 'intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'neve') THEN 'FC'    
ELSE 'Unknown'
  END as Sector,
  cast(null as string) as Media_Type,
  Cast(null as string) AS Account_Id,
  Cast( Data_Source_name as string)  AS Account_Name,  
  CAST(Campaign AS STRING)  AS Campaign, 
  Cast(null as string) AS Ad_Group, 
  Cast(null as string) AS Keyword, 
  Cast(null as string) AS Network, 
  Cast(null as string) AS Network_With_Search_Param, 
  Cast(null as string) as Device,
  CAST(Impressions as INT64) AS Impressions,
  CAST(Clicks as INT64) AS Clicks,
  Cast(null as INT64) as Interactions,
  Cast(null as INT64) as Engagements,
  CAST (Revenue__DoubleClick_Bid_Manager as FLOAT64) as Cost,
  Cast(null as string) as Quality_Score,
  Cast(null as string) as Landing_Page,
  Cast(null as string) as Impression_Share,
  CAST (Creative__DoubleClick_Bid_Manager  as string) as Creative_Name,
  CAST(Creative_Size__DoubleClick_Bid_Manager as string) as Creative_Size,
  CAST(Creative_Type__DoubleClick_Bid_Manager as string) as Creative_Type,
  Cast(null as string) as Placement,
  CAST(Advertiser_ID__DoubleClick_Bid_Manager as string) as Advertiser_ID,
  CAST(Advertiser__DoubleClick_Bid_Manager as string) as Advertiser,  
  CAST( Campaign_ID__DoubleClick_Bid_Manager AS STRING) AS Campaign_ID,
  CAST(Activity__DoubleClick_Bid_Manager as string) as Activity,
  CAST(Video_Completed_Views__DoubleClick_Bid_Manager as INT64) as Video_Views,
  CAST(Video_Starts__DoubleClick_Bid_Manager as INT64) as Video_Plays,
  CAST(Video_Viewed_To_25__DoubleClick_Bid_Manager as INT64) as Video_Watch_25_Percent,
  CAST(Video_Viewed_To_50__DoubleClick_Bid_Manager as INT64) as Video_Watch_50_Percent,
  CAST(Video_Viewed_To_75__DoubleClick_Bid_Manager as INT64) as Video_Watch_75_Percent,
  CAST(Video_Completed_Views__DoubleClick_Bid_Manager as INT64) as Video_Watch_100_Percent,
  CAST(Total_Conversions__DoubleClick_Bid_Manager as float64) as Conversions,
  Cast(null as string) as Ad_Set,
  Cast(null as string) as Ad_Set_ID,
  Cast(null as string) as Ad_Name,
  Cast(null as string) as Ad_ID,
  Cast(null as string) as Objective,
  "DV360" as Platform, 
  Cast(null as string) as Adset_Geo_Targeting,
  Cast(null as string) as Adset_Target_Platform,
  Cast(null as string) as Adset_Locales,
  Cast(null as string) as Impression_Device,
  Cast(null as INT64) as Video_Watch_30_sec
FROM
  `dv360_performance_brazil.funnel_data_*`
  WHERE date between '2020-01-01' and '{{backfill date}}'
  ),
  
cm as (
SELECT
  date AS Date,
  "LAO" as Region,
  CASE
    WHEN REGEXP_CONTAINS(advertiser, 'Argentina') THEN 'Argentina'
    WHEN REGEXP_CONTAINS(advertiser, 'Peru') THEN 'Peru'
    WHEN REGEXP_CONTAINS(advertiser, 'Perú') THEN 'Peru'
    WHEN REGEXP_CONTAINS(advertiser, 'Colombia') THEN 'Colombia'
    WHEN REGEXP_CONTAINS(advertiser, 'Chile') THEN 'Chile'
    WHEN REGEXP_CONTAINS(advertiser, 'Costa Rica') THEN 'Costa Rica'
    WHEN REGEXP_CONTAINS(advertiser, 'argentina') THEN 'Argentina'
    WHEN REGEXP_CONTAINS(advertiser, 'peru') THEN 'Peru'
    WHEN REGEXP_CONTAINS(advertiser, 'perú') THEN 'Peru'
    WHEN REGEXP_CONTAINS(advertiser, 'colombia') THEN 'Colombia'
    WHEN REGEXP_CONTAINS(advertiser, 'chile') THEN 'Chile'
    WHEN REGEXP_CONTAINS(advertiser, 'costa rica') THEN 'Costa Rica'   
ELSE 'Unknown'
  END as Country,
  CASE
    WHEN REGEXP_CONTAINS(Campaign_name, 'Huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Scott') THEN 'Scott'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kotex') THEN 'Kotex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Suave') THEN 'Suave'
    WHEN REGEXP_CONTAINS(Campaign_name, 'huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign_name, 'intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign_name, 'plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign_name, 'duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign_name, 'scott') THEN 'Scott'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kotex') THEN 'Kotex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'suave') THEN 'Suave'
    ELSE 'Unknown'
  END as Brand,
  CASE
    WHEN REGEXP_CONTAINS(Campaign_name, 'Huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Neve') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Scott') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kotex') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Suave') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'neve') THEN 'FC'   
    WHEN REGEXP_CONTAINS(Campaign_name, 'scott') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kotex') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'suave') THEN 'FC'
ELSE 'Unknown'
  END as Sector,
  cast(null as string) as Media_Type,
  Cast(null as string) AS Account_ID, 
  Cast( null as string)  AS Account_Name, 
  CAST(Campaign_name AS STRING)  AS Campaign, 
  Cast(null as string) AS Ad_Group, 
  Cast(null as string) AS Keyword, 
  Cast(null as string) AS Network, 
  Cast(null as string) AS Network_With_Search_Param, 
  Cast(null as string) as Device,
  CAST(Impressions as INT64) AS Impressions,
  CAST(Clicks as INT64) AS Clicks,
  Cast(null as INT64) as Interactions,
  Cast(null as INT64) as Engagements,
  CAST (media_cost as FLOAT64) as Cost,
  Cast(null as string) as Quality_Score,
  Cast(null as string) as Landing_Page,
  Cast(null as string) as Impression_Share,
  CAST (null  as string) as Creative_Name, --- no creative
  CAST(null as string) as Creative_Size, --- no creative
  CAST(null as string) as Creative_Type, --- no creative
  Cast(null as string) as Placement,
  CAST(Advertiser_id as string) as Advertiser_ID,
  CAST(Advertiser as string) as Advertiser,  
  CAST( Campaign_ID AS STRING) AS Campaign_ID,
  CAST(Activity as string) as Activity,
  CAST( video_views as INT64) as Video_Views,
  CAST(Video_plays as INT64) as Video_Plays,
  CAST( video_watch_25_percent as INT64) as Video_Watch_25_Percent,
  CAST(video_watch_50_percent as INT64) as Video_Watch_50_Percent,
  CAST(video_watch_75_percent as INT64) as Video_Watch_75_Percent,
  CAST(video_watch_100_percent as INT64) as Video_Watch_100_Percent,
  CAST(Total_Conversions as float64) as Conversions,
  Cast(null as string) as Ad_Set,
  Cast(null as string) as Ad_Set_ID,
  Cast(null as string) as Ad_Name,
  Cast(null as string) as Ad_ID,
  Cast(null as string) as Objective,
  "Campaign Manager" as Platform,
  Cast(null as string) as Adset_Geo_Targeting,
  Cast(null as string) as Adset_Target_Platform,
  Cast(null as string) as Adset_Locales,
  Cast(null as string) as Impression_Device,
  Cast(null as INT64) as Video_Watch_30_sec
FROM
  `KimberlyClark_lao_MediaData.campaign_manager_performance_daily`
  WHERE date between '2020-01-01' and '{{backfill date}}'
  ),  
  
brazil_google_ads as (
SELECT
  date AS Date,
  "LAO" as Region, --- need to modify
  "Brazil" As Country,
  CASE
    WHEN REGEXP_CONTAINS(Campaign, 'Huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign, 'Intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign, 'Plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign, 'Duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign, 'Kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign, 'Neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign, 'huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign, 'intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign, 'plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign, 'duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign, 'kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign, 'neve') THEN 'Neve'
    ELSE 'Unknown'
  END as Brand,
  CASE
    WHEN REGEXP_CONTAINS(Campaign, 'Huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign, 'Intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'Plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'Duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'Kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'Neve') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign, 'intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign, 'duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign, 'neve') THEN 'FC'    
ELSE 'Unknown'
  END as Sector,
  cast(null as string) as Media_Type,
  CAST(Customer_ID__AdWords AS STRING) AS Account_ID, 
  Cast( Data_Source_name as string)  AS Account_Name,  
  CAST(Campaign as string) AS Campaign, 
  CAST( Ad_Group_Name__AdWords AS STRING) AS Ad_Group, 
  CAST( Keyword__AdWords AS STRING) AS Keyword, 
  CAST( Network__AdWords AS STRING) AS Network, 
  CAST( Network_With_Search_Params__AdWords AS STRING) AS Network_With_Search_Param, 
  CAST(Device__AdWords  as string) as Device,
  CAST(Impressions as INT64) AS Impressions,
  CAST(Clicks as INT64) AS Clicks,
  CAST(Interactions__AdWords as INT64) as Interactions,
  Cast(Engagements__AdWords as INT64) as Engagements,
  CAST(Cost__AdWords as float64) as Cost,
  cast(Quality_Score__AdWords As string) as Quality_Score,
  cast(Expanded_landing_page__AdWords as string) as Landing_Page,
  cast( Search_Impr__share___30_Day_Campaign__AdWords_1 as string) as Impression_Share,
  Cast(null as string) as Creative_Name,
  Cast(null as string) as Creative_Size,
  Cast(null as string) as Creative_Type,
  Cast(null as string) as Placement,
  Cast(null as string) as Advertiser_ID,
  Cast(null as string) as Advertiser,  
  CAST(Campaign_ID__AdWords AS STRING) AS Campaign_ID,
  Cast(null as string) as Activity,
  Cast(null as int64) as Video_Views,
  Cast(null as int64) as Video_Plays,
  Cast(null as int64) as Video_Watch_25_Percent,
  Cast(null as int64) as Video_Watch_50_Percent,
  Cast(null as int64) as Video_Watch_75_Percent,
  Cast(null as int64) as Video_Watch_100_Percent,
  CAST( Conversions__AdWords as float64) as Conversions,
  Cast(null as string) as Ad_Set,
  Cast(null as string) as Ad_Set_ID,
  Cast(null as string) as Ad_Name,
  Cast(null as string) as Ad_ID,
  Cast(null as string) as Objective,
  "Google Ads" as Platform, 
  Cast(null as string) as Adset_Geo_Targeting,
  Cast(null as string) as Adset_Target_Platform,
  Cast(null as string) as Adset_Locales,
  Cast(null as string) as Impression_Device,
  Cast(null as int64) as Video_Watch_30_sec
FROM
  `google_ads_performance_brazil.funnel_data_*`
  WHERE date between '2020-01-01' and '{{backfill date}}'
  ),
  
google_ads as (
SELECT
  date AS Date,
  "LAO" as Region,
    CASE
    WHEN REGEXP_CONTAINS( client_customer_name , 'Argentina') THEN 'Argentina'
    WHEN REGEXP_CONTAINS( client_customer_name  , 'Peru') THEN 'Peru'
    WHEN REGEXP_CONTAINS(client_customer_name  , 'Perú') THEN 'Peru'
    WHEN REGEXP_CONTAINS(client_customer_name , 'Colombia') THEN 'Colombia'
    WHEN REGEXP_CONTAINS( client_customer_name  , 'Chile') THEN 'Chile'
    WHEN REGEXP_CONTAINS( client_customer_name , 'Costa Rica') THEN 'Costa Rica'
    WHEN REGEXP_CONTAINS(client_customer_name  , 'argentina') THEN 'Argentina'
    WHEN REGEXP_CONTAINS(client_customer_name  , 'peru') THEN 'Peru'
    WHEN REGEXP_CONTAINS(client_customer_name , 'perú') THEN 'Peru'
    WHEN REGEXP_CONTAINS( client_customer_name  , 'colombia') THEN 'Colombia'
    WHEN REGEXP_CONTAINS( client_customer_name  , 'chile') THEN 'Chile'
    WHEN REGEXP_CONTAINS( client_customer_name , 'costa rica') THEN 'Costa Rica'   
ELSE 'Unknown'
  END as Country,
  CASE
    WHEN REGEXP_CONTAINS(Campaign_name, 'Huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Scott') THEN 'Scott'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kotex') THEN 'Kotex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Suave') THEN 'Suave'
    WHEN REGEXP_CONTAINS(Campaign_name, 'huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign_name, 'intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign_name, 'plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign_name, 'duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign_name, 'scott') THEN 'Scott'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kotex') THEN 'Kotex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'suave') THEN 'Suave'
    ELSE 'Unknown'
  END as Brand,
  CASE
    WHEN REGEXP_CONTAINS(Campaign_name, 'Huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Neve') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Scott') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kotex') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Suave') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'neve') THEN 'FC'   
    WHEN REGEXP_CONTAINS(Campaign_name, 'scott') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kotex') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'suave') THEN 'FC'
ELSE 'Unknown'
  END as Sector,
  cast(null as string) as Media_Type,
  CAST( client_customer_id AS STRING) AS Account_ID, 
  Cast( client_customer_name as string)  AS Account_Name,  
  CAST(Campaign_name as string) AS Campaign, 
  CAST( Ad_Group AS STRING) AS Ad_Group, 
  CAST( Keyword AS STRING) AS Keyword, 
  CAST( Network AS STRING) AS Network, 
  CAST( Network_With_Search_Partners AS STRING) AS Network_With_Search_Param, 
  CAST(Device  as string) as Device,
  CAST(Impressions as INT64) AS Impressions,
  CAST(Clicks as INT64) AS Clicks,
  CAST(Interactions as INT64) as Interactions, 
  Cast(Engagements as INT64) as Engagements, 
  CAST(Cost as float64) as Cost,
  cast(Quality_Score As string) as Quality_Score,
  cast(final_url as string) as Landing_Page,
  cast( Search_Impression_share as string) as Impression_Share, 
  Cast(null as string) as Creative_Name,
  Cast(null as string) as Creative_Size,
  Cast(null as string) as Creative_Type,
  Cast(null as string) as Placement,
  Cast(null as string) as Advertiser_ID,
  Cast(null as string) as Advertiser,  
  CAST(null AS STRING) AS Campaign_ID,
  Cast(null as string) as Activity,
  Cast(null as int64) as Video_Views,
  Cast(null as int64) as Video_Plays,
  Cast(null as int64) as Video_Watch_25_Percent,
  Cast(null as int64) as Video_Watch_50_Percent,
  Cast(null as int64) as Video_Watch_75_Percent,
  Cast(null as int64) as Video_Watch_100_Percent,
  CAST(null as float64) as Conversions,
  Cast(null as string) as Ad_Set,
  Cast(null as string) as Ad_Set_ID,
  Cast(null as string) as Ad_Name,
  Cast(null as string) as Ad_ID,
  Cast(null as string) as Objective,
  "Google Ads" as Platform, 
  Cast(null as string) as Adset_Geo_Targeting,
  Cast(null as string) as Adset_Target_Platform,
  Cast(null as string) as Adset_Locales,
  Cast(null as string) as Impression_Device,
  Cast(null as int64) as Video_Watch_30_sec
FROM
  `KimberlyClark_lao_MediaData.google_ads_performance_daily`
  WHERE date between '2020-01-01' and '{{backfill date}}'
  ),
  
brazil_facebook_ads as (
SELECT
  date AS Date,
  "LAO" as Region,
  "Brazil" As Country,
  CASE
    WHEN REGEXP_CONTAINS(Data_source_name, 'Huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Data_source_name, 'huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Data_source_name, 'intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Data_source_name, 'plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Data_source_name, 'duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Data_source_name, 'kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Data_source_name, 'neve') THEN 'Neve'
    ELSE 'Unknown'
  END as Brand,
  CASE
    WHEN REGEXP_CONTAINS(Data_source_name, 'Huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'Neve') THEN 'FC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Data_source_name, 'neve') THEN 'FC'    
ELSE 'Unknown'
  END as Sector,
  cast(null as string) as Media_Type,
  CAST(Ad_Account_ID__Facebook_Ads as string) AS Account_ID,
  Cast( Data_Source_name as string)  AS Account_Name, 
  CAST(Campaign as string) AS Campaign, 
  Cast(null as string) AS Ad_Group, 
  Cast(null as string) AS Keyword, 
  Cast(null as string) AS Network, 
  Cast(null as string) AS Network_With_Search_Param, 
  CAST(Device_Platform__Facebook_Ads as string) as Device,
  CAST(Impressions as INT64) AS Impressions,
  CAST(Clicks as INT64) AS Clicks,
  Cast(null as INT64) as Interactions,
  Cast(null as INT64) as Engagements,
  CAST(Amount_Spent__Facebook_Ads as float64) as Cost,
  Cast(null as string) as Quality_Score,
  Cast(null as string) as Landing_Page,
  Cast(null as string) as Impression_Share,
  Cast(null as string) as Creative_Name,
  Cast(null as string) as Creative_Size,
  Cast(null as string) as Creative_Type,
  Cast(null as string) as Placement,
  Cast(null as string) as Advertiser_ID,
  Cast(null as string) as Advertiser,  
  CAST( Campaign_ID__Facebook_Ads AS STRING) AS Campaign_ID,
  Cast(null as string) as Activity,
  Cast(null as int64) as Video_Views,
  CAST(Video_Plays__Facebook_Ads as INT64) as Video_Plays,
  CAST(Video_Watches_at_25__Facebook_Ads as INT64) as Video_Watch_25_Percent,
  CAST(Video_Watches_at_50__Facebook_Ads as INT64) as Video_Watch_50_Percent,
  CAST( Video_Watches_at_75__Facebook_Ads as INT64) as Video_Watch_75_Percent,
  CAST(Video_Watches_at_100__Facebook_Ads as INT64) as Video_Watch_100_Percent,
  CAST(Website_Conversions__Facebook_Ads as FLOAT64) as Conversions,
  CAST(Ad_Set_Name__Facebook_Ads as string) as Ad_Set,
  CAST(Ad_Set_ID__Facebook_Ads as string) as Ad_Set_ID,
  CAST(Ad_Name__Facebook_Ads as string) as Ad_Name,
  CAST(Ad_ID__Facebook_Ads as string) as Ad_ID,
  CAST(Campaign_Objective__Facebook_Ads as string) as Objective,
  "Facebook" as Platform, 
  Cast(null as string) as Adset_Geo_Targeting,
  Cast(null as string) as Adset_Target_Platform,
  Cast(null as string) as Adset_Locales,
  CAST(Impression_Device__Facebook_Ads as string) as Impression_Device,
  CAST(n_30_Second_Video_Views__Facebook_Ads as INT64) as Video_Watch_30_sec
FROM
  `facebook_ads_performance_brazil.funnel_data_*`
  WHERE date between '2020-01-01' and '{{backfill date}}'
  ),
facebook_ads as (

SELECT
  date_stop AS Date,
  "LAO" as Region,
  CASE
    WHEN REGEXP_CONTAINS( account_name , 'Argentina') THEN 'Argentina'
    WHEN REGEXP_CONTAINS( account_name , 'Peru') THEN 'Peru'
    WHEN REGEXP_CONTAINS( account_name , 'Perú') THEN 'Peru'
    WHEN REGEXP_CONTAINS( account_name , 'Colombia') THEN 'Colombia'
    WHEN REGEXP_CONTAINS( account_name , 'Chile') THEN 'Chile'
    WHEN REGEXP_CONTAINS( account_name , 'Costa Rica') THEN 'Costa Rica'
    WHEN REGEXP_CONTAINS( account_name , 'argentina') THEN 'Argentina'
    WHEN REGEXP_CONTAINS( account_name , 'peru') THEN 'Peru'
    WHEN REGEXP_CONTAINS( account_name , 'perú') THEN 'Peru'
    WHEN REGEXP_CONTAINS( account_name , 'colombia') THEN 'Colombia'
    WHEN REGEXP_CONTAINS( account_name , 'chile') THEN 'Chile'
    WHEN REGEXP_CONTAINS( account_name , 'costa rica') THEN 'Costa Rica'   
ELSE 'Unknown'
  END as Country,
  CASE
    WHEN REGEXP_CONTAINS(Campaign_name, 'Huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Scott') THEN 'Scott'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kotex') THEN 'Kotex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Suave') THEN 'Suave'
    WHEN REGEXP_CONTAINS(Campaign_name, 'huggies') THEN 'Huggies'
    WHEN REGEXP_CONTAINS(Campaign_name, 'intimus') THEN 'Intimus'
    WHEN REGEXP_CONTAINS(Campaign_name, 'plenitud') THEN 'Plenitud'
    WHEN REGEXP_CONTAINS(Campaign_name, 'duramax') THEN 'Duramax'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kleenex') THEN 'Kleenex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'neve') THEN 'Neve'
    WHEN REGEXP_CONTAINS(Campaign_name, 'scott') THEN 'Scott'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kotex') THEN 'Kotex'
    WHEN REGEXP_CONTAINS(Campaign_name, 'suave') THEN 'Suave'
    ELSE 'Unknown'
  END as Brand,
  CASE
    WHEN REGEXP_CONTAINS(Campaign_name, 'Huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Neve') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Scott') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Kotex') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'Suave') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'huggies') THEN 'BCC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'intimus') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'plenitud') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'duramax') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kleenex') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'neve') THEN 'FC'   
    WHEN REGEXP_CONTAINS(Campaign_name, 'scott') THEN 'FC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'kotex') THEN 'AFC'
    WHEN REGEXP_CONTAINS(Campaign_name, 'suave') THEN 'FC'
ELSE 'Unknown'
  END as Sector,
  cast(null as string) as Media_Type,
  CAST( account_id as string) AS Account_ID, 
  Cast( account_name as string)  AS Account_Name, 
  CAST(Campaign_name as string) AS Campaign, 
  Cast(null as string) AS Ad_Group, 
  Cast(null as string) AS Keyword, 
  Cast(null as string) AS Network, 
  Cast(null as string) AS Network_With_Search_Param, 
  CAST(Device_Platform as string) as Device,
  CAST(Impressions as INT64) AS Impressions,
  CAST(Clicks as INT64) AS Clicks,
  Cast(null as INT64) as Interactions,
  Cast(null as INT64) as Engagements,
  CAST(spend as float64) as Cost,
  Cast(null as string) as Quality_Score,
  Cast(null as string) as Landing_Page,
  Cast(null as string) as Impression_Share,
  Cast(null as string) as Creative_Name,
  Cast(null as string) as Creative_Size,
  Cast(null as string) as Creative_Type,
  Cast(null as string) as Placement,
  Cast(null as string) as Advertiser_ID,
  Cast(null as string) as Advertiser,  
  CAST( Campaign_ID AS STRING) AS Campaign_ID,
  Cast(null as string) as Activity,
  Cast(null as int64) as Video_Views,
  CAST(Video_Plays as INT64) as Video_Plays,
  CAST( video_watch_25_percent as INT64) as Video_Watch_25_Percent,
  CAST(video_watch_50_percent as INT64) as Video_Watch_50_Percent,
  CAST(video_watch_75_percent as INT64) as Video_Watch_75_Percent,
  CAST(video_watch_100_percent as INT64) as Video_Watch_100_Percent,
  CAST(null as FLOAT64) as Conversions, --check
  CAST(AdSet_Name as string) as Ad_Set,
  CAST(AdSet_ID as string) as Ad_Set_ID,
  CAST(Ad_Name as string) as Ad_Name,
  CAST(Ad_ID as string) as Ad_ID,
  CAST(objective as string) as Objective,
  "Facebook" as Platform, 
  Cast( adset_targeting_geo_locations as string) as Adset_Geo_Targeting,
  Cast( adset_targeting_publisher_platforms as string) as Adset_Target_Platform,
  Cast( adset_targeting_locales as string) as Adset_Locales,
  CAST( impression_device as string) as Impression_Device,
  CAST( video_watch_30_sec as INT64) as Video_Watch_30_sec
FROM
  `KimberlyClark_lao_MediaData.facebook_ads_performance_daily`
  WHERE date_stop between '2020-01-01' and '{{backfill date}}'
  )
  
  
  SELECT 
  *,
  CURRENT_DATETIME() as LoadTime
FROM (
  SELECT * from brazil_dv360
  UNION ALL SELECT * FROM brazil_google_ads
  UNION ALL SELECT * FROM google_ads
  UNION ALL SELECT * FROM brazil_facebook_ads
  UNION ALL SELECT * FROM facebook_ads
  UNION ALL SELECT * FROM CM
) where Brand != 'Unknown'
AND Country != 'Unknown'



