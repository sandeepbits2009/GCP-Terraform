WITH
dates as (
SELECT 
    CONCAT(FORMAT_DATETIME("%Y-%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01") as CM_FROM_CY ,
    FORMAT_DATETIME("%Y%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)) as CM_FROM_CY_YYMM,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH)) as CM_TO_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH)) as CM_TO_CY_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as YTD_FROM_CY,
    FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as date)) as YTD_FROM_CY_YYMM,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY_YYMM,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_CY,
	CONCAT(FORMAT_DATETIME("%Y-%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)),"-01") as LM_FROM_CY,
	FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_TO_CY,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as YTD_LY_FROM_CY,
	FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as date)) as YTD_LY_FROM_CY_YYMM,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 YEAR)), "01") as  R12_FROM_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as R12_TO_CY,
	CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)),'12') as LY_DEC,
  	CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)),'-12-01') as FROM_LY_DEC,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)),'-12-31') as TO_LY_DEC
FROM 
    (select current_date() as DATE_VALUE)

),
    
/* Shared data is taken from vw_sprinklr_daily view and the data is aggregated on month, brand, sector, country & region*/
  
SOURCE AS (

SELECT 
    'OWNED SOCIAL' as channel,
    Brand_Account as brand,
    (case when sector is null then '' else sector end) as sector,
	country_of_origin_account as country,
    region,
	Social_Network,
    FORMAT_DATETIME("%Y%m",date) as month,
    SUM(distinct Followers_SUM) as Followers,
	SUM(Post_Likes_And_Reactions_SUM) as Likes_And_Reactions,
	SUM(Post_Shares_SUM) as Shares,
	SUM(Total_Engagements_SUM) as Engagement,
	SUM(Total_Impressions_SUM) as Impressions,
    SUM(Post_Comments_SUM) as Comments,
      FROM kc_viz_owned_social.vw_sprinklr_daily
      where  
        date
         BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select YTD_TO_CY from dates) AS date)
      GROUP BY
        month,
        brand,
        sector,
		country_of_origin_account,
		region,
		Social_Network
),

/* Current month for Shared aggregated month wise(on month, brand, sector, country & region) */

CM as (
Select m.channel,m.brand,m.sector,m.country,m.region,m.Social_Network,m.month,f.Followers,m.Likes_And_Reactions,m.Shares,m.Engagement,m.Impressions,m.Comments from 
(SELECT 
    channel,brand,sector,country,region,Social_Network,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
    SUM(Followers) as Followers,
	SUM(Likes_And_Reactions) as Likes_And_Reactions,
	SUM(Shares) as Shares,
	SUM(Engagement) as Engagement,
	SUM(Impressions) as Impressions,
    SUM(Comments) as Comments,
      FROM SOURCE
      where  
        SOURCE.month  = (select CM_FROM_CY_YYMM from dates) 
      GROUP BY
        month,
		channel,
        brand,
        sector,
		country,
		region,
    Social_Network) m
left outer join 
(
select Brand_Account as brand,sector,country_of_origin_account as country,region,Social_Network,Followers from 
(select a.Brand_Account, (case when a.sector is null then '' else a.sector end) as	sector,a.country_of_origin_account	,a.region	,a.Social_Network,sum(distinct a.Followers_SUM) as Followers
from kc_viz_owned_social.vw_sprinklr_daily a
inner  join
(SELECT 
    Brand_Account as brand,(case when sector is null then '' else sector end) as sector,country_of_origin_account as country,region,Social_Network,
    max(date) as month
      FROM kc_viz_owned_social.vw_sprinklr_daily
      where  
        date
         BETWEEN CAST((select CM_FROM_CY from dates) AS date) AND CAST((select CM_TO_CY from dates) AS date)
         --BETWEEN '2022-05-01' and '2022-05-31' 
         --and country_of_origin_account ='USA' --and Social_Network = 'Facebook' and brand_account='Huggies'
      GROUP BY
        brand,
        sector,
		    country_of_origin_account,
		    region,
		    Social_Network) b
    on 
a.Brand_Account=b.brand and
(case when a.sector is null then '' else a.sector end)=b.sector and
a.country_of_origin_account=b.country and
a.region=b.region and
a.social_network=b.social_network and
a.date=b.month
    where date
         BETWEEN CAST((select CM_FROM_CY from dates) AS date) AND CAST((select CM_TO_CY from dates) AS date)
         --BETWEEN '2022-05-01' and '2022-05-31'
--where country_of_origin_account ='USA' --and Social_Network = 'Facebook' and brand_account='Huggies' 
GROUP BY
brand_account,
sector,
country_of_origin_account,
region,
Social_Network)
) f
on 
m.brand=f.brand and
m.sector=f.sector and
m.country=f.country and
m.region=f.region and
m.social_network=f.social_network
),

/* last month's CM for Shared aggregated month wise(on month, brand, sector, country & region) */

LM as (

Select m.channel,m.brand,m.sector,m.country,m.region,m.Social_Network,m.month,f.Followers,m.Likes_And_Reactions,m.Shares,m.Engagement,m.Impressions,m.Comments from 
(SELECT 
    channel,brand,sector,country,region,Social_Network,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
    SUM(Followers) as Followers,
	SUM(Likes_And_Reactions) as Likes_And_Reactions,
	SUM(Shares) as Shares,
	SUM(Engagement) as Engagement,
	SUM(Impressions) as Impressions,
    SUM(Comments) as Comments,
      FROM SOURCE
      where  
        SOURCE.month  = (select LM_CY from dates) 
      GROUP BY
        month,
		channel,
        brand,
        sector,
		country,
		region,
    Social_Network) m
left outer join 
(
select Brand_Account as brand,sector,country_of_origin_account as country,region,Social_Network,Followers from 
(select a.Brand_Account, (case when a.sector is null then '' else a.sector end) as	sector,a.country_of_origin_account	,a.region	,a.Social_Network,sum(distinct a.Followers_SUM) as Followers
from kc_viz_owned_social.vw_sprinklr_daily a
inner  join
(SELECT 
    Brand_Account as brand,(case when sector is null then '' else sector end) as sector,country_of_origin_account as country,region,Social_Network,
    max(date) as month
      FROM kc_viz_owned_social.vw_sprinklr_daily
      where  
        date
         BETWEEN CAST((select LM_FROM_CY from dates) AS date) AND CAST((select LM_TO_CY from dates) AS date)
      GROUP BY
        brand,
        sector,
		country_of_origin_account,
		region,
		Social_Network) b
    on 
a.Brand_Account=b.brand and
(case when a.sector is null then '' else a.sector end)=b.sector and
a.country_of_origin_account=b.country and
a.region=b.region and
a.social_network=b.social_network and
a.date=b.month
    where date
         BETWEEN CAST((select LM_FROM_CY from dates) AS date) AND CAST((select LM_TO_CY from dates) AS date)
GROUP BY
brand_account,
sector,
country_of_origin_account,
region,
Social_Network)
) f
on 
m.brand=f.brand and
m.sector=f.sector and
m.country=f.country and
m.region=f.region and
m.social_network=f.social_network

),

/* Year to date(YTD) for for Shared aggregated month wise(on month, brand, sector, country & region) */

YTD as (

SELECT 
    channel,
    brand,
    sector,
	country,
	region,
	Social_Network,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
    --SUM(Followers) as Followers,
	SUM(Likes_And_Reactions) as Likes_And_Reactions,
	SUM(Shares) as Shares,
	SUM(Engagement) as Engagement,
	SUM(Impressions) as Impressions,
    SUM(Comments) as Comments,
      FROM SOURCE
      where  
        SOURCE.month BETWEEN (select YTD_FROM_CY_YYMM from dates) AND (select YTD_TO_CY_YYMM from dates)
      GROUP BY
        month,
		channel,
        brand,
        sector,
		country,
		region,
    Social_Network

),
YTD_F as (
Select m.channel,m.brand,m.sector,m.country,m.region,m.Social_Network,m.month,f.Followers from 
(SELECT 
    channel,brand,sector,country,region,Social_Network,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
      FROM SOURCE
      where  
        SOURCE.month  = (select LY_DEC from dates) 
      GROUP BY
        month,
		channel,
        brand,
        sector,
		country,
		region,
    Social_Network) m
left outer join 
(
select Brand_Account as brand,sector,country_of_origin_account as country,region,Social_Network,Followers from 
(select a.Brand_Account, (case when a.sector is null then '' else a.sector end) as	sector,a.country_of_origin_account	,a.region	,a.Social_Network,sum(distinct a.Followers_SUM) as Followers
from kc_viz_owned_social.vw_sprinklr_daily a
inner  join
(SELECT 
    Brand_Account as brand,(case when sector is null then '' else sector end) as sector,country_of_origin_account as country,region,Social_Network,
    max(date) as month
      FROM kc_viz_owned_social.vw_sprinklr_daily
      where  
        date
         BETWEEN CAST((select FROM_LY_DEC from dates) AS date) AND CAST((select TO_LY_DEC from dates) AS date)
      GROUP BY
        brand,
        sector,
		    country_of_origin_account,
		    region,
		    Social_Network) b
    on 
a.Brand_Account=b.brand and
(case when a.sector is null then '' else a.sector end)=b.sector and
a.country_of_origin_account=b.country and
a.region=b.region and
a.social_network=b.social_network and
a.date=b.month
    where date
         BETWEEN CAST((select FROM_LY_DEC from dates) AS date) AND CAST((select TO_LY_DEC from dates) AS date)
GROUP BY
brand_account,
sector,
country_of_origin_account,
region,
Social_Network)
) f
on 
m.brand=f.brand and
m.sector=f.sector and
m.country=f.country and
m.region=f.region and
m.social_network=f.social_network
),
/* Year to date(YTD) of last year for for Shared aggregated month wise(on month, brand, sector, country & region) */

YTD_LY as (

Select m.channel,m.brand,m.sector,m.country,m.region,m.Social_Network,m.month,f.Followers,m.Likes_And_Reactions,m.Shares,m.Engagement,m.Impressions,m.Comments from 
(SELECT 
    channel,brand,sector,country,region,Social_Network,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
    SUM(Followers) as Followers,
	SUM(Likes_And_Reactions) as Likes_And_Reactions,
	SUM(Shares) as Shares,
	SUM(Engagement) as Engagement,
	SUM(Impressions) as Impressions,
    SUM(Comments) as Comments,
      FROM SOURCE
      where  
        SOURCE.month BETWEEN (select YTD_LY_FROM_CY_YYMM from dates) AND (select YTD_LY_TO_CY_YYMM from dates) 
      GROUP BY
        month,
		channel,
        brand,
        sector,
		country,
		region,
    Social_Network) m
left outer join 
(
select Brand_Account as brand,sector,country_of_origin_account as country,region,Social_Network,Followers from 
(select a.Brand_Account, (case when a.sector is null then '' else a.sector end) as	sector,a.country_of_origin_account	,a.region	,a.Social_Network,sum(distinct a.Followers_SUM) as Followers
from kc_viz_owned_social.vw_sprinklr_daily a
inner  join
(SELECT 
    Brand_Account as brand,(case when sector is null then '' else sector end) as sector,country_of_origin_account as country,region,Social_Network,
    max(date) as month
      FROM kc_viz_owned_social.vw_sprinklr_daily
      where  
        date
         BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select YTD_LY_TO_CY from dates) AS date)
      GROUP BY
        brand,
        sector,
		country_of_origin_account,
		region,
		Social_Network) b
    on 
a.Brand_Account=b.brand and
(case when a.sector is null then '' else a.sector end)=b.sector and
a.country_of_origin_account=b.country and
a.region=b.region and
a.social_network=b.social_network and
a.date=b.month
    where date
         BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select YTD_LY_TO_CY from dates) AS date)
GROUP BY
brand_account,
sector,
country_of_origin_account,
region,
Social_Network)
) f
on 
m.brand=f.brand and
m.sector=f.sector and
m.country=f.country and
m.region=f.region and
m.social_network=f.social_network

),

combination AS (
  SELECT
    DISTINCT
      month,
      channel,
      brand,
      sector,
	  country,
	  region,
	  Social_Network
    FROM CM)

SELECT
  concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
  c.channel,
  c.country,
  c.region,
  c.brand,
  c.sector,
  c.Social_Network,
  
      /* MONTHLY DATA */
  CM.Followers as Followers_CM,
  CM.Likes_And_Reactions as Likes_And_Reactions_CM,
  CM.Shares as Shares_CM,
  CM.Engagement as Engagement_CM,
  CM.Impressions as Impressions_CM,
  CM.Comments as Comments_CM,
  
      /* LAST MONTH DATA */
  LM.Followers as Followers_LM,
  LM.Likes_And_Reactions as Likes_And_Reactions_LM,
  LM.Shares as Shares_LM,
  LM.Engagement as Engagement_LM,
  LM.Impressions as Impressions_LM,
  LM.Comments as Comments_LM,
  
      /* YTD DATA */
  (CASE WHEN YTD_F.Followers IS NULL THEN CM.Followers ELSE (CM.Followers - YTD_F.Followers) END ) AS Followers_YTD,
  YTD.Likes_And_Reactions as Likes_And_Reactions_YTD,
  YTD.Shares as Shares_YTD,
  YTD.Engagement  as Engagement_YTD,
  YTD.Impressions as Impressions_YTD,
  YTD.Comments as Comments_YTD,
 
      /* YTD_LY DATA */
  YTD_LY.Followers as Followers_YTD_LY,
  YTD_LY.Likes_And_Reactions as Likes_And_Reactions_YTD_LY,
  YTD_LY.Shares as Shares_YTD_LY,
  YTD_LY.Engagement as Engagement_YTD_LY,
  YTD_LY.Impressions as Impressions_YTD_LY,
  YTD_LY.Comments as Comments_YTD_LY
  	     
  FROM
    combination c
  LEFT OUTER JOIN
    CM
  ON
    c.month   = CM.month      and
    c.brand   = CM.brand      and
    c.sector  = CM.sector     and
    c.channel = CM.channel    and
    c.country = CM.country    and
    c.region  = CM.region     and
    c.Social_Network = CM.Social_Network	
  LEFT OUTER JOIN           
    LM                        
  ON                          
    c.month   = LM.month      and
    c.brand   = LM.brand      and
    c.sector  = LM.sector     and
    c.channel = LM.channel    and
    c.country = LM.country    and
    c.region  = LM.region     and
    c.Social_Network = LM.Social_Network	
  LEFT OUTER JOIN         
    YTD                       
  ON                          
    c.month   = YTD.month     and
    c.brand   = YTD.brand     and
    c.sector  = YTD.sector    and
    c.channel = YTD.channel    and
    c.country = YTD.country    and
    c.region  = YTD.region     and
    c.Social_Network = YTD.Social_Network	 	
  LEFT OUTER JOIN
    YTD_LY
  ON
    c.month   = YTD_LY.month    and
    c.brand   = YTD_LY.brand    and
    c.sector  = YTD_LY.sector   and
    c.channel = YTD_LY.channel  and
    c.country = YTD_LY.country  and
    c.region  = YTD_LY.region   and
    c.Social_Network = YTD_LY.Social_Network
  LEFT OUTER JOIN
    YTD_F
  ON
    c.month   = YTD_F.month    and
    c.brand   = YTD_F.brand    and
    c.sector  = YTD_F.sector   and
    c.channel = YTD_F.channel  and
    c.country = YTD_F.country  and
    c.region  = YTD_F.region   and
    c.Social_Network = YTD_F.Social_Network
where c.region not in ('AUS')