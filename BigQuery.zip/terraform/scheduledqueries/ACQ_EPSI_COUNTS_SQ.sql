


--insert into sfmc_crm_onepd.CV_MAP_ACQUISITION_COUNT_F_EPSI
-------------------------------------------------------------
---Change dataset name evreywhere
with 
base as
(
	select 
	TIMESTAMP,
    case when REGION='AUS' then 'APAC' else REGION end as REGION,
	IS_CONTACTABLE,COUNTRYCODE,SECTOR,BRAND,AGE_IN_MONTHS,
	sum(NO_OF_CONSUMERS) as NO_OF_CONSUMERS,
	sum(TOT_DOB) as TOT_DOB,
	sum(NO_OF_CONSUMERS) as TOT_CONSUMER
	
	from
	sfmc_crm_onepd.F_ACQUISITION_BYAGE_EPSI_VALIDATED
	where REGION="KCNA" and TIMESTAMP >="2021-03-31" and BRAND != 'NA' and TIMESTAMP=last_day(date_sub(CURRENT_DATE(), interval 1 month))
	group by 
	TIMESTAMP,REGION,IS_CONTACTABLE,COUNTRYCODE,SECTOR,BRAND,AGE_IN_MONTHS
),
time_dimension as 
(
	select 
	DATE_SQL,
    YEAR as YEAR_ACQ_COUNT,
    QUARTER as QUARTER_ACQ_COUNT,
    MONTH as MONTH_ACQ_COUNT,
    WEEK as WEEK_ACQ_COUNT
	
	from sfmc_crm_onepd.time_dimension
	
	----Filtering records to only within range of last 14 months
	where DATE_SQL  between last_day(date_sub(CURRENT_DATE(), interval 14 month)) and last_day(date_sub(CURRENT_DATE(), interval 1 month))
),
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
---Aggeregating without is_contactable field to prepare data for customer count correction
---This query shouldn't have is_contactable
cc_correction as
(
    select 
	TIMESTAMP,REGION,COUNTRYCODE,SECTOR,BRAND,AGE_IN_MONTHS,
	sum(NO_OF_CONSUMERS) as NO_OF_CONSUMERS_CC,
	sum(TOT_CONSUMER) as TOT_CONSUMER_CC
	
	from
	base
	where REGION="KCNA" and TIMESTAMP >="2021-03-31" and BRAND != 'NA' and TIMESTAMP=last_day(date_sub(CURRENT_DATE(), interval 1 month))
	
	group by 
	TIMESTAMP,REGION,COUNTRYCODE,SECTOR,BRAND,AGE_IN_MONTHS

)

select 
TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,
YEAR_ACQ_COUNT,QUARTER_ACQ_COUNT,MONTH_ACQ_COUNT,WEEK_ACQ_COUNT,
SECTOR,REGION,BRAND,AGE_IN_MONTHS,
CASE WHEN COUNTRYCODE IN ('GB','UK') THEN 'United Kingdom' 
     WHEN COUNTRYCODE = 'UN' THEN 'Unknown'
     ELSE Country_Code_Desc END AS COUNTRYCODE_DESC ,

FLOOR(AGE_IN_MONTHS/12) as CC_AGE_IN_YEAR,
case when UPPER(IS_CONTACTABLE) in ('Y','TRUE') then 'With Opt-In' else 'Total' end as CC_CONTACTABLE,
case 
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<=-7 then '-9 TO -7 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-6 AND AGE_IN_MONTHS<=-4 then '-6 TO -4 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-3 AND AGE_IN_MONTHS<=-1 then '-3 TO -1 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<=2 then '0 TO 2 M'
when SECTOR = 'BCC' AND REGION!='KCNA' AND AGE_IN_MONTHS>=3 AND AGE_IN_MONTHS<=5 then '3 TO 5 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<=8 then '6 TO 8 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=9 AND AGE_IN_MONTHS<=11 then '9 TO 11 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=12 AND AGE_IN_MONTHS<=14 then '12 TO 14 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=15 AND AGE_IN_MONTHS<=17 then '15 TO 17 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=18 AND AGE_IN_MONTHS<=20 then '18 TO 20 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=21 AND AGE_IN_MONTHS<=23 then '21 TO 23 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=24 AND AGE_IN_MONTHS<=26 then '24 TO 26 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=27 AND AGE_IN_MONTHS<=29 then '27 TO 29 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=30 AND AGE_IN_MONTHS<=32 then '30 TO 32 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=33 AND AGE_IN_MONTHS<=35 then '33 TO 35 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'NO DUE DATE/DOB' else '' end as CC_Journey,

case when AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<0 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_PREGNANT_9_TO_0,

case
when COUNTRYCODE in ('US','CA') and AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 then CC_NO_OF_CONSUMERS
when COUNTRYCODE not in ('US','CA') and AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<6 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_NEW_BORN_0_TO_6,

case when AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_ACTIVE_BABY_6_TO_36,
case when AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!=999999999 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MORE_36 ,
case when AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS<39 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_36_TO_39,
case when AGE_IN_MONTHS>=39 AND AGE_IN_MONTHS<42 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_39_TO_42,
case when AGE_IN_MONTHS>=42 AND AGE_IN_MONTHS<45 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_42_TO_45,
case when AGE_IN_MONTHS>=45 AND AGE_IN_MONTHS<48 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_45_TO_48,
case when AGE_IN_MONTHS>=48 AND AGE_IN_MONTHS<51 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_48_TO_51,
case when AGE_IN_MONTHS>=51 AND AGE_IN_MONTHS<54 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_51_TO_54,
case when AGE_IN_MONTHS>=54 AND AGE_IN_MONTHS<57 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_54_TO_57,
case when AGE_IN_MONTHS>=57 AND AGE_IN_MONTHS<60 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_MONTH_57_TO_60,
case when AGE_IN_MONTHS>=60 AND AGE_IN_MONTHS<72 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_5_TO_6,
case when AGE_IN_MONTHS>=72 AND AGE_IN_MONTHS<84 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_6_TO_7,
case when AGE_IN_MONTHS>=84 AND AGE_IN_MONTHS<96 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_7_TO_8,
case when AGE_IN_MONTHS>=96 AND AGE_IN_MONTHS<108 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_8_TO_9,
case when AGE_IN_MONTHS>=108 AND AGE_IN_MONTHS<120 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_9_TO_10,
case when AGE_IN_MONTHS>=120 AND AGE_IN_MONTHS<132 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_10_TO_11,
case when AGE_IN_MONTHS>=132 AND AGE_IN_MONTHS<144 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_11_TO_12,
case when AGE_IN_MONTHS>=-12 AND AGE_IN_MONTHS<0 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR__1_TO_0,
case when AGE_IN_MONTHS>=0 	AND AGE_IN_MONTHS<12 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_0_TO_1,
case when AGE_IN_MONTHS>=12 AND AGE_IN_MONTHS<24 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_1_TO_2,
case when AGE_IN_MONTHS>=24 AND AGE_IN_MONTHS<36 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_2_TO_3,
case when AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS<48 then CC_NO_OF_CONSUMERS else 0 end as CC_TOT_YEAR_3_TO_4,

CC_TOT_CONSUMER as TOT_CONSUMER,
CC_NO_OF_CONSUMERS as NO_OF_CONSUMERS

from
    (
        select 
        base_CC_TD_map.TIMESTAMP,base_CC_TD_map.COUNTRYCODE,
        COALESCE(case when base_CC_TD_map.REGION='KCNA' and UPPER(IS_CONTACTABLE) IN ('FALSE','N') then TOT_CONSUMER_CC else TOT_CONSUMER end,0) as CC_TOT_CONSUMER,
        COALESCE(case when base_CC_TD_map.REGION='KCNA' and UPPER(IS_CONTACTABLE) IN ('FALSE','N') then NO_OF_CONSUMERS_CC else NO_OF_CONSUMERS end,0) as CC_NO_OF_CONSUMERS,
        IS_CONTACTABLE,
        base_CC_TD_map.BRAND,
		base_CC_TD_map.SECTOR,
		base_CC_TD_map.REGION,
		base_CC_TD_map.AGE_IN_MONTHS,
        Country_Code_Desc,
        YEAR_ACQ_COUNT,
		QUARTER_ACQ_COUNT,
		MONTH_ACQ_COUNT,
		WEEK_ACQ_COUNT
        from   
            (
                select 
                TIMESTAMP,COUNTRYCODE,TOT_CONSUMER,IS_CONTACTABLE,BRAND,SECTOR,REGION,AGE_IN_MONTHS,NO_OF_CONSUMERS,
                Country_Code_Desc,
                YEAR_ACQ_COUNT,QUARTER_ACQ_COUNT,MONTH_ACQ_COUNT,WEEK_ACQ_COUNT
                from
                    (
                        select 
                        TIMESTAMP,COUNTRYCODE,TOT_CONSUMER,IS_CONTACTABLE,BRAND,SECTOR,REGION,AGE_IN_MONTHS,NO_OF_CONSUMERS,
                        Country_Code_Desc
                        from 
                        base
                        left join 
                        country_desc desc_map
                        on
                        base.COUNTRYCODE=desc_map.country_code

                    ) base_CCmap
                left join 
                time_dimension TD_map
                on
                base_CCmap.TIMESTAMP=TD_map.DATE_SQL
            ) base_CC_TD_map
            left join 
            cc_correction C_correc
            on
            base_CC_TD_map.TIMESTAMP=C_correc.TIMESTAMP and
            base_CC_TD_map.COUNTRYCODE=C_correc.COUNTRYCODE and
            base_CC_TD_map.BRAND=C_correc.BRAND and
            base_CC_TD_map.SECTOR=C_correc.SECTOR and
            base_CC_TD_map.REGION=C_correc.REGION and
            base_CC_TD_map.AGE_IN_MONTHS=C_correc.AGE_IN_MONTHS
        )


