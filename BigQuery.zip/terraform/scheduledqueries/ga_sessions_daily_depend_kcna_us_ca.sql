WITH
  base AS (
  SELECT
    *
  FROM
    `231411647.ga_sessions_*` --- change table
  WHERE
    _TABLE_SUFFIX = FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 2 DAY)) ),
  sessions AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    clientId,
    visitNumber,
    visitStartTime,
    CONCAT(fullVisitorId, CAST(visitStartTime AS INT64)) AS SessionId,
    SUM(totals.visits) AS Sessions,
    SUM(totals.pageviews) AS Pageviews,
    SUM(totals.bounces) AS Bounces,
    SUM(totals.timeOnSite) AS timeOnSite
  FROM
    base b
  GROUP BY
    1,
    2,
    3,
    4,
    5 ),
  users AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    CONCAT(fullVisitorId, CAST(visitStartTime AS INT64)) AS SessionId,
    clientId,
    fullVisitorId,
    visitNumber,
    COUNT(DISTINCT fullVisitorId) AS UsersD,
    COUNT(DISTINCT(
        CASE
          WHEN totals.newVisits = 1 THEN fullVisitorId
        ELSE
        NULL
      END
        )) / COUNT(DISTINCT CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))) AS PercentageNewSessions,
    COUNT(DISTINCT(CASE
          WHEN totals.newVisits = 1 THEN fullVisitorId
        ELSE
        NULL
      END
        )) AS NewUsers,
    COUNT(DISTINCT CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))) / COUNT(DISTINCT fullVisitorId) AS SessionsPerUser,
  FROM
    base
  GROUP BY
    1,
    2,
    3,
    4,
    5 ),
  landingPage AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    clientId,
    CONCAT(fullVisitorId, CAST(visitStartTime AS INT64)) AS SessionId,
    channelGrouping AS Channel,
    trafficSource.source AS Source,
    trafficSource.medium AS Medium,
    trafficSource.campaign AS Campaign,
    geoNetwork.country AS GACountry,
    geoNetwork.region AS Region,
    geoNetwork.city AS City,
    hitNumber,
    page.pagePath AS LandingPage,
    page.pageTitle AS LandingPageTitle,
    device.deviceCategory AS DeviceCategory,
  FROM
    base,
    UNNEST(hits) AS hits
  WHERE
    hits.isEntrance = TRUE
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14),
  output AS (
  SELECT
    s.Date,
    "231411647" AS GAViewID, --- change GAviewID
    "Depend" AS Brand, --- change Brand
    "KCNA" AS Region, --- change Region
    "AFC" AS Sector, --- change Sector
    "KCNA" AS WebsiteCountry, --- change Argentina
    s.SessionId,
    GACountry,
    Region as GARegion,
    Channel,
    Source,
    Medium,
    Campaign,
    City,
    LandingPage.LandingPage,
    LandingPageTitle,
    DeviceCategory,
    s.clientId,
    IFNULL(SUM(Sessions),
      0) AS Sessions,
    IFNULL(SUM(Pageviews),
      0) AS Pageviews,
    IFNULL(SUM(Bounces),
      0) AS Bounces,
    SUM(NewUsers) AS NewUsers,
  IF
    (timeOnSite IS NULL,
      0,
      timeOnSite) AS TimeOnSiteInSeconds
  FROM
    sessions s
  LEFT JOIN
    users
  ON
    s.SessionId = users.SessionId
    AND s.Date = users.Date
  LEFT JOIN
    landingPage
  ON
    s.SessionId = landingPage.SessionId
    AND s.Date = landingPage.Date
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    23)

,language AS (
SELECT  Date, fullVisitorId,Sessionsid , MAX(COUNTRYCODE) COUNTRYCODE, MAX(lang) AS lang FROM  (
SELECT distinct
    PARSE_DATE("%Y%m%d", date) AS Date,
fullVisitorId,
 CONCAT(fullVisitorId, CAST(visitStartTime AS STRING)) AS Sessionsid
 ,  CASE
        WHEN  hits.page.pagePath LIKE '%en-us%' THEN 'US'
        WHEN  hits.page.pagePath LIKE '%en-ca%' THEN 'CA'
        WHEN  hits.page.pagePath LIKE '%es-us%' THEN 'US'
        WHEN  hits.page.pagePath LIKE '%fr-ca%' THEN 'CA'
      ELSE
      NULL
    END
      AS COUNTRYCODE,
       CASE
        WHEN  hits.page.pagePath LIKE '%en-us%' THEN 'EN'
        WHEN  hits.page.pagePath LIKE '%en-ca%' THEN 'EN'
        WHEN  hits.page.pagePath LIKE '%es-us%' THEN 'ES'
        WHEN  hits.page.pagePath LIKE '%fr-ca%' THEN 'FR'
      ELSE
      NULL
    END
      AS lang,
      hits.page.pagePathLevel2,hitNumber
FROM
  `231411647.ga_sessions_*`, UNNEST(hits) as hits
WHERE
  _TABLE_SUFFIX = FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 2 DAY)) 
) group by 1,2,3
)

SELECT  
output.Date
,output.GAViewID
,output.Brand
,output.Region
,output.Sector
,output.WebsiteCountry
,language.COUNTRYCODE  AS CountryCode
,language.LANG AS Language
,output.SessionId
,output.GACountry
,output.GARegion
,output.Channel
,output.Source
,output.Medium
,output.Campaign
,output.City
,output.LandingPage
,output.LandingPageTitle
,output.DeviceCategory
,output.clientId
,output.Sessions
,output.Pageviews
,output.Bounces
,output.NewUsers
,output.TimeOnSiteInSeconds
FROM
  output LEFT JOIN language ON  output.DATE = language.DATE AND  output.Sessionid= language.Sessionsid