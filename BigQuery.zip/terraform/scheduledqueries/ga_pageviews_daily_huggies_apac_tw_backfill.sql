
WITH
  ga_data AS (
  SELECT
    *
  FROM
    `hmp-emea-reporting.233959541.ga_sessions_*` --- change table
  WHERE
     _TABLE_SUFFIX between '20190101' and '20210313'), --- date for backfill dependent on when pushed to production
  session_info AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    geoNetwork.country AS GACountry,
    geoNetwork.region AS Region,
    geoNetwork.city AS City,
    clientId,
    CONCAT(fullVisitorId, CAST(visitStartTime AS string)) AS SessionId,
    hits.page.pagePath AS Page,
    hits.page.pageTitle AS PageTitle,
    hits.hitNumber,
    hits.isEntrance,
    hits.isExit,
  IF
    (totals.bounces IS NOT NULL,
      1,
      0) AS bounces,
    MIN(
    IF
      (hits.isInteraction,
        hits.hitNumber,
        0)) OVER (PARTITION BY fullVisitorId, visitStartTime) AS FirstHitNumber,
    hits.time AS HitTime,
    LEAD(hits.time) OVER (PARTITION BY fullVisitorId, visitStartTime ORDER BY hits.time) AS NextPageviewTime
  FROM
    ga_data,
    UNNEST(hits) AS hits
  WHERE
    hits.type = 'PAGE' ),
  -- Last interaction must be computed separately as a non-interactive event
  -- after the last pageview of a session can give us an indication of how long
  -- someone spend on that final page.
  last_interaction AS (
  SELECT
    Date,
    Region,
    GACountry,
    City,
    SessionId,
    LastInteractionTime
  FROM (
    SELECT
      PARSE_DATE("%Y%m%d",
        date) AS Date,
      geoNetwork.country AS GACountry,
      geoNetwork.region AS Region,
      geoNetwork.city AS City,
      CONCAT(fullVisitorId, CAST(visitStartTime AS string)) AS SessionId,
      MAX(
      IF
        (hits.isInteraction,
          hits.time,
          0)) OVER (PARTITION BY fullVisitorId, visitStartTime) AS LastInteractionTime
    FROM
      ga_data,
      UNNEST(hits) AS hits )
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6 ),
  unique_pageviews AS (
  SELECT
    Date,
    Region,
    GACountry,
    City,
    pagePath,
    PageTitle, ------- add page title
    COUNT(DISTINCT session_id) AS UniquePageviews
  FROM (
    SELECT
      PARSE_DATE("%Y%m%d",
        date) AS Date,
      geoNetwork.region AS Region,
      geoNetwork.country AS GACountry,
      geoNetwork.city AS City,
      hits.page.pagePath,
      hits.page.pageTitle as PageTitle, ------- add page title
      CONCAT(fullVisitorId, CAST(visitStartTime AS STRING)) AS session_id
    FROM
      ga_data,
      UNNEST(ga_data.hits) AS hits
    WHERE
      hits.type = 'PAGE')
  GROUP BY
    1,
    2,
    3,
    4,
    5
    ,6 ------- add group by
  ORDER BY
    UniquePageviews DESC),
  page_load AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    hits.page.pagePath AS pagePath,
    geoNetwork.country AS GACountry,
    geoNetwork.region AS Region,
    geoNetwork.city AS City,
    SUM(
    IF
      (hits.latencyTracking.pageLoadTime IS NOT NULL,
        (SAFE_CAST(hits.latencyTracking.pageLoadTime AS FLOAT64)) / 1000,
        NULL)) AS SumOfPageLoadTimeInSeconds,
     SUM(hits.latencyTracking.pageLoadSample) AS SumOfPageLoadSample,
  FROM
    ga_data,
    UNNEST(hits) AS hits
  GROUP BY
    1,
    2,
    3,
    4,
    5 ),
  output AS (
  SELECT
    Date,
    CURRENT_DATETIME() AS LoadTime,
    Region,
    GACountry,
    City,
    Page,
    PageTitle,
    COUNT(Page) AS Pageviews,
    SUM(
    IF
      (isEntrance,
        1,
        0)) AS Entrances,
    SUM(
    IF
      (isExit,
        1,
        0)) AS Exit,
    SUM(bounces) AS Bounces,
    CAST(SUM(TimeOnPage) AS INT64) AS TimeOnPageInSeconds,
    TIME_ADD(TIME(0,
        0,
        0),
      INTERVAL SAFE_CAST(SUM(TimeOnPage) AS INT64) SECOND) AS TimeOnPage,
    TIME_ADD(TIME(0,
        0,
        0),
      INTERVAL SAFE_CAST(SAFE_DIVIDE(SUM(TimeOnPage),
          COUNT(Page) - SUM(
          IF
            (isExit,
              1,
              0))) AS INT64) SECOND) AS AvgTimeOnPage
  FROM (
    SELECT
      si.*,
      SAFE_DIVIDE(
      IF
        (NextPageviewTime IS NOT NULL,
          NextPageviewTime,
          LastInteractionTime) - HitTime,
        1000) AS TimeOnPage
    FROM
      session_info si
    LEFT JOIN
      last_interaction li
    ON
      si.Date = li.Date
      AND si.SessionId = li.SessionId
      AND si.Region = li.Region
      AND si.GACountry = li.GACountry
      AND si.City = li.City )
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7
  ORDER BY
    Pageviews DESC)
SELECT
  output.Date,
  CURRENT_DATETIME() AS LoadTime,
    "233959541" AS GAViewID, --- change GAviewID
    "Huggies" AS Brand, --- change Brand
    "APAC" AS Region, --- change Region
    "BCC" AS Sector, --- change Sector
    "Taiwan" AS WebsiteCountry, --- change Argentina
    "TW" as CountryCode, --- change CountryCode
  output.Region as GARegion,
  output.GACountry,
  output.City,
  Page,
  output.PageTitle, ------------- add output
  SUM(Pageviews) AS Pageviews,
  SUM(UniquePageviews) AS UniquePageviews,
  SUM(entrances) AS Entrances,
  SUM(exit) AS Exit,
  SUM(bounces) AS Bounces,
SUM(SumOfPageLoadTimeInSeconds) AS SumOfPageLoadTimeInSeconds,
SUM(SumOfPageLoadSample) AS SumOfPageLoadSample,
  SUM(TimeOnPageInSeconds) AS TimeOnPageInSeconds,
  TimeOnPage AS TimeOnPage,
  AvgTimeOnPage AS AvgTimeOnPage
FROM
  output
LEFT JOIN
  unique_pageviews up
ON
  output.Date = up.Date
  AND output.Page = up.pagePath
  AND IFNULL(output.PageTitle, '~') = ifnull(up.PageTitle, '~')
  AND output.Region = up.Region
  AND output.GACountry = up.GACountry
  AND output.City = up.City
LEFT JOIN
  page_load pl
ON
  output.Date = pl.Date
  AND output.Page = pl.pagePath
    AND output.Region = pl.Region
  AND output.GACountry = pl.GACountry
  AND output.City = pl.City
GROUP BY
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  22,
  23

