

with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `hmp-emea-reporting.sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
sends_base as
(
SELECT 
distinct
case when Country in ('AU','NZ') then 'APAC' else Region end as Region, 
case when Country='UK' then 'GB' else Country end as country_code, 
SubscriberID as subscriber_id , 
Case when UPPER(BRAND)='GOODNITES' then 'GoodNites'
when UPPER(BRAND)='PULL-UPS' then 'Pull-Ups'
when UPPER(BRAND)='VIVA' then 'Viva'
when UPPER(BRAND)='SCOTT' then 'Scott'
when UPPER(BRAND)='KLEENEX' then 'Kleenex'
when UPPER(BRAND)='COTTONELLE' then 'Cottonelle'
when UPPER(BRAND)='DEPEND' then 'Depend'
when UPPER(BRAND)='POISE' then 'Poise'
when UPPER(BRAND)='UBYKOTEX' then 'UByKotex'
when UPPER(BRAND)='HUGGIES' then 'Huggies'
when UPPER(BRAND)='PLENITUD' then 'Plenitud'
when UPPER(BRAND)='ANDREX' then 'Andrex'
when UPPER(BRAND)='SHIKMA' then 'Shikma'
when UPPER(BRAND)='TITULIM' then 'Titulim'
when UPPER(BRAND)='MOLETT' then 'Molett'
when UPPER(BRAND)='LILY' then 'Lily'
when UPPER(BRAND)='NIKOL' then 'Nikol'
when UPPER(BRAND)='INTIMUS' then 'Intimus'
when UPPER(BRAND)='HAKLE' then 'Hakle'
when UPPER(BRAND)='SCOTTEX' then 'Scottex'
when UPPER(BRAND)='LAVIE' then 'Lavie'
when UPPER(BRAND)='NALAVIE' then 'Lavie'
when UPPER(BRAND)='NEVE' then 'Neve'
when UPPER(BRAND)='SUAVE' then 'Suave'      
when UPPER(BRAND)='KOTEX' then 'Kotex'
when UPPER(BRAND)='DURAMAX' then 'Duramax'
when UPPER(BRAND)='DRYNITES' then 'DryNites'
when BRAND='LaVie' then 'Lavie'
when BRAND='nalavie' then 'Lavie'
when BRAND='PullUps' then 'Pull-Ups'
else BRAND end as BRAND,
sector,
date(EventDate) Event_date
from hmp-emea-reporting.sfmc_sms.F_SMS_METRICS
where date(EventDate) <= last_day(date_sub(@run_date, interval 1 month)) and
sent is true
),
sends_rolling as
(
select count(distinct subscriber_id) sends_rolling_12months, region, country_code, brand, sector from 
sends_base 
where Event_date between last_day(date_sub(@run_date, interval 13 month)) and last_day(date_sub(@run_date, interval 1 month)) 
group by region, country_code, brand, sector
),
sends as
(
select count(distinct subscriber_id) sends, region, country_code, brand, sector from 
sends_base 
group by region, country_code, brand, sector
),
sms_sends as
(
Select 
sends_rolling_12months,
sends.sends as sends,
sends.country_code as country_code,
sends.region as region,
sends.brand,
sends.sector
from 
sends left join sends_rolling 
on sends.country_code = sends_rolling.country_code 
and sends.region = sends_rolling.region
and sends.brand = sends_rolling.brand
and sends.sector = sends_rolling.sector
),

/* Fetching >>KCNA data( -->before '2021-03-31',
                         -->other than US all brand and sector
						 -->other than US where Age_in_months = 9999 
						)  except US_HUGGIES , US_BCC combination
            >>non KCNA data complete */
db_health_monthly 
as
(   Select sum(TOT_CONSUMER) TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,TOT_CONSUMER,brand, sector from hmp-emea-reporting.sfmc_crm_onepd.F_DB_HEALTH_MONTHLY_VALIDATED
    where 
    (
    (region = 'KCNA'  and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and countrycode = 'US' and upper(brand) <> 'HUGGIES')  or --for US except US_HUGGIES
    (region = 'KCNA'  and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and sector <> 'BCC' and countrycode<> 'US')  or --for all countries except US AND BCC
    (region = 'KCNA'  and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and Age_in_months = 9999 and countrycode <> 'US') or
    (region <> 'KCNA' and upper(IS_CONTACTABLE) in ('Y','TRUE'))  
    )
    AND TIMESTAMP = last_day(date_sub(@run_date, interval 1 month))
    )
    group by REGION,COUNTRYCODE,brand, sector 
),

/* Fetching only KCNA data( -->after '2021-03-31',
                            -->BCC when AGE_IN_MONTHS = 9999
                            -->non BCC
					      ) except US_HUGGIES  */
db_acq_epsi 
as
(
    Select sum(NO_OF_CONSUMERS) TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector  from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,
    case when countrycode = 'US' and upper(brand)='HUGGIES' then 0 else NO_OF_CONSUMERS end as NO_OF_CONSUMERS,brand, sector  from hmp-emea-reporting.sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    where 
    timestamp >= '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE') and 
    (
    (upper(REGION)='KCNA' and SECTOR='BCC' and AGE_IN_MONTHS=9999) OR 
    (upper(REGION)='KCNA' and SECTOR<>'BCC')
    )
    AND TIMESTAMP = last_day(date_sub(@run_date, interval 1 month))
	AND BRAND <> 'NA'
    AND SECTOR <> 'NA'
    )
    where NO_OF_CONSUMERS<>0
    group by REGION,COUNTRYCODE,brand, sector 

),
/* Fetching only US_HUGGIES_BCC data from different table */
KCNA_HUGGIES_1PD as
(   
    SELECT 
    SUM(TOT_CONSUMER_US_HUGGIES) AS TOT_CONSUMER,
    COUNTRYCODE,REGION,SECTOR,BRAND FROM
    (
    select 
    IN_AGE_CONSUMERS + CATEGORY_PURCHASE_CONSUMERS + PRE_CATEGORY_PURCHASE_CONSUMERS as TOT_CONSUMER_US_HUGGIES ,
    'BCC' as SECTOR,
    'Huggies' as BRAND ,
    COUNTRY_CODE AS COUNTRYCODE,
    REGION
    from 
    (
    SELECT * FROM hmp-emea-reporting.sfmc_crm_onepd.CV_MAP_ACQ_KCNA_HUGGIES_1PD_EPSI
    UNION ALL 
    SELECT * FROM hmp-emea-reporting.sfmc_crm_onepd.CV_MAP_ACQ_KCNA_HUGGIES_1PD_OVEN
    )KCNA_HUGGIES_1PD
    where 
    DATE = last_day(date_sub(@run_date, interval 1 month)) and
    COUNTRY_CODE = 'US'
    )KCNA_HUGGIES_1PD_AGG

    GROUP BY COUNTRYCODE,REGION, SECTOR,BRAND 
),
epsi_unique_cons as
(
    select TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from db_health_monthly
    union all 
    select TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from db_acq_epsi
    union all 
    select TOT_CONSUMER,REGION,COUNTRYCODE,brand, sector from KCNA_HUGGIES_1PD 

)

Select 		last_day(date_sub(@run_date, interval 1 month)) as date,
			cast(base_country.TOT_CONSUMER as INT64) as TOT_CONSUMER,
              base_country.sends_rolling_12months as Sends_rolling_12_months,
              base_country.sends as Sends,
              base_country.country_code as Countrycode,
              base_country.region as Region,
              base_country.brand as Brand,
              base_country.sector as Sector,
              case 
              when base_country.country_code in ('UK','GB') then 'United Kingdom' 
              when base_country.country_code ='UN' then 'Unknown' else base_country.country_code_desc end as COUNTRYCODE_DESC,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends/base_country.TOT_CONSUMER,2) end as Utilization,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends_rolling_12months/base_country.TOT_CONSUMER,2) end as Utilization_rolling_12_months,
              from
              (
                    SELECT 
                    base.TOT_CONSUMER ,
                    base.sends_rolling_12months,
                    base.sends,
                    base.country_code,
                    base.region   ,
                    base.brand,
                    base.sector,
                    country_desc.Country_Code_Desc  as country_code_desc
                    from   
                    (
						Select 
							epsi_unique_cons.TOT_CONSUMER ,
							sms_sends.sends_rolling_12months,
							sms_sends.sends,
							epsi_unique_cons.COUNTRYCODE country_code,
							epsi_unique_cons.region,
                            epsi_unique_cons.brand,
                            epsi_unique_cons.sector
							from 
							sms_sends 
						inner join 
						epsi_unique_cons 
						on sms_sends.country_code = epsi_unique_cons.COUNTRYCODE 
						and sms_sends.region = epsi_unique_cons.region
						and sms_sends.brand = epsi_unique_cons.brand
						and sms_sends.sector = epsi_unique_cons.sector
              ) base 
                left join 
                country_desc country_desc 
                ON base.country_code =  country_desc.country_code 
)base_country
