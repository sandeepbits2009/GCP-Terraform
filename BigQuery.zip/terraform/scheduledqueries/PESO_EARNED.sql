WITH
dates as 
(
select 
    CONCAT(FORMAT_DATETIME("%Y-%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01") as CM_FROM_CY ,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH)) as CM_TO_CY,
    FORMAT_DATETIME("%Y%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)) as CM_FROM_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as YTD_FROM_CY,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY,
    FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as date)) as YTD_FROM_YYMM,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY_YYMM,	
	CONCAT(FORMAT_DATETIME("%Y-%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)),"-01") as LM_FROM_CY,
	FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_TO_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as YTD_LY_FROM_CY,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY,
	FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as date)) as YTD_LY_FROM_YYMM,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY_YYMM,	
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 YEAR)), "01") as  R12_FROM_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as R12_TO_CY
from 

 (select current_date()	 as DATE_VALUE)
),

source as 
(
SELECT
    'ORGANIC_SEARCH' AS channel,
	FORMAT_DATETIME("%Y%m",DATE) as month,
country,
region,
brand,
(case 
when brand = 'Mas Abrazos' then 'BCC' 
when brand = 'Lavie' then 'AFC'
else sector end) as sector,
sum(case when clicks is null then 0 else clicks end) AS clicks,
sum(impressions) AS impressions,
count(position) as tot_position_cnt,
cast(sum(position) as int) as tot_position,
cast(avg(position) as int) as ranking,
sum(case when non_brand_clicks is null then 0 else non_brand_clicks end) AS non_brand_clicks,
sum(case when in_market_clicks is null then 0 else in_market_clicks end) AS in_market_clicks
  FROM
   hmp-emea-reporting.kc_viz_ga360.vw_searchconsole_ga360_union 
  WHERE
  constant = 'SerachConsole' and
  DATE
    BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date)
    AND CAST((select CM_TO_CY from dates) AS date)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector
),  

  CM AS (
SELECT
    'ORGANIC_SEARCH' AS channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(clicks) AS clicks,
sum(impressions) AS impressions,
sum(tot_position_cnt) as tot_position_cnt,
sum(tot_position) as tot_position,
round(avg(ranking)) as ranking,
sum(non_brand_clicks) AS non_brand_clicks,
sum(in_market_clicks) AS in_market_clicks

  FROM
    source
  WHERE source.month = (select CM_FROM_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector
),
  YTD AS (
SELECT
    'ORGANIC_SEARCH' AS channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(clicks) AS clicks,
sum(impressions) AS impressions,
sum(tot_position_cnt) as tot_position_cnt,
sum(tot_position) as tot_position,
round(avg(ranking)) as ranking,
sum(non_brand_clicks) AS non_brand_clicks,
sum(in_market_clicks) AS in_market_clicks
  FROM
    source
  WHERE source.month between (select YTD_FROM_YYMM from dates) and (select YTD_TO_CY_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector
),
  YTD_LY AS (
SELECT
    'ORGANIC_SEARCH' AS channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(clicks) AS clicks,
sum(impressions) AS impressions,
sum(tot_position_cnt) as tot_position_cnt,
sum(tot_position) as tot_position,
round(avg(ranking)) as ranking,
sum(non_brand_clicks) AS non_brand_clicks,
sum(in_market_clicks) AS in_market_clicks

  FROM
   source
  WHERE source.month between (select YTD_LY_FROM_YYMM from dates) and (select YTD_LY_TO_CY_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector
),
  LM AS (
SELECT
    'ORGANIC_SEARCH' AS channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(clicks) AS clicks,
sum(impressions) AS impressions,
sum(tot_position_cnt) as tot_position_cnt,
sum(tot_position) as tot_position,
round(avg(ranking)) as ranking,
sum(non_brand_clicks) AS non_brand_clicks,
sum(in_market_clicks) AS in_market_clicks
  FROM
   source
 WHERE source.month = (select LM_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector
),

 combination AS (
  SELECT
    DISTINCT
	month,
    channel,
    country,
    region,
    brand,
    sector
	FROM CM
)

/* Final Pivot of data happens here  */      
    
SELECT
  concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
  c.channel,
  c.country,
  c.region,
  c.brand,
  c.sector,
  
    /* REQUIRED MONTH DATA */
	
CM.clicks as clicks_CM,
CM.impressions as impressions_CM,
CM.tot_position_cnt as tot_position_cnt_CM,
CM.tot_position as tot_position_CM,
CM.ranking as ranking_CM,
--non-brand and in-market
CM.non_brand_clicks AS non_brand_clicks_CM,
CM.in_market_clicks AS in_market_clicks_CM,	

   /* REQUIRED LAST MONTH DATA */

LM.clicks as clicks_LM,
LM.impressions as impressions_LM,
LM.tot_position_cnt as tot_position_cnt_LM,
LM.tot_position as tot_position_LM,
LM.ranking as ranking_LM,	
--non-brand and in-market
LM.non_brand_clicks AS non_brand_clicks_LM,
LM.in_market_clicks AS in_market_clicks_LM,		

   /* REQUIRED YTD DATA */

YTD.clicks as clicks_YTD,
YTD.impressions as impressions_YTD,
YTD.tot_position_cnt as tot_position_cnt_YTD,
YTD.tot_position as tot_position_YTD,
YTD.ranking as ranking_YTD,		
--non-brand and in-market
YTD.non_brand_clicks AS non_brand_clicks_YTD,
YTD.in_market_clicks AS in_market_clicks_YTD,	

   /* REQUIRED YEAR AGO DATA */

YTD_LY.clicks as clicks_YTD_LY,
YTD_LY.impressions as impressions_YTD_LY,
YTD_LY.tot_position_cnt as tot_position_cnt_YTD_LY,
YTD_LY.tot_position as tot_position_YTD_LY,
YTD_LY.ranking as ranking_YTD_LY,
--non-brand and in-market
YTD_LY.non_brand_clicks AS non_brand_clicks_YTD_LY,
YTD_LY.in_market_clicks AS in_market_clicks_YTD_LY,		

/* CTR PLACE HOLDERS(taken care in views) */ 
  cast(null as FLOAT64) as CTR_CM,
  cast(null as FLOAT64) as CTR_LM,
  cast(null as FLOAT64) as CTR_YTD,
  cast(null as FLOAT64) as CTR_YTD_LY,

FROM
  combination c
LEFT OUTER JOIN
  CM
ON
  c.month   = CM.month and
  upper(c.country) = upper(CM.country) and
  upper(c.region)  = upper(CM.region) and
  upper(c.brand)   = upper(CM.brand) and
  upper(c.sector)  = upper(CM.sector) and
  upper(c.channel) = upper(CM.channel)
LEFT OUTER JOIN
  YTD
ON
  c.month   = YTD.month and
  upper(c.country) = upper(YTD.country) and
  upper(c.region)  = upper(YTD.region) and
  upper(c.brand)   = upper(YTD.brand) and
  upper(c.sector)  = upper(YTD.sector) and
  upper(c.channel) = upper(YTD.channel)
LEFT OUTER JOIN
  LM
ON
  c.month   = LM.month and
  upper(c.country) = upper(LM.country) and
  upper(c.region)  = upper(LM.region) and
  upper(c.brand)   = upper(LM.brand) and
  upper(c.sector)  = upper(LM.sector) and
  upper(c.channel) = upper(LM.channel)
LEFT OUTER JOIN
  YTD_LY
ON
  c.month   = YTD_LY.month and
  upper(c.country) = upper(YTD_LY.country) and
  upper(c.region)  = upper(YTD_LY.region) and
  upper(c.brand)   = upper(YTD_LY.brand) and
  upper(c.sector)  = upper(YTD_LY.sector) and
  upper(c.channel) = upper(YTD_LY.channel)
