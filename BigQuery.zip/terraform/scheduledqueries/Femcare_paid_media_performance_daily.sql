
--INSERT INTO KimberlyClark_lao_MediaData.paid_media_performance_daily

  WITH 
    all_brand_string AS (
  SELECT
    CAST(REPLACE(STRING_AGG(LOWER(brand_name)), ',', '|') AS STRING) AS brand_list
  FROM
    media_checker_tool.brand_lookup_table ),
	
  brazil_dv360 AS (
  SELECT
    date AS Date,
    "LAO" AS Region,
    "Brazil" AS Country,
    REGEXP_EXTRACT(LOWER(CONCAT(advertiser,campaign)), ( SELECT * FROM all_brand_string)) AS brand,
    CAST(NULL AS string) AS Media_Type,
    CAST(NULL AS string) AS Account_Id,
    CAST( Data_Source AS string) AS Account_Name,
    CAST(Campaign AS STRING) AS Campaign,
    CAST(NULL AS string) AS Ad_Group,
    CAST(NULL AS string) AS Keyword,
    CAST(NULL AS string) AS Network,
    CAST(NULL AS string) AS Network_With_Search_Param,
    CAST(NULL AS string) AS Device,
    CAST(Impressions AS INT64) AS Impressions,
    CAST(Clicks AS INT64) AS Clicks,
    CAST(NULL AS INT64) AS Interactions,
    CAST(NULL AS INT64) AS Engagements,
    CAST (revenue_USD AS FLOAT64) AS Cost,
    CAST(NULL AS string) AS Quality_Score,
    CAST(NULL AS string) AS Landing_Page,
    CAST(NULL AS string) AS Impression_Share,
    CAST (Creative AS string) AS Creative_Name,
    CAST(creative_size AS string) AS Creative_Size,
    CAST(Creative_Type AS string) AS Creative_Type,
    CAST(NULL AS string) AS Placement,
    CAST(advertiser_id AS string) AS Advertiser_ID,
    CAST(advertiser AS string) AS Advertiser,
    CAST( campaign_id AS STRING) AS Campaign_ID,
    CAST(floodlight_activity_name AS string) AS Activity,
    CAST(complete_views_video AS INT64) AS Video_Views,
    CAST(starts_video AS INT64) AS Video_Plays,
    CAST(first_quartile_views_video AS INT64) AS Video_Watch_25_Percent,
    Midpoint_views_video AS Video_Watch_50_Percent,
    Third_quartile_views_video AS Video_Watch_75_Percent,
    complete_views_video AS Video_Watch_100_Percent,
    Total_conversions AS Conversions,
    CAST(NULL AS string) AS Ad_Set,
    CAST(NULL AS string) AS Ad_Set_ID,
    CAST(NULL AS string) AS Ad_Name,
    CAST(NULL AS string) AS Ad_ID,
    CAST(NULL AS string) AS Objective,
    "DV360" AS Platform,
    CAST(NULL AS string) AS Adset_Geo_Targeting,
    CAST(NULL AS string) AS Adset_Target_Platform,
    CAST(NULL AS string) AS Adset_Locales,
    CAST(NULL AS string) AS Impression_Device,
    CAST(NULL AS INT64) AS Video_Watch_30_sec,
    CURRENT_DATETIME() AS LoadTime,
    'brazil_dv360' AS Data_Category,
    CAST(NULL as FLOAT64) as Average_Cpc,
    CAST(NULL as FLOAT64) as Cost_Per_Conversion,
    CAST(NULL as FLOAT64) as Ctr,
    CAST(NULL as string) as Quality_Ranking,
    CONCAT('','',creative) AS ad_placement_join
  FROM
    ftran_brazil_google_display_and_video_360.brazil_google_display_and_video_360
	
  WHERE
    advertiser_id IN (5163834,
      5954438,
      5163832,
      5163835,
      5163833) /*
    AND advertiser IN ('BR_MIRUM-NEVE',
      'BR_MIRUM-PLENITUD',
      'BR_MIRUM-HUGGIES',
      'BR_MIRUM-SCOTTDURAMAX',
      'BR_MIRUM-INTIMUS')*/
    AND date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY) ),
  brazil_facebook_ads AS (
  SELECT
    a.date AS Date,
    "LAO" AS Region,
    "Brazil" AS Country,
	REGEXP_EXTRACT(LOWER(CONCAT(account_name)), ( SELECT * FROM all_brand_string)) AS brand,
    CAST(NULL AS string) AS Media_Type,
    CAST(account_id AS string) AS Account_ID,
    CAST(account_name AS string) AS Account_Name,
    CAST(Campaign_name AS string) AS Campaign,
    CAST(AdSet_name AS string) AS Ad_Group,
    CAST(NULL AS string) AS Keyword,
    CAST(NULL AS string) AS Network,
    CAST(NULL AS string) AS Network_With_Search_Param,
    CAST(NULL AS string) AS Device,
    CAST(Impressions AS INT64) AS Impressions,
    CAST(Clicks AS INT64) AS Clicks,
    CAST(NULL AS INT64) AS Interactions,
    CAST(NULL AS INT64) AS Engagements,
    CAST(spend AS float64) AS Cost,
    CAST(NULL AS string) AS Quality_Score,
    CAST(NULL AS string) AS Landing_Page,
    CAST(NULL AS string) AS Impression_Share,
    CAST(a.Ad_Name AS string) AS Creative_Name,
    CAST(NULL AS string) AS Creative_Size,
    CAST(NULL AS string) AS Creative_Type,
    CAST(NULL AS string) AS Placement,
    CAST(NULL AS string) AS Advertiser_ID,
    CAST(account_name as string) as Advertiser,  
    --CAST(NULL as string) as Advertiser,  --20220707
    CAST(Campaign_ID AS STRING) AS Campaign_ID,
    CAST(NULL AS string) AS Activity,
    CAST(NULL AS int64) AS Video_Views,
    -- CAST(Video_Plays__Facebook_Ads AS INT64) AS Video_Plays,
    -- CAST(Video_Watches_at_25__Facebook_Ads AS INT64) AS Video_Watch_25_Percent,
    -- CAST(Video_Watches_at_50__Facebook_Ads AS INT64) AS Video_Watch_50_Percent,
    -- CAST( Video_Watches_at_75__Facebook_Ads AS INT64) AS Video_Watch_75_Percent,
    -- CAST(Video_Watches_at_100__Facebook_Ads AS INT64) AS Video_Watch_100_Percent,
    -- CAST(Website_Conversions__Facebook_Ads AS FLOAT64) AS Conversions,
    CAST(g.value AS int64) AS Video_Plays,
    CAST(c.value AS int64) AS Video_Watch_25_Percent,
    CAST(e.value AS int64) AS Video_Watch_50_Percent,
    CAST(f.value AS int64) AS Video_Watch_75_Percent,
    CAST(d.value AS int64) AS Video_Watch_100_Percent,
    CAST(NULL AS int64) AS Conversions,
    CAST(AdSet_name AS string) AS Ad_Set,
    CAST(AdSet_ID AS string) AS Ad_Set_ID,
    CAST(a.Ad_Name AS string) AS Ad_Name,
    CAST(a.Ad_ID AS string) AS Ad_ID,
    CAST(Objective AS string) AS Objective,
    "Facebook" AS Platform,
    CAST(NULL AS string) AS Adset_Geo_Targeting,
    CAST(NULL AS string) AS Adset_Target_Platform,
    CAST(NULL AS string) AS Adset_Locales,
    CAST(NULL AS string) AS Impression_Device,
    CAST(b.value AS INT64) AS Video_Watch_30_sec,
    CURRENT_DATETIME() AS LoadTime,
    'brazil_facebook_ads' AS Data_Category,
    Cast(null as FLOAT64) as Average_Cpc,
    Cast(null as FLOAT64) as Cost_Per_Conversion,
    Cast(null as FLOAT64) as Ctr,
    Quality_Ranking,  
    CONCAT(a.AdSet_name,'',a.Ad_Name) AS ad_placement_join
  FROM
    facebook_ads_brazil_ftran.ftran_brazil_fb a
  LEFT JOIN
    `hmp-emea-reporting.facebook_ads_brazil_ftran.ftran_brazil_fb_video_30_sec_watched_actions` b
  ON
    a.ad_id= b.ad_id
    AND a.DATE=b.DATE
  LEFT JOIN
    `hmp-emea-reporting.facebook_ads_brazil_ftran.ftran_brazil_fb_video_p_25_watched_actions` c
  ON
    a.ad_id= c.ad_id
    AND a.DATE=c.DATE
  LEFT JOIN
    `hmp-emea-reporting.facebook_ads_brazil_ftran.ftran_brazil_fb_video_p_100_watched_actions` d
  ON
    a.ad_id= d.ad_id
    AND a.DATE=d.DATE
  LEFT JOIN
    `hmp-emea-reporting.facebook_ads_brazil_ftran.ftran_brazil_fb_video_p_50_watched_actions` e
  ON
    a.ad_id= e.ad_id
    AND a.DATE=e.DATE
  LEFT JOIN
    `hmp-emea-reporting.facebook_ads_brazil_ftran.ftran_brazil_fb_video_p_75_watched_actions` f
  ON
    a.ad_id= f.ad_id
    AND a.DATE=f.DATE
  LEFT JOIN
    `hmp-emea-reporting.facebook_ads_brazil_ftran.ftran_brazil_fb_video_play_actions` g
  ON
    a.ad_id= g.ad_id
    AND a.DATE=g.DATE
  WHERE
    a.date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY) ),	
  brazil_google_ads AS (
  SELECT
    date AS Date,
    "LAO" AS Region,
    "Brazil" AS Country,
    REGEXP_EXTRACT(LOWER(CONCAT(customer_descriptive_name)), ( SELECT * FROM all_brand_string)) AS brand,
    CAST(NULL AS string) AS Media_Type,
    CAST(customer_id AS STRING) AS Account_ID,
    CAST(customer_descriptive_name AS string) AS Account_Name,
    --CAST( Account_Descriptive_Name AS string) AS Account_Name,
    CAST(Campaign_Name AS string) AS Campaign,
    CAST( Ad_Group_Name AS STRING) AS Ad_Group,
    CAST(info_text AS STRING) AS Keyword,
    --CAST( Keyword_Text_Matching_Query AS STRING) AS Keyword,
    CAST( ad_network_type AS STRING) AS Network,
    '' AS Network_With_Search_Param,
    -- CAST( Ad_network_Type_1 AS STRING) AS Network,
    --CAST( Ad_network_Type_2 AS STRING) AS Network_With_Search_Param,
    CAST(Device AS string) AS Device,
    CAST(Impressions AS INT64) AS Impressions,
    CAST(Clicks AS INT64) AS Clicks,
    CAST(Interactions AS INT64) AS Interactions,
    CAST(Engagements AS INT64) AS Engagements,
    CAST(cost_micros/1000000 AS float64) AS Cost,
    --CAST(Cost AS float64) AS Cost,
    CAST(NULL AS string) AS Quality_Score,
    '' AS Landing_Page,
    --CAST(Destination_url AS string) AS Landing_Page,
    CAST( NULL AS string) AS Impression_Share,
    CAST(NULL AS string) AS Creative_Name,
    CAST(NULL AS string) AS Creative_Size,
    CAST(NULL AS string) AS Creative_Type,
    CAST(NULL AS string) AS Placement,
    CAST(NULL AS string) AS Advertiser_ID,
    CAST(NULL AS string) AS Advertiser,
    CAST(Campaign_Id AS STRING) AS Campaign_ID,
    CAST(NULL AS string) AS Activity,
    CAST(NULL AS int64) AS Video_Views,
    CAST(NULL AS int64) AS Video_Plays,
    CAST(NULL AS int64) AS Video_Watch_25_Percent,
    CAST(NULL AS int64) AS Video_Watch_50_Percent,
    CAST(NULL AS int64) AS Video_Watch_75_Percent,
    CAST(NULL AS int64) AS Video_Watch_100_Percent,
    CAST( Conversions AS float64) AS Conversions,
    CAST(NULL AS string) AS Ad_Set,
    CAST(NULL AS string) AS Ad_Set_ID,
    CAST(NULL AS string) AS Ad_Name,
    CAST(Ad_ID AS string) AS Ad_ID,
    --CAST(NULL AS string) AS Ad_ID, --20220707
    CAST(NULL AS string) AS Objective,
    "Google Ads" AS Platform,
    CAST(NULL AS string) AS Adset_Geo_Targeting,
    CAST(NULL AS string) AS Adset_Target_Platform,
    CAST(NULL AS string) AS Adset_Locales,
    CAST(NULL AS string) AS Impression_Device,
    CAST(NULL AS int64) AS Video_Watch_30_sec,
    CURRENT_DATETIME() AS LoadTime,
    'brazil_google_ads_intimus' AS Data_Category,
    Average_Cpc,
    Cost_Per_Conversion,
    Ctr,
    Cast(null as string) as Quality_Ranking,
    CONCAT(Ad_Group_Name,'','') AS ad_placement_join
  FROM
    adwords_brazil_intimus_new_api.keyword_brazil_intimus
  WHERE
    date = DATE_SUB(CURRENT_DATE(), INTERVAL 2 DAY) 
	
	UNION ALL
	
	  SELECT
    date AS Date,
    "LAO" AS Region,
    "Brazil" AS Country,
    REGEXP_EXTRACT(LOWER(CONCAT(customer_descriptive_name)), ( SELECT * FROM all_brand_string)) AS brand,
    CAST(NULL AS string) AS Media_Type,
    CAST(customer_id AS STRING) AS Account_ID,
    CAST(customer_descriptive_name AS string) AS Account_Name,
    --CAST( Account_Descriptive_Name AS string) AS Account_Name,
    CAST(Campaign_Name AS string) AS Campaign,
    CAST( Ad_Group_Name AS STRING) AS Ad_Group,
    CAST(info_text AS STRING) AS Keyword,
    --CAST( Keyword_Text_Matching_Query AS STRING) AS Keyword,
    CAST( ad_network_type AS STRING) AS Network,
    '' AS Network_With_Search_Param,
    -- CAST( Ad_network_Type_1 AS STRING) AS Network,
    --CAST( Ad_network_Type_2 AS STRING) AS Network_With_Search_Param,
    CAST(Device AS string) AS Device,
    CAST(Impressions AS INT64) AS Impressions,
    CAST(Clicks AS INT64) AS Clicks,
    CAST(Interactions AS INT64) AS Interactions,
    CAST(Engagements AS INT64) AS Engagements,
    CAST(cost_micros/1000000 AS float64) AS Cost,
    --CAST(Cost AS float64) AS Cost,
    CAST(NULL AS string) AS Quality_Score,
    '' AS Landing_Page,
    --CAST(Destination_url AS string) AS Landing_Page,
    CAST( NULL AS string) AS Impression_Share,
    CAST(NULL AS string) AS Creative_Name,
    CAST(NULL AS string) AS Creative_Size,
    CAST(NULL AS string) AS Creative_Type,
    CAST(NULL AS string) AS Placement,
    CAST(NULL AS string) AS Advertiser_ID,
    CAST(NULL AS string) AS Advertiser,
    CAST(Campaign_Id AS STRING) AS Campaign_ID,
    CAST(NULL AS string) AS Activity,
    CAST(NULL AS int64) AS Video_Views,
    CAST(NULL AS int64) AS Video_Plays,
    CAST(NULL AS int64) AS Video_Watch_25_Percent,
    CAST(NULL AS int64) AS Video_Watch_50_Percent,
    CAST(NULL AS int64) AS Video_Watch_75_Percent,
    CAST(NULL AS int64) AS Video_Watch_100_Percent,
    CAST( Conversions AS float64) AS Conversions,
    CAST(NULL AS string) AS Ad_Set,
    CAST(NULL AS string) AS Ad_Set_ID,
    CAST(NULL AS string) AS Ad_Name,
    CAST(Ad_ID AS string) AS Ad_ID,
    --CAST(NULL AS string) AS Ad_ID, --20220707
    CAST(NULL AS string) AS Objective,
    "Google Ads" AS Platform,
    CAST(NULL AS string) AS Adset_Geo_Targeting,
    CAST(NULL AS string) AS Adset_Target_Platform,
    CAST(NULL AS string) AS Adset_Locales,
    CAST(NULL AS string) AS Impression_Device,
    CAST(NULL AS int64) AS Video_Watch_30_sec,
    CURRENT_DATETIME() AS LoadTime,
    'brazil_google_ads_plenitud' AS Data_Category,
    Average_Cpc,
    Cost_Per_Conversion,
    Ctr,
    Cast(null as string) as Quality_Ranking,
    CONCAT(Ad_Group_Name,'','') AS ad_placement_join
  FROM
    adwords_brazil_plenitud_new_api.keyword_brazil_plenitud
  WHERE
    date = DATE_SUB(CURRENT_DATE(), INTERVAL 2 DAY)
	
 UNION ALL

 SELECT
    date AS Date,
    "LAO" AS Region,
    "Brazil" AS Country,
    REGEXP_EXTRACT(LOWER(CONCAT(customer_descriptive_name)), ( SELECT * FROM all_brand_string)) AS brand,
    CAST(NULL AS string) AS Media_Type,
    CAST(customer_id AS STRING) AS Account_ID,
    CAST(customer_descriptive_name AS string) AS Account_Name,
    --CAST( Account_Descriptive_Name AS string) AS Account_Name,
    CAST(Campaign_Name AS string) AS Campaign,
    CAST( Ad_Group_Name AS STRING) AS Ad_Group,
    CAST(info_text AS STRING) AS Keyword,
    --CAST( Keyword_Text_Matching_Query AS STRING) AS Keyword,
    CAST( ad_network_type AS STRING) AS Network,
    '' AS Network_With_Search_Param,
    -- CAST( Ad_network_Type_1 AS STRING) AS Network,
    --CAST( Ad_network_Type_2 AS STRING) AS Network_With_Search_Param,
    CAST(Device AS string) AS Device,
    CAST(Impressions AS INT64) AS Impressions,
    CAST(Clicks AS INT64) AS Clicks,
    CAST(Interactions AS INT64) AS Interactions,
    CAST(Engagements AS INT64) AS Engagements,
    CAST(cost_micros/1000000 AS float64) AS Cost,
    --CAST(Cost AS float64) AS Cost,
    CAST(NULL AS string) AS Quality_Score,
    '' AS Landing_Page,
    --CAST(Destination_url AS string) AS Landing_Page,
    CAST( NULL AS string) AS Impression_Share,
    CAST(NULL AS string) AS Creative_Name,
    CAST(NULL AS string) AS Creative_Size,
    CAST(NULL AS string) AS Creative_Type,
    CAST(NULL AS string) AS Placement,
    CAST(NULL AS string) AS Advertiser_ID,
    CAST(NULL AS string) AS Advertiser,
    CAST(Campaign_Id AS STRING) AS Campaign_ID,
    CAST(NULL AS string) AS Activity,
    CAST(NULL AS int64) AS Video_Views,
    CAST(NULL AS int64) AS Video_Plays,
    CAST(NULL AS int64) AS Video_Watch_25_Percent,
    CAST(NULL AS int64) AS Video_Watch_50_Percent,
    CAST(NULL AS int64) AS Video_Watch_75_Percent,
    CAST(NULL AS int64) AS Video_Watch_100_Percent,
    CAST( Conversions AS float64) AS Conversions,
    CAST(NULL AS string) AS Ad_Set,
    CAST(NULL AS string) AS Ad_Set_ID,
    CAST(NULL AS string) AS Ad_Name,
    CAST(Ad_ID AS string) AS Ad_ID,
    --CAST(NULL AS string) AS Ad_ID, --20220707
    CAST(NULL AS string) AS Objective,
    "Google Ads" AS Platform,
    CAST(NULL AS string) AS Adset_Geo_Targeting,
    CAST(NULL AS string) AS Adset_Target_Platform,
    CAST(NULL AS string) AS Adset_Locales,
    CAST(NULL AS string) AS Impression_Device,
    CAST(NULL AS int64) AS Video_Watch_30_sec,
    CURRENT_DATETIME() AS LoadTime,
    'brazil_google_ads_huggies' AS Data_Category,
    Average_Cpc,
    Cost_Per_Conversion,
    Ctr,
    Cast(null as string) as Quality_Ranking,
    CONCAT(Ad_Group_Name,'','') AS ad_placement_join
  FROM
    adwords_new_api.brazil_keywords
  WHERE
    date = DATE_SUB(CURRENT_DATE(), INTERVAL 2 DAY)	
    ),

 media_checker AS(
  SELECT
    advertiser,
    campaign_date,
	campaign,
    CONCAT(
    IF
      (Ad_group='not set',
        '',
        Ad_group),
    IF
      (LOWER(source)='dv360'
        OR Placement='not set',
        '',
        Placement),
    IF
      (Ad='not set',
        '',
        Ad) ) AS ad_placement_join,
    Advertiser_1,
    Advertiser_2,
    Campaign_1,
    Campaign_2,
    Campaign_3,
    Campaign_4,
    Campaign_5,
    Campaign_6,
    Campaign_7,
    Ad_1,
    Ad_2,
    Ad_3,
    Ad_4,
    Ad_5,
    Ad_6,
    Ad_group_1,
    Ad_group_2,
    Ad_group_3,
    Ad_group_4,
    Ad_group_5,
    status_Advertiser,
    status_Campaign,
    status_Ad,
    status_Business_manager,
    status_Ads_manager,
    status_Portfolio,
    status_Ad_group,
    status_Placement,
    status_Brand_rule
  FROM
    media_checker_tool.media_checker_tool_final
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33	)
	
SELECT
  hmp.Date AS Date,
  hmp.Region AS Region,
  hmp.Country AS Country,
  INITCAP(hmp.Brand) AS Brand,
  lookup_sector.Sector AS Sector,
  hmp.Media_Type AS Media_Type,
  hmp.Account_Id AS Account_Id,
  hmp.Account_Name AS Account_Name,
  hmp.Campaign AS Campaign,
  hmp.Ad_Group AS Ad_Group,
  hmp.Keyword AS Keyword,
  hmp.Network AS Network,
  hmp.Network_With_Search_Param AS Network_With_Search_Param,
  hmp.Device AS Device,
  hmp.Impressions AS Impressions,
  hmp.Clicks AS Clicks,
  hmp.Interactions AS Interactions,
  hmp.Engagements AS Engagements,
  hmp.Cost AS Cost,
  hmp.Quality_Score AS Quality_Score,
  hmp.Landing_Page AS Landing_Page,
  hmp.Impression_Share AS Impression_Share,
  hmp.Creative_Name AS Creative_Name,
  hmp.Creative_Size AS Creative_Size,
  hmp.Creative_Type AS Creative_Type,
  hmp.Placement AS Placement,
  hmp.Advertiser_ID AS Advertiser_ID,
  hmp.Advertiser AS Advertiser,
  hmp.Campaign_ID AS Campaign_ID,
  hmp.Activity AS Activity,
  hmp.Video_Views AS Video_Views,
  hmp.Video_Plays AS Video_Plays,
  hmp.Video_Watch_25_Percent AS Video_Watch_25_Percent,
  hmp.Video_Watch_50_Percent AS Video_Watch_50_Percent,
  hmp.Video_Watch_75_Percent AS Video_Watch_75_Percent,
  hmp.Video_Watch_100_Percent AS Video_Watch_100_Percent,
  hmp.Conversions AS Conversions,
  hmp.Ad_Set AS Ad_Set,
  hmp.Ad_Set_ID AS Ad_Set_ID,
  hmp.Ad_Name AS Ad_Name,
  hmp.Ad_ID AS Ad_ID,
  hmp.Objective AS Objective,
  hmp.Platform AS Platform,
  hmp.Adset_Geo_Targeting AS Adset_Geo_Targeting,
  hmp.Adset_Target_Platform AS Adset_Target_Platform,
  hmp.Adset_Locales AS Adset_Locales,
  hmp.Impression_Device AS Impression_Device,
  hmp.Video_Watch_30_sec AS Video_Watch_30_sec,
  hmp.LoadTime AS LoadTime,
  hmp.Data_Category AS Data_Category,
  hmp.Average_Cpc,
  hmp.Cost_Per_Conversion,
  hmp.Ctr,
  hmp.Quality_Ranking,
  media_checker.Advertiser_1 AS Advertiser_1,
  media_checker.advertiser_2 AS Advertiser_2,
  media_checker.Campaign_1 AS Campaign_1,
  media_checker.Campaign_2 AS Campaign_2,
  media_checker.Campaign_3 AS Campaign_3,
  media_checker.Campaign_4 AS Campaign_4,
  media_checker.Campaign_5 AS Campaign_5,
  media_checker.Campaign_6 AS Campaign_6,
  media_checker.Campaign_7 AS Campaign_7,
  media_checker.Ad_group_1 AS Ad_group_1,
  media_checker.Ad_group_2 AS Ad_group_2,
  media_checker.Ad_group_3 AS Ad_group_3,
  media_checker.Ad_group_4 AS Ad_group_4,
  media_checker.Ad_group_5 AS Ad_group_5,
  media_checker.Ad_1 AS Creative_1,
  media_checker.Ad_2 AS Creative_2,
  media_checker.Ad_3 AS Creative_3,
  media_checker.Ad_4 AS Creative_4,
  media_checker.Ad_5 AS Creative_5,
  media_checker.Ad_6 AS Creative_6,
  media_checker.status_Advertiser AS status_Advertiser,
  media_checker.status_Campaign AS status_Campaign,
  media_checker.status_Ad AS status_Ad,
  media_checker.status_Business_manager AS status_Business_manager,
  media_checker.status_Ads_manager AS status_Ads_manager,
  media_checker.status_Portfolio AS status_Portfolio,
  media_checker.status_Ad_group AS status_Ad_group,
  media_checker.status_Placement AS status_Placement,
  media_checker.status_Brand_rule AS status_Brand_rule
FROM (
  SELECT
    *
  FROM
    brazil_dv360
  UNION ALL
  SELECT
    *
  FROM
    brazil_google_ads
  UNION ALL
  SELECT
    *
  FROM
    brazil_facebook_ads ) AS hmp
LEFT OUTER JOIN
  kc_lookup_data.lookup_brand_sector_map lookup_sector
  On upper(hmp.brand)=upper(lookup_sector.brand)
LEFT OUTER JOIN
  media_checker
ON
  --IF(platform IN ('Facebook' ,'Google Ads'),hmp.Account_Name, hmp.advertiser) = media_checker.advertiser
  hmp.advertiser = media_checker.advertiser
  AND hmp.campaign = media_checker.campaign
  AND hmp.date = media_checker.campaign_date
  AND hmp.ad_placement_join = media_checker.ad_placement_join