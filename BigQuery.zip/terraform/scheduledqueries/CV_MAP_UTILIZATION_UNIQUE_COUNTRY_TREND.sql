



--insert into sfmc_crm_onepd.CV_MAP_UTILIZATION_UNIQUE_COUNTRY_TREND


with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
unique_consumer 
as
(   Select 
    sum(TOT_CONSUMER) TOT_CONSUMER,
    REGION,
    yearmonth,
    COUNTRYCODE 
    from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,TOT_CONSUMER,FORMAT_DATE("%Y%m", TIMESTAMP) yearmonth from sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED
    where 
    ((region = 'KCNA' and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')) or (region <> 'KCNA' and upper(IS_CONTACTABLE) in ('Y','TRUE')))
    AND TIMESTAMP BETWEEN last_day(date_sub(CURRENT_DATE(), interval 8 month)) AND last_day(date_sub(CURRENT_DATE(), interval 1 month))
    )
    WHERE REGION = 'KCNA'
    group by REGION,yearmonth,COUNTRYCODE
),

db_acq_epsi 
as
(
    Select sum(NO_OF_CONSUMERS) TOT_CONSUMER,
    REGION, 
    yearmonth,
    COUNTRYCODE
    from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,NO_OF_CONSUMERS, FORMAT_DATE("%Y%m", TIMESTAMP) yearmonth
    from sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    where 
    timestamp >= '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')
    AND TIMESTAMP BETWEEN last_day(date_sub(CURRENT_DATE(), interval 8 month)) AND last_day(date_sub(CURRENT_DATE(), interval 1 month))
    AND BRAND = 'NA'
    AND SECTOR = 'NA'
    )
    WHERE REGION = 'KCNA'
    group by REGION,yearmonth,COUNTRYCODE

),

epsi_unique_cons as
(
    select TOT_CONSUMER,
    REGION, 
    yearmonth,
    COUNTRYCODE from unique_consumer
    union all 
    select TOT_CONSUMER,
    REGION, 
    yearmonth,
    COUNTRYCODE from db_acq_epsi
),
sends_base as
(
SELECT 
distinct
Region,  
subscriber_id , 
date(Event_date) Event_date,
country_code
from sfmc_email.sends
where date(Event_date) <= last_day(date_sub(CURRENT_DATE(), interval 1 month)) 
AND REGION = 'KCNA' 
------union on email_subscriber will happen here.
union all 
SELECT 
distinct
Region,  
subscriberid , 
date(Eventdate) Event_date,
countrycode
from sfmc_crm_onepd.email_subscriber 
where date(Eventdate) <= last_day(date_sub(CURRENT_DATE(), interval 1 month))
AND REGION = 'KCNA' 
),
sends_rolling as
(
select count(distinct subscriber_id) sends_rolling_12months, 
region,  country_code,
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 1 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 13 month)) and last_day(date_sub(CURRENT_DATE(), interval 1 month)) 
group by region, country_code, yearmonth

union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
country_code, 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 2 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 14 month)) and last_day(date_sub(CURRENT_DATE(), interval 2 month)) 
group by region, country_code, yearmonth
union all 

select count(distinct subscriber_id) sends_rolling_12months, 
region, 
country_code, 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 3 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 15 month)) and last_day(date_sub(CURRENT_DATE(), interval 3 month)) 
group by region, country_code, yearmonth
union all 

select count(distinct subscriber_id) sends_rolling_12months, 
region, 
country_code, 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 4 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 16 month)) and last_day(date_sub(CURRENT_DATE(), interval 4 month)) 
group by region, country_code, yearmonth
union all 

select count(distinct subscriber_id) sends_rolling_12months, 
region, 
country_code, 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 5 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 17 month)) and last_day(date_sub(CURRENT_DATE(), interval 5 month)) 
group by region, country_code, yearmonth
union all 

select count(distinct subscriber_id) sends_rolling_12months, 
region, 
country_code, 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 6 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 18 month)) and last_day(date_sub(CURRENT_DATE(), interval 6 month)) 
group by region, country_code, yearmonth
union all 

select count(distinct subscriber_id) sends_rolling_12months, 
region, 
country_code, 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 7 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 19 month)) and last_day(date_sub(CURRENT_DATE(), interval 7 month)) 
group by region, country_code, yearmonth
)


Select 
			  cast(base_country.TOT_CONSUMER as INT64) as TOT_CONSUMER,
              base_country.sends_rolling_12months as SENDS,
              base_country.region as REGION,
              base_country.yearmonth as YEARMONTH,
              CASE WHEN base_country.country_code IN ('GB','UK') THEN 'United Kingdom' 
              WHEN base_country.country_code = 'UN' THEN 'Unknown'
              ELSE base_country.Country_Code_Desc END AS COUNTRYCODEDESC,
              base_country.country_code AS COUNTRYCODE,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends_rolling_12months/base_country.TOT_CONSUMER,2) end as UTILIZATION
              from
              (
                    SELECT 
                    base.TOT_CONSUMER ,
                    base.sends_rolling_12months,
                    base.region,
                    base.yearmonth,
                    base.country_code,
                    country_desc.Country_Code_Desc
                    from   
                    (
						Select 
							epsi_unique_cons.TOT_CONSUMER ,
							sends_rolling.sends_rolling_12months,
							epsi_unique_cons.yearmonth ,
							epsi_unique_cons.region,
                            epsi_unique_cons.countrycode COUNTRY_CODE
                            from 
							epsi_unique_cons 
						left join 
						sends_rolling 
                        on
						sends_rolling.region = epsi_unique_cons.region
                        AND sends_rolling.yearmonth = epsi_unique_cons.yearmonth
                        AND sends_rolling.country_code = epsi_unique_cons.COUNTRYCODE
                     ) base 
                     left join 
                     country_desc country_desc 
                     ON base.country_code =  country_desc.country_code 
            )base_country











