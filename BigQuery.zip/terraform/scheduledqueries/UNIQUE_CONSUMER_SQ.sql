--------   Comments are written in top  of the code , wherever needed -----------
--insert into sfmc_crm_onepd.CV_MAP_UNIQUE_CONSUMER_OVEN as
---------------------------------
---Adjust dataset name everywhere
with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
--- Aggregating data at the required level
--- this subquery will process 2 months of data
--- Reminder : Add filter to get data dynamically

Agg_base as
(
select 
TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,CREATEUPDATE_DATETIME,REGION,

---- Code for extracting month and year from timestamp
EXTRACT(MONTH from TIMESTAMP) as CC_MONTH,
EXTRACT(YEAR from TIMESTAMP) as CC_YEAR,
sum(TOT_CONSUMER) as TOT_CONSUMER,
sum(TOT_NO_DOB) as TOT_NO_DOB,
sum(TOT_DOB) as TOT_DOB,
sum(TOT_GENDER) as TOT_GENDER,
sum(TOT_CHILD_NAME) as TOT_CHILD_NAME,
sum(TOT_MEMBER_FIRST_NAME) as TOT_MEMBER_FIRST_NAME,
sum(TOT_MEMBER_LAST_NAME) as TOT_MEMBER_LAST_NAME,
sum(TOT_MEMBER_GENDER) as TOT_MEMBER_GENDER,
sum(TOT_POSTAL_CODE) as TOT_POSTAL_CODE,
sum(TOT_STATE) as TOT_STATE,
sum(TOT_CITY) as TOT_CITY,
sum(TOT_MOBILE_PHONE) as TOT_MOBILE_PHONE,
sum(TOT_LANDLINE_PHONE) as TOT_LANDLINE_PHONE,
sum(TOT_EMAIL) as TOT_EMAIL,
sum(TOT_MEMBER_GENDER_M) as TOT_MEMBER_GENDER_M,
sum(TOT_MEMBER_GENDER_F) as TOT_MEMBER_GENDER_F,
sum(TOT_MEMBER_GENDER_U) as TOT_MEMBER_GENDER_U,
sum(NO_OF_CONSUMERS) as NO_OF_CONSUMERS,
sum(TOT_CONSUMER_EMAILABLE) as TOT_CONSUMER_EMAILABLE,

from
sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED

where REGION!='KCNA' and
TIMESTAMP between LAST_DAY(date_sub(current_date(), interval 26 month), month) and LAST_DAY(date_sub(current_date(), interval 1 month), month)

---- Change it to 
---- timestamp between last_day(date_sub(current_date(), interval 26 month)) and last_day(date_sub(current_date(), interval 1 month))
---- This do because incremental data comes every month 
---- Ex data for May will available june but data for may with have timestamp as last day of May
group by 
TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,CREATEUPDATE_DATETIME,REGION,CC_MONTH,CC_YEAR
),

---- This query takes care of the metrics need to get YTD and YOY numbers
---- Query contains a union of data from same moth prev year and december of previous year

YTD_YoY_data as 
(
select 
COUNTRYCODE,IS_CONTACTABLE,REGION,
sum(case when METRIC_TYPE="YOY" then TOT_CONSUMER else 0 end) as Month_PREV_year,
sum(case when METRIC_TYPE="YTD" then TOT_CONSUMER else 0 end) as DEC_PREV_year
from
(
	select 
	COUNTRYCODE,IS_CONTACTABLE,REGION,
	sum(TOT_CONSUMER) as TOT_CONSUMER, "YOY" as METRIC_TYPE
	from
	sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED
	where TIMESTAMP=LAST_DAY(date_sub(current_date(), interval 13 month), month) 
    group by COUNTRYCODE,IS_CONTACTABLE,REGION

union all

	select 
	COUNTRYCODE,IS_CONTACTABLE,REGION,
	sum(TOT_CONSUMER) as TOT_CONSUMER, "YTD" as METRIC_TYPE
	from
	sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED
    ---- this filter is used to get get where timestamp is 31st dec of the Prev year
	where TIMESTAMP=LAST_DAY(date_sub(current_date(), interval 1 year), year)
    group by COUNTRYCODE,IS_CONTACTABLE,REGION
)
group by
COUNTRYCODE,IS_CONTACTABLE,REGION
)

----- Main query starts here

select 
TIMESTAMP,
COUNTRYCODE,
---- corrections need for country code are done below 
case 
when COUNTRYCODE in ('UK','GB') then 'United Kingdom' 
when COUNTRYCODE='UN' then 'Unknown' else COUNTRYCODE_DESC end as COUNTRYCODE_DESC,

IS_CONTACTABLE,CREATEUPDATE_DATETIME,REGION,TOT_CONSUMER,TOT_NO_DOB,TOT_DOB,TOT_GENDER,TOT_CHILD_NAME,TOT_MEMBER_FIRST_NAME,TOT_MEMBER_LAST_NAME,TOT_MEMBER_GENDER,TOT_POSTAL_CODE,TOT_STATE,TOT_CITY,TOT_MOBILE_PHONE,TOT_LANDLINE_PHONE,TOT_EMAIL,TOT_MEMBER_GENDER_M,TOT_MEMBER_GENDER_F,TOT_MEMBER_GENDER_U,NO_OF_CONSUMERS,TOT_CONSUMER_EMAILABLE,
CC_MONTH,CC_YEAR,
TOT_CONSUMER_NON_CUM,TOT_NO_DOB_NON_CUM,TOT_DOB_NON_CUM,TOT_GENDER_NON_CUM,TOT_CHILD_NAME_NON_CUM,TOT_MEMBER_FIRST_NAME_NON_CUM,TOT_MEMBER_LAST_NAME_NON_CUM,TOT_MEMBER_GENDER_NON_CUM,TOT_POSTAL_CODE_NON_CUM,TOT_STATE_NON_CUM,TOT_CITY_NON_CUM,TOT_MOBILE_PHONE_NON_CUM,TOT_LANDLINE_PHONE_NON_CUM,TOT_EMAIL_NON_CUM,TOT_MEMBER_GENDER_M_NON_CUM,TOT_MEMBER_GENDER_F_NON_CUM,TOT_MEMBER_GENDER_U_NON_CUM,
YOY_GROWTH_RATE,YTD_GROWTH_RATE,TOT_CONSUMER_DEC_PREV_YEAR,TOT_CONSUMER_PREV_YEAR
from
    (
        select 
        TIMESTAMP,base_CCmap_CU.COUNTRYCODE,base_CCmap_CU.IS_CONTACTABLE,base_CCmap_CU.CREATEUPDATE_DATETIME,base_CCmap_CU.REGION,TOT_CONSUMER,TOT_NO_DOB,TOT_DOB,TOT_GENDER,TOT_CHILD_NAME,TOT_MEMBER_FIRST_NAME,TOT_MEMBER_LAST_NAME,TOT_MEMBER_GENDER,TOT_POSTAL_CODE,TOT_STATE,TOT_CITY,TOT_MOBILE_PHONE,TOT_LANDLINE_PHONE,TOT_EMAIL,TOT_MEMBER_GENDER_M,TOT_MEMBER_GENDER_F,TOT_MEMBER_GENDER_U,NO_OF_CONSUMERS,TOT_CONSUMER_EMAILABLE,
		CC_MONTH,CC_YEAR,
		COUNTRYCODE_DESC,
		TOT_CONSUMER_NON_CUM,TOT_NO_DOB_NON_CUM,TOT_DOB_NON_CUM,TOT_GENDER_NON_CUM,TOT_CHILD_NAME_NON_CUM,TOT_MEMBER_FIRST_NAME_NON_CUM,TOT_MEMBER_LAST_NAME_NON_CUM,TOT_MEMBER_GENDER_NON_CUM,TOT_POSTAL_CODE_NON_CUM,TOT_STATE_NON_CUM,TOT_CITY_NON_CUM,TOT_MOBILE_PHONE_NON_CUM,TOT_LANDLINE_PHONE_NON_CUM,TOT_EMAIL_NON_CUM,TOT_MEMBER_GENDER_M_NON_CUM,TOT_MEMBER_GENDER_F_NON_CUM,TOT_MEMBER_GENDER_U_NON_CUM,
		---- YTD and YOY calculations are done here
		case when Month_PREV_year=0 then 0 else ((TOT_CONSUMER-Month_PREV_year)/Month_PREV_year) end as YOY_GROWTH_RATE,
		case when DEC_PREV_year=0 then 0 else ((TOT_CONSUMER-DEC_PREV_year)/DEC_PREV_year) end as YTD_GROWTH_RATE,
		DEC_PREV_year as TOT_CONSUMER_DEC_PREV_YEAR,
		Month_PREV_year as TOT_CONSUMER_PREV_YEAR
        from   
            (
                select 
                base_Ccmap.TIMESTAMP,base_Ccmap.COUNTRYCODE,base_Ccmap.IS_CONTACTABLE,base_Ccmap.CREATEUPDATE_DATETIME,base_Ccmap.REGION,base_Ccmap.TOT_CONSUMER,base_Ccmap.TOT_NO_DOB,base_Ccmap.TOT_DOB,base_Ccmap.TOT_GENDER,base_Ccmap.TOT_CHILD_NAME,base_Ccmap.TOT_MEMBER_FIRST_NAME,base_Ccmap.TOT_MEMBER_LAST_NAME,base_Ccmap.TOT_MEMBER_GENDER,base_Ccmap.TOT_POSTAL_CODE,base_Ccmap.TOT_STATE,base_Ccmap.TOT_CITY,base_Ccmap.TOT_MOBILE_PHONE,base_Ccmap.TOT_LANDLINE_PHONE,base_Ccmap.TOT_EMAIL,base_Ccmap.TOT_MEMBER_GENDER_M,base_Ccmap.TOT_MEMBER_GENDER_F,base_Ccmap.TOT_MEMBER_GENDER_U,base_Ccmap.NO_OF_CONSUMERS,base_Ccmap.TOT_CONSUMER_EMAILABLE,
				base_Ccmap.CC_MONTH,base_Ccmap.CC_YEAR,
				COUNTRYCODE_DESC,
				
				------ Below are all the calculations used to get non cumulative numbers
				(base_Ccmap.TOT_CONSUMER-PREV_month.TOT_CONSUMER) as TOT_CONSUMER_NON_CUM,
				(base_Ccmap.TOT_NO_DOB-PREV_month.TOT_NO_DOB) as TOT_NO_DOB_NON_CUM,
				(base_Ccmap.TOT_DOB-PREV_month.TOT_DOB) as TOT_DOB_NON_CUM,
				(base_Ccmap.TOT_GENDER-PREV_month.TOT_GENDER) as TOT_GENDER_NON_CUM,
				(base_Ccmap.TOT_CHILD_NAME-PREV_month.TOT_CHILD_NAME) as TOT_CHILD_NAME_NON_CUM,
				(base_Ccmap.TOT_MEMBER_FIRST_NAME-PREV_month.TOT_MEMBER_FIRST_NAME) as TOT_MEMBER_FIRST_NAME_NON_CUM,
				(base_Ccmap.TOT_MEMBER_LAST_NAME-PREV_month.TOT_MEMBER_LAST_NAME) as TOT_MEMBER_LAST_NAME_NON_CUM,
				(base_Ccmap.TOT_MEMBER_GENDER-PREV_month.TOT_MEMBER_GENDER) as TOT_MEMBER_GENDER_NON_CUM,
				(base_Ccmap.TOT_POSTAL_CODE-PREV_month.TOT_POSTAL_CODE) as TOT_POSTAL_CODE_NON_CUM,
				(base_Ccmap.TOT_STATE-PREV_month.TOT_STATE) as TOT_STATE_NON_CUM,
				(base_Ccmap.TOT_CITY-PREV_month.TOT_CITY) as TOT_CITY_NON_CUM,
				(base_Ccmap.TOT_MOBILE_PHONE-PREV_month.TOT_MOBILE_PHONE) as TOT_MOBILE_PHONE_NON_CUM,
				(base_Ccmap.TOT_LANDLINE_PHONE-PREV_month.TOT_LANDLINE_PHONE) as TOT_LANDLINE_PHONE_NON_CUM,
				(base_Ccmap.TOT_EMAIL-PREV_month.TOT_EMAIL) as TOT_EMAIL_NON_CUM,
				(base_Ccmap.TOT_MEMBER_GENDER_M-PREV_month.TOT_MEMBER_GENDER_M) as TOT_MEMBER_GENDER_M_NON_CUM,
				(base_Ccmap.TOT_MEMBER_GENDER_F-PREV_month.TOT_MEMBER_GENDER_F) as TOT_MEMBER_GENDER_F_NON_CUM,
				(base_Ccmap.TOT_MEMBER_GENDER_U-PREV_month.TOT_MEMBER_GENDER_U) as TOT_MEMBER_GENDER_U_NON_CUM,

                from
                    (
                        select 
                        TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,base.CREATEUPDATE_DATETIME,REGION,TOT_CONSUMER,TOT_NO_DOB,TOT_DOB,TOT_GENDER,TOT_CHILD_NAME,TOT_MEMBER_FIRST_NAME,TOT_MEMBER_LAST_NAME,TOT_MEMBER_GENDER,TOT_POSTAL_CODE,TOT_STATE,TOT_CITY,TOT_MOBILE_PHONE,TOT_LANDLINE_PHONE,TOT_EMAIL,TOT_MEMBER_GENDER_M,TOT_MEMBER_GENDER_F,TOT_MEMBER_GENDER_U,NO_OF_CONSUMERS,TOT_CONSUMER_EMAILABLE,
                        CC_MONTH,CC_YEAR,
						Country_Code_Desc as COUNTRYCODE_DESC
                        from 
                        (select * from Agg_base where TIMESTAMP=last_day(date_sub(current_date(), interval 1 month))) as base
                        left join 
                        country_desc desc_map
                        on
                        base.COUNTRYCODE=desc_map.country_code

                    ) base_CCmap
				left join
				--- Interval is set to 2 so to get previous month data
				(select * from Agg_base where TIMESTAMP=last_day(date_sub(current_date(), interval 2 month))) PREV_month
				on
				base_Ccmap.COUNTRYCODE=PREV_month.COUNTRYCODE and
				base_Ccmap.IS_CONTACTABLE=PREV_month.IS_CONTACTABLE and
				base_Ccmap.REGION=PREV_month.REGION
				
			)base_CCmap_CU
		left join
		YTD_YoY_data 
		---- join here is performed without timestamp because this level has been removed in YTD_YoY_data subquery 
		on
		base_Ccmap_CU.COUNTRYCODE=YTD_YoY_data.COUNTRYCODE and
		base_Ccmap_CU.IS_CONTACTABLE=YTD_YoY_data.IS_CONTACTABLE and
		base_Ccmap_CU.REGION=YTD_YoY_data.REGION
				
	)			
			


          

