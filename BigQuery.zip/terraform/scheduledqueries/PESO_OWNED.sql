  /*PESO SCHEDULED QUERY*/
WITH
dates as 
(
select 
    CONCAT(FORMAT_DATETIME("%Y-%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01") as CM_FROM_CY ,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH)) as CM_TO_CY,
    FORMAT_DATETIME("%Y%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)) as CM_FROM_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as YTD_FROM_CY,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY,
    FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as date)) as YTD_FROM_YYMM,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY_YYMM,	
	CONCAT(FORMAT_DATETIME("%Y-%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)),"-01") as LM_FROM_CY,
	FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_TO_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as YTD_LY_FROM_CY,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY,
	FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as date)) as YTD_LY_FROM_YYMM,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY_YYMM,	
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 YEAR)), "01") as  R12_FROM_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as R12_TO_CY
from 

 (select current_date()	 as DATE_VALUE)
),

CM_1pd AS (
  /*One-PD opt-in and volume-source*/
SELECT
    'ONE-PD' AS channel,
	FORMAT_DATETIME("%Y%m",TIMESTAMP) as month,
COUNTRYCODE_DESC AS country	,
region,
(
Case when UPPER(brand)='GOODNITES' then 'GoodNites'
when UPPER(brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(brand)='VIVA' then 'Viva'
when UPPER(brand)='SCOTT' then 'Scott'
when UPPER(brand)='KLEENEX' then 'Kleenex'
when UPPER(brand)='COTTONELLE' then 'Cottonelle'
when UPPER(brand)='DEPEND' then 'Depend'
when UPPER(brand)='DEPENDCARE' then 'Depend'
when UPPER(brand)='POISE' then 'Poise'
when UPPER(brand)='UBYKOTEX' then 'UByKotex'
when UPPER(brand)='HUGGIES' then 'Huggies'
when UPPER(brand)='PLENITUD' then 'Plenitud'
when UPPER(brand)='ANDREX' then 'Andrex'
when UPPER(brand)='SHIKMA' then 'Shikma'
when UPPER(brand)='TITULIM' then 'Titulim'
when UPPER(brand)='MOLETT' then 'Molett'
when UPPER(brand)='LILY' then 'Lily'
when UPPER(brand)='NIKOL' then 'Nikol'
when UPPER(brand)='INTIMUS' then 'Intimus'
when UPPER(brand)='HAKLE' then 'Hakle'
when UPPER(brand)='SCOTTEX' then 'Scottex'
when UPPER(brand)='LAVIE' then 'Lavie'
when UPPER(brand)='NALAVIE' then 'Lavie'
when UPPER(brand)='NEVE' then 'Neve'
when UPPER(brand)='SUAVE' then 'Suave'      
when UPPER(brand)='KOTEX' then 'Kotex'
when UPPER(brand)='DURAMAX' then 'Duramax'
when UPPER(brand)='DURAMEX' then 'Duramax'
when UPPER(brand)='DRYNITES' then 'DryNites'
when brand='LaVie' then 'Lavie'
when brand='nalavie' then 'Lavie'
when brand='PullUps' then 'Pull-Ups'
else brand end 
 ) as brand
,
sector,
--updated IS_CONTACTABLE cases to Y and N
CASE WHEN (trim(upper(IS_CONTACTABLE)) in ('TRUE','Y')) then TOT_CONSUMER else 0 end as opted_in,
CASE WHEN (trim(upper(IS_CONTACTABLE)) in ('FALSE','N')) then TOT_CONSUMER else 0 end as total_consumers

FROM
  hmp-emea-reporting.sfmc_crm_onepd.CV_MAP_ACQUISITION_COUNT_F
  where
  TIMESTAMP
    BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date)
    AND CAST((select CM_TO_CY from dates) AS date)


union all	


SELECT
    'ONE-PD' AS channel,
	FORMAT_DATETIME("%Y%m",TIMESTAMP) as month,
COUNTRYCODE_DESC AS country	,
region,
(
Case when UPPER(brand)='GOODNITES' then 'GoodNites'
when UPPER(brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(brand)='VIVA' then 'Viva'
when UPPER(brand)='SCOTT' then 'Scott'
when UPPER(brand)='KLEENEX' then 'Kleenex'
when UPPER(brand)='COTTONELLE' then 'Cottonelle'
when UPPER(brand)='DEPEND' then 'Depend'
when UPPER(brand)='DEPENDCARE' then 'Depend'
when UPPER(brand)='POISE' then 'Poise'
when UPPER(brand)='UBYKOTEX' then 'UByKotex'
when UPPER(brand)='HUGGIES' then 'Huggies'
when UPPER(brand)='PLENITUD' then 'Plenitud'
when UPPER(brand)='ANDREX' then 'Andrex'
when UPPER(brand)='SHIKMA' then 'Shikma'
when UPPER(brand)='TITULIM' then 'Titulim'
when UPPER(brand)='MOLETT' then 'Molett'
when UPPER(brand)='LILY' then 'Lily'
when UPPER(brand)='NIKOL' then 'Nikol'
when UPPER(brand)='INTIMUS' then 'Intimus'
when UPPER(brand)='HAKLE' then 'Hakle'
when UPPER(brand)='SCOTTEX' then 'Scottex'
when UPPER(brand)='LAVIE' then 'Lavie'
when UPPER(brand)='NALAVIE' then 'Lavie'
when UPPER(brand)='NEVE' then 'Neve'
when UPPER(brand)='SUAVE' then 'Suave'      
when UPPER(brand)='KOTEX' then 'Kotex'
when UPPER(brand)='DURAMAX' then 'Duramax'
when UPPER(brand)='DURAMEX' then 'Duramax'
when UPPER(brand)='DRYNITES' then 'DryNites'
when brand='LaVie' then 'Lavie'
when brand='nalavie' then 'Lavie'
when brand='PullUps' then 'Pull-Ups'
else brand end 
 ) as brand,
sector,
CASE WHEN (trim(upper(IS_CONTACTABLE)) in ('TRUE','Y')) then TOT_CONSUMER else 0 end as opted_in,
CASE WHEN (trim(upper(IS_CONTACTABLE)) in ('FALSE','N')) then TOT_CONSUMER else 0 end as total_consumers

FROM
  hmp-emea-reporting.sfmc_crm_onepd.CV_MAP_ACQUISITION_COUNT_F_EPSI
  where
  TIMESTAMP
    BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date)
    AND CAST((select CM_TO_CY from dates) AS date)
),
  /*Source for other channels are aggregated here, data upto 24 months from required month is loaded in this block*/

source as (
(
SELECT 
N.channel,N.month,N.country,N.region,N.brand,N.sector,
web_sessions,web_session_timeonsite,web_pageviews,web_users,
email_sends,emails_delivered,unique_clicks,unique_opens,sms_delivered,sms_ctor,onepd_volume,opted_in,onepd_utilization_rate,onepd_utilization_rolling_12_months,
website_optins,unique_users_to_website,web_optin_Sessions,buy_now_clicks
FROM (
(SELECT
    'WEBSITE' AS channel,
	FORMAT_DATETIME("%Y%m",DATE) as month,
COUNTRYNAME as country,
region,
(Case when UPPER(brand)='GOODNITES' then 'GoodNites'
when UPPER(brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(brand)='VIVA' then 'Viva'
when UPPER(brand)='SCOTT' then 'Scott'
when UPPER(brand)='KLEENEX' then 'Kleenex'
when UPPER(brand)='COTTONELLE' then 'Cottonelle'
when UPPER(brand)='DEPEND' then 'Depend'
when UPPER(brand)='DEPENDCARE' then 'Depend'
when UPPER(brand)='POISE' then 'Poise'
when UPPER(brand)='UBYKOTEX' then 'UByKotex'
when UPPER(brand)='HUGGIES' then 'Huggies'
when UPPER(brand)='PLENITUD' then 'Plenitud'
when UPPER(brand)='ANDREX' then 'Andrex'
when UPPER(brand)='SHIKMA' then 'Shikma'
when UPPER(brand)='TITULIM' then 'Titulim'
when UPPER(brand)='MOLETT' then 'Molett'
when UPPER(brand)='LILY' then 'Lily'
when UPPER(brand)='NIKOL' then 'Nikol'
when UPPER(brand)='INTIMUS' then 'Intimus'
when UPPER(brand)='HAKLE' then 'Hakle'
when UPPER(brand)='SCOTTEX' then 'Scottex'
when UPPER(brand)='LAVIE' then 'Lavie'
when UPPER(brand)='NALAVIE' then 'Lavie'
when UPPER(brand)='NEVE' then 'Neve'
when UPPER(brand)='SUAVE' then 'Suave'      
when UPPER(brand)='KOTEX' then 'Kotex'
when UPPER(brand)='DURAMAX' then 'Duramax'
when UPPER(brand)='DURAMEX' then 'Duramax'
when UPPER(brand)='DRYNITES' then 'DryNites'
when brand='LaVie' then 'Lavie'
when brand='nalavie' then 'Lavie'
when brand='PullUps' then 'Pull-Ups'
else brand end 
 ) as brand,
sector,
sum(Sessions) AS web_sessions, --from constant = sessions
sum(TimeOnSiteInSeconds) as web_session_timeonsite,--from constant = sessions
sum(Pageviews) as web_pageviews,
--sum(Users) as web_users, new logic Users = Distinct Client ID
count(distinct clientId) as web_users,
null as email_sends,
null as emails_delivered,
null as unique_clicks,
null as unique_opens,
null as sms_delivered,
null as sms_ctor,
null as onepd_volume,
NULL as opted_in,
null as onepd_utilization_rate,
null as onepd_utilization_rolling_12_months
  FROM
    hmp-emea-reporting.kc_viz_ga360.vw_ga360_website_metrics
  WHERE
  constant = 'Sessions' and
  DATE
    BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date)
    AND CAST((select CM_TO_CY from dates) AS date)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel
) N
LEFT OUTER JOIN
(
select a.channel,a.month,a.country,a.region,
(Case when UPPER(a.brand)='GOODNITES' then 'GoodNites'
when UPPER(a.brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(a.brand)='VIVA' then 'Viva'
when UPPER(a.brand)='SCOTT' then 'Scott'
when UPPER(a.brand)='KLEENEX' then 'Kleenex'
when UPPER(a.brand)='COTTONELLE' then 'Cottonelle'
when UPPER(a.brand)='DEPEND' then 'Depend'
when UPPER(a.brand)='DEPENDCARE' then 'Depend'
when UPPER(a.brand)='POISE' then 'Poise'
when UPPER(a.brand)='UBYKOTEX' then 'UByKotex'
when UPPER(a.brand)='HUGGIES' then 'Huggies'
when UPPER(a.brand)='PLENITUD' then 'Plenitud'
when UPPER(a.brand)='ANDREX' then 'Andrex'
when UPPER(a.brand)='SHIKMA' then 'Shikma'
when UPPER(a.brand)='TITULIM' then 'Titulim'
when UPPER(a.brand)='MOLETT' then 'Molett'
when UPPER(a.brand)='LILY' then 'Lily'
when UPPER(a.brand)='NIKOL' then 'Nikol'
when UPPER(a.brand)='INTIMUS' then 'Intimus'
when UPPER(a.brand)='HAKLE' then 'Hakle'
when UPPER(a.brand)='SCOTTEX' then 'Scottex'
when UPPER(a.brand)='LAVIE' then 'Lavie'
when UPPER(a.brand)='NALAVIE' then 'Lavie'
when UPPER(a.brand)='NEVE' then 'Neve'
when UPPER(a.brand)='SUAVE' then 'Suave'      
when UPPER(a.brand)='KOTEX' then 'Kotex'
when UPPER(a.brand)='DURAMAX' then 'Duramax'
when UPPER(a.brand)='DURAMEX' then 'Duramax'
when UPPER(a.brand)='DRYNITES' then 'DryNites'
when a.brand='LaVie' then 'Lavie'
when a.brand='nalavie' then 'Lavie'
when a.brand='PullUps' then 'Pull-Ups'
else a.brand end 
 ) as brand,
a.sector,a.website_optins,a.unique_users_to_website,a.web_optin_Sessions,b.buy_now_clicks from 
(select 
'WebSite' AS channel,
FORMAT_DATETIME("%Y%m",Date) as month,
Country,
region,
brand ,
sector,
sum(Goal_Completions) as website_optins,
--sum(users) as unique_users_to_website, new logic unique_users_to_website = distinct clientID
count(distinct client_Id) as unique_users_to_website,
sum(Sessions) as web_optin_Sessions 
from hmp-emea-reporting.kc_viz_ga360.vw_kcna_ga_360_all_goals_pivoted 
where Goal_Name = 'Web_OptIn' and 
      DATE BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select CM_TO_CY from dates) AS date)
group by channel,month,country,region,brand,sector) a

inner join

(select 
'WebSite' AS channel,
FORMAT_DATETIME("%Y%m",Date) as month,
Country,
region,
brand ,
sector,
sum(Goal_Completions) as buy_now_clicks
from hmp-emea-reporting.kc_viz_ga360.vw_kcna_ga_360_all_goals_pivoted 
where Goal_Name = 'Buy_Online' and 
      DATE BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select CM_TO_CY from dates) AS date)
group by channel,month,country,region,brand,sector) b

on

a.month=b.month and
a.Country=b.Country and
a.region=b.region and
a.brand=b.brand and
a.sector=b.sector
)web_dis
on
N.month=web_dis.month and
upper(N.Country)=upper(web_dis.Country) and
N.region=web_dis.region and
N.brand=web_dis.brand and
N.sector=web_dis.sector
)  
)  
 
UNION ALL

SELECT
    'SMS' AS channel,
	FORMAT_DATETIME("%Y%m",Event_Date) as month,
COUNTRYCODE_DESC AS Country,
region,
(Case when UPPER(brand)='GOODNITES' then 'GoodNites'
when UPPER(brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(brand)='VIVA' then 'Viva'
when UPPER(brand)='SCOTT' then 'Scott'
when UPPER(brand)='KLEENEX' then 'Kleenex'
when UPPER(brand)='COTTONELLE' then 'Cottonelle'
when UPPER(brand)='DEPEND' then 'Depend'
when UPPER(brand)='DEPENDCARE' then 'Depend'
when UPPER(brand)='POISE' then 'Poise'
when UPPER(brand)='UBYKOTEX' then 'UByKotex'
when UPPER(brand)='HUGGIES' then 'Huggies'
when UPPER(brand)='PLENITUD' then 'Plenitud'
when UPPER(brand)='ANDREX' then 'Andrex'
when UPPER(brand)='SHIKMA' then 'Shikma'
when UPPER(brand)='TITULIM' then 'Titulim'
when UPPER(brand)='MOLETT' then 'Molett'
when UPPER(brand)='LILY' then 'Lily'
when UPPER(brand)='NIKOL' then 'Nikol'
when UPPER(brand)='INTIMUS' then 'Intimus'
when UPPER(brand)='HAKLE' then 'Hakle'
when UPPER(brand)='SCOTTEX' then 'Scottex'
when UPPER(brand)='LAVIE' then 'Lavie'
when UPPER(brand)='NALAVIE' then 'Lavie'
when UPPER(brand)='NEVE' then 'Neve'
when UPPER(brand)='SUAVE' then 'Suave'      
when UPPER(brand)='KOTEX' then 'Kotex'
when UPPER(brand)='DURAMAX' then 'Duramax'
when UPPER(brand)='DURAMEX' then 'Duramax'
when UPPER(brand)='DRYNITES' then 'DryNites'
when brand='LaVie' then 'Lavie'
when brand='nalavie' then 'Lavie'
when brand='PullUps' then 'Pull-Ups'
else brand end 
 ) as brand,
sector,
null AS web_sessions,
null as web_session_timeonsite,
null as web_pageviews,
null as web_users,
null as email_sends,
null as emails_delivered,
null as unique_clicks,
null as unique_opens,
sum(Delivered) as sms_delivered,
null as sms_ctor,
null as onepd_volume,
NULL as opted_in,
null as onepd_utilization_rate,
null as onepd_utilization_rolling_12_months,
null as website_optins,
NULL as unique_users_to_website,
null as web_optin_Sessions,
null as buy_now_clicks
  FROM
    hmp-emea-reporting.kc_viz_sfmc_email.vw_sms_agg_view
  WHERE
    Event_Date BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date)
    AND CAST((select CM_TO_CY from dates) AS date)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel

UNION ALL
    
SELECT
'E-MAIL' as channel,
	FORMAT_DATETIME("%Y%m",TIMESTAMP) as month,
COUNTRYCODE_DESC AS Country,
region,
(Case when UPPER(brand)='GOODNITES' then 'GoodNites'
when UPPER(brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(brand)='VIVA' then 'Viva'
when UPPER(brand)='SCOTT' then 'Scott'
when UPPER(brand)='KLEENEX' then 'Kleenex'
when UPPER(brand)='COTTONELLE' then 'Cottonelle'
when UPPER(brand)='DEPEND' then 'Depend'
when UPPER(brand)='DEPENDCARE' then 'Depend'
when UPPER(brand)='POISE' then 'Poise'
when UPPER(brand)='UBYKOTEX' then 'UByKotex'
when UPPER(brand)='HUGGIES' then 'Huggies'
when UPPER(brand)='PLENITUD' then 'Plenitud'
when UPPER(brand)='ANDREX' then 'Andrex'
when UPPER(brand)='SHIKMA' then 'Shikma'
when UPPER(brand)='TITULIM' then 'Titulim'
when UPPER(brand)='MOLETT' then 'Molett'
when UPPER(brand)='LILY' then 'Lily'
when UPPER(brand)='NIKOL' then 'Nikol'
when UPPER(brand)='INTIMUS' then 'Intimus'
when UPPER(brand)='HAKLE' then 'Hakle'
when UPPER(brand)='SCOTTEX' then 'Scottex'
when UPPER(brand)='LAVIE' then 'Lavie'
when UPPER(brand)='NALAVIE' then 'Lavie'
when UPPER(brand)='NEVE' then 'Neve'
when UPPER(brand)='SUAVE' then 'Suave'      
when UPPER(brand)='KOTEX' then 'Kotex'
when UPPER(brand)='DURAMAX' then 'Duramax'
when UPPER(brand)='DURAMEX' then 'Duramax'
when UPPER(brand)='DRYNITES' then 'DryNites'
when brand='LaVie' then 'Lavie'
when brand='nalavie' then 'Lavie'
when brand='PullUps' then 'Pull-Ups'
else brand end 
 ) as brand,
sector,
null AS web_sessions,
null as web_session_timeonsite,
null as web_pageviews,
null as web_users,
sum(sends) as email_sends,
sum(Delivered) as emails_delivered,
sum(case when TIMESTAMP < '2021-08-01' then UNIQUE_CLICKS else UNIQUE_CLICKS_NEW end) as unique_clicks,
sum(UNIQUE_OPENS) as unique_opens,
null as sms_delivered,
null as sms_ctor,
null as onepd_volume,
NULL as opted_in,
null as onepd_utilization_rate,
null as onepd_utilization_rolling_12_months,
null as website_optins,
NULL as unique_users_to_website,
null as web_optin_Sessions,
null as buy_now_clicks
  FROM
    hmp-emea-reporting.kc_viz_sfmc_email.vw_F_EMAIL_METRICS_GLOBAL
  WHERE
    TIMESTAMP BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date)
    AND CAST((select CM_TO_CY from dates) AS date)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel
	
union all

SELECT
'ONE-PD' as channel,
month,
country	,
region,
brand,
sector,
null AS web_sessions,
null as web_session_timeonsite,
null as web_pageviews,
null as web_users,
null as email_sends,
null as emails_delivered,
null as unique_clicks,
null as unique_opens,
NULL as sms_delivered,
null as sms_ctor,
sum(total_consumers) as onepd_volume,
sum(opted_in) as opted_in,
null as onepd_utilization_rate,
null as onepd_utilization_rolling_12_months,
null as website_optins,
NULL as unique_users_to_website,
null as web_optin_Sessions,
null as buy_now_clicks
FROM CM_1pd
WHERE
    MONTH BETWEEN (select YTD_LY_FROM_YYMM from dates) AND (select CM_FROM_YYMM from dates)
	GROUP BY
  month,
    country,
    region,
    brand,
    sector

union all

SELECT
'ONE-PD-UL' as channel,
concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
COUNTRYCODE_DESC as country	,
region,
(Case when UPPER(brand)='GOODNITES' then 'GoodNites'
when UPPER(brand)='PULL-UPS' then 'Pull-Ups'
when UPPER(brand)='VIVA' then 'Viva'
when UPPER(brand)='SCOTT' then 'Scott'
when UPPER(brand)='KLEENEX' then 'Kleenex'
when UPPER(brand)='COTTONELLE' then 'Cottonelle'
when UPPER(brand)='DEPEND' then 'Depend'
when UPPER(brand)='POISE' then 'Poise'
when UPPER(brand)='UBYKOTEX' then 'UByKotex'
when UPPER(brand)='HUGGIES' then 'Huggies'
when UPPER(brand)='PLENITUD' then 'Plenitud'
when UPPER(brand)='ANDREX' then 'Andrex'
when UPPER(brand)='SHIKMA' then 'Shikma'
when UPPER(brand)='TITULIM' then 'Titulim'
when UPPER(brand)='MOLETT' then 'Molett'
when UPPER(brand)='LILY' then 'Lily'
when UPPER(brand)='NIKOL' then 'Nikol'
when UPPER(brand)='INTIMUS' then 'Intimus'
when UPPER(brand)='HAKLE' then 'Hakle'
when UPPER(brand)='SCOTTEX' then 'Scottex'
when UPPER(brand)='LAVIE' then 'Lavie'
when UPPER(brand)='NALAVIE' then 'Lavie'
when UPPER(brand)='NEVE' then 'Neve'
when UPPER(brand)='SUAVE' then 'Suave'      
when UPPER(brand)='KOTEX' then 'Kotex'
when UPPER(brand)='DURAMAX' then 'Duramax'
when UPPER(brand)='DURAMEX' then 'Duramax'
when UPPER(brand)='DRYNITES' then 'DryNites'
when brand='LaVie' then 'Lavie'
when brand='nalavie' then 'Lavie'
when brand='PullUps' then 'Pull-Ups'
else brand end 
 ) as brand,
sector,
null AS web_sessions,
null as web_session_timeonsite,
null as web_pageviews,
null as web_users,
null as email_sends,
null as emails_delivered,
null as unique_clicks,
null as unique_opens,
NULL as sms_delivered,
null as sms_ctor,
null as onepd_volume,
null as opted_in,
Utilization as onepd_utilization_rate,
Utilization_rolling_12_months as onepd_utilization_rolling_12_months,
null as website_optins,
NULL as unique_users_to_website,
null as web_optin_Sessions,
null as buy_now_clicks
from hmp-emea-reporting.sfmc_crm_onepd.CV_MAP_UTILIZATION_1PD

),

  /*data of required month is populated in this block*/

  CM AS (
SELECT
channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(source.web_sessions) AS web_sessions,
sum(source.web_session_timeonsite) as web_session_timeonsite,
sum(source.web_pageviews) as web_pageviews,
sum(source.web_users) as web_users,
sum(source.email_sends) as email_sends,
sum(source.emails_delivered) as emails_delivered,
sum(source.unique_clicks) as unique_clicks,
sum(source.unique_opens) as unique_opens,
sum(source.sms_delivered) as sms_delivered,
null as sms_ctor,
sum(source.onepd_volume) as onepd_volume,
sum(source.opted_in) as opted_in,
sum(source.onepd_utilization_rate) as onepd_utilization_rate,
sum(source.onepd_utilization_rolling_12_months) as onepd_utilization_rolling_12_months,
sum(source.website_optins) as website_optins,
sum(source.unique_users_to_website) as unique_users_to_website,
sum(web_optin_Sessions) as web_optin_Sessions,
sum(source.buy_now_clicks) as buy_now_clicks
  FROM
    source
  WHERE source.month = (select CM_FROM_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel
)
,


/* YTDs for SMS,WEBSITE,e-MAIL aghrehated month wise(and other segments like brand,country etc) */

  YTD AS (
SELECT
channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(source.web_sessions) AS web_sessions,
sum(source.web_session_timeonsite) as web_session_timeonsite,
sum(source.web_pageviews) as web_pageviews,
sum(source.web_users) as web_users,
sum(source.email_sends) as email_sends,
sum(source.emails_delivered) as emails_delivered,
sum(source.unique_clicks) as unique_clicks,
sum(source.unique_opens) as unique_opens,
sum(source.sms_delivered) as sms_delivered,
null as sms_ctor,
sum(source.onepd_volume) as onepd_volume,
sum(source.opted_in) as opted_in,
/* added additional fields to incorporate landing layer */
sum(source.onepd_utilization_rate) as onepd_utilization_rate,
sum(source.onepd_utilization_rolling_12_months) as onepd_utilization_rolling_12_months,
sum(source.website_optins) as website_optins,
sum(source.unique_users_to_website) as unique_users_to_website,
sum(web_optin_Sessions) as web_optin_Sessions,
sum(source.buy_now_clicks) as buy_now_clicks
  FROM
    source
  WHERE source.month between (select YTD_FROM_YYMM from dates) and (select YTD_TO_CY_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel
)
,

/* YAGO for SMS,WEBSITE,e-MAIL aghrehated month wise(and other segments like brand,country etc) */
    
  YTD_LY AS (
SELECT
channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(source.web_sessions) AS web_sessions,
sum(source.web_session_timeonsite) as web_session_timeonsite,
sum(source.web_pageviews) as web_pageviews,
sum(source.web_users) as web_users,
sum(source.email_sends) as email_sends,
sum(source.emails_delivered) as emails_delivered,
sum(source.unique_clicks) as unique_clicks,
sum(source.unique_opens) as unique_opens,
sum(source.sms_delivered) as sms_delivered,
null as sms_ctor,
sum(source.onepd_volume) as onepd_volume,
sum(source.opted_in) as opted_in,
/* added additional fields to incorporate landing layer */
sum(source.onepd_utilization_rate) as onepd_utilization_rate,
sum(source.onepd_utilization_rolling_12_months) as onepd_utilization_rolling_12_months,
sum(source.website_optins) as website_optins,
sum(source.unique_users_to_website) as unique_users_to_website,
sum(web_optin_Sessions) as web_optin_Sessions,
sum(source.buy_now_clicks) as buy_now_clicks
  FROM
    source
  WHERE source.month between (select YTD_LY_FROM_YYMM from dates) and (select YTD_LY_TO_CY_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel
)
,
    
/* last month's of required month for SMS,WEBSITE,e-MAIL aghrehated month wise(and other segments like brand,country etc) */
    
LM AS (
SELECT
channel,
	concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
country,
region,
brand,
sector,
sum(source.web_sessions) AS web_sessions,
sum(source.web_session_timeonsite) as web_session_timeonsite,
sum(source.web_pageviews) as web_pageviews,
sum(source.web_users) as web_users,
sum(source.email_sends) as email_sends,
sum(source.emails_delivered) as emails_delivered,
sum(source.unique_clicks) as unique_clicks,
sum(source.unique_opens) as unique_opens,
sum(source.sms_delivered) as sms_delivered,
null as sms_ctor,
sum(source.onepd_volume) as onepd_volume,
sum(source.opted_in) as opted_in,
/* added additional fields to incorporate landing layer */
sum(source.onepd_utilization_rate) as onepd_utilization_rate,
sum(source.onepd_utilization_rolling_12_months) as onepd_utilization_rolling_12_months,
sum(source.website_optins) as website_optins,
sum(source.unique_users_to_website) as unique_users_to_website,
sum(web_optin_Sessions) as web_optin_Sessions,
sum(source.buy_now_clicks) as buy_now_clicks
  FROM
    source
 WHERE source.month = (select LM_YYMM from dates)
  GROUP BY
  month,
    country,
    region,
    brand,
    sector,
    channel
)   
/* getting unique combinations of channel,country,region,brand,sector
This data is used to map YTD,LM and other fileds in a pivot manner */
,

 combination AS (
  SELECT
    DISTINCT
	month,
    channel,
    country,
    region,
    brand,
    sector
	FROM CM
)


/* Final Pivot of data happens here  */      
    
SELECT
  concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
  c.channel,
  c.country,
  c.region,
  c.brand,
  c.sector,
  
    /* REQUIRED MONTH DATA */
	
  CM.sms_delivered AS sms_delivered_CM,
  CM.sms_ctor as sms_ctor_CM,
  CM.web_sessions as web_sessions_CM,
    cast(null as int64) as web_sessions_tgt_CM,
  CM.web_session_timeonsite as web_session_timeonsite_CM,
  CM.web_pageviews as web_pageviews_CM,
      cast(null as int64) as web_session_timeonsite_tgt_CM,
  CM.web_users as web_users_CM,
  CM.email_sends as email_sends_CM,
  CM.Emails_delivered as Emails_delivered_CM,
  CM.UNIQUE_CLICKS as UNIQUE_CLICKS_CM,
  CM.UNIQUE_OPENS AS UNIQUE_OPENS_CM,
  CM.onepd_volume as onepd_volume_CM,
  CM.opted_in as opted_in_CM,
  CM.onepd_utilization_rate as onepd_utilization_rate,
  CM.onepd_utilization_rolling_12_months as onepd_utilization_rolling_12_months,
      /*Disruptive KPIs*/
  CM.website_optins as website_optins_CM,
  CM.unique_users_to_website as unique_users_to_website_CM,
  CM.web_optin_Sessions as web_optin_Sessions_CM,
  CM.buy_now_clicks as buy_now_clicks_CM,
  
      /* LAST MONTH DATA */
      
  LM.sms_delivered AS sms_delivered_LM,
  LM.sms_ctor as sms_ctor_LM,
  LM.web_sessions as web_sessions_LM,
  LM.web_session_timeonsite as web_session_timeonsite_LM,
  LM.web_pageviews as web_pageviews_LM,
  LM.web_users as web_users_LM,
  LM.email_sends as email_sends_LM,
  LM.Emails_delivered as Emails_delivered_LM,
  LM.UNIQUE_CLICKS as UNIQUE_CLICKS_LM,
  LM.UNIQUE_OPENS AS UNIQUE_OPENS_LM,
  LM.onepd_volume as onepd_volume_LM,
  LM.opted_in as opted_in_LM,
  --LM.onepd_utilization_rate as onepd_utilization_rate,
  --LM.onepd_utilization_rolling_12_months as onepd_utilization_rolling_12_months,
  
      /*Disruptive KPIs*/
	  
  LM.website_optins as website_optins_LM,
  LM.unique_users_to_website as unique_users_to_website_LM,
  LM.web_optin_Sessions as web_optin_Sessions_LM,  
  LM.buy_now_clicks as buy_now_clicks_LM, 
  
  /* YTD */
  
  YTD.sms_delivered as sms_delivered_YTD,
  YTD.sms_ctor as sms_ctor_YTD,
  YTD.web_sessions as web_sessions_YTD,
  YTD.web_session_timeonsite as web_session_timeonsite_YTD,
  YTD.web_pageviews as web_pageviews_YTD,
  YTD.web_users as web_users_YTD,
  YTD.email_sends as email_sends_YTD,
  YTD.Emails_delivered as Emails_delivered_YTD,	
  YTD.UNIQUE_CLICKS AS UNIQUE_CLICKS_YTD,
  YTD.UNIQUE_OPENS AS UNIQUE_OPENS_YTD,
  YTD.onepd_volume AS onepd_volume_YTD, 
  YTD.opted_in AS opted_in_YTD,
  --YTD.onepd_utilization_rate as onepd_utilization_rate,
  --YTD.onepd_utilization_rolling_12_months as onepd_utilization_rolling_12_months,
  
      /*Disruptive KPIs*/
	  
  YTD.website_optins as website_optins_YTD,
  YTD.unique_users_to_website as unique_users_to_website_YTD,
  YTD.web_optin_Sessions as web_optin_Sessions_YTD,  
  YTD.buy_now_clicks as buy_now_clicks_YTD,

  /* LAST YEAR DATA */
  
  YTD_LY.sms_delivered as sms_delivered_YTD_LY,
  YTD_LY.sms_ctor as sms_ctor_YTD_LY,
  YTD_LY.web_sessions as web_sessions_YTD_LY,
  YTD_LY.web_session_timeonsite as web_session_timeonsite_YTD_LY,
  YTD_LY.web_pageviews as web_pageviews_YTD_LY,
  YTD_LY.web_users as web_users_YTD_LY,
  YTD_LY.email_sends as email_sends_YTD_LY,
  YTD_LY.Emails_delivered as Emails_delivered_YTD_LY,	
  YTD_LY.UNIQUE_CLICKS AS UNIQUE_CLICKS_YTD_LY,
  YTD_LY.UNIQUE_OPENS AS UNIQUE_OPENS_YTD_LY,
  YTD_LY.onepd_volume AS onepd_volume_YTD_LY, 
  YTD_LY.opted_in AS opted_in_YTD_LY,
  --YTD_LY.onepd_utilization_rate as onepd_utilization_rate,
  --YTD_LY.onepd_utilization_rolling_12_months as onepd_utilization_rolling_12_months,
  
      /*Disruptive KPIs*/
	  
  YTD_LY.website_optins as website_optins_YTD_LY,
  YTD_LY.unique_users_to_website as unique_users_to_website_YTD_LY,
  YTD_LY.web_optin_Sessions as web_optin_Sessions_YTD_LY,  
  YTD_LY.buy_now_clicks as buy_now_clicks_YTD_LY

FROM
  combination c
LEFT OUTER JOIN
  CM
ON
  c.month   = CM.month and
  upper(c.country) = upper(CM.country) and
  upper(c.region)  = upper(CM.region) and
  upper(c.brand)   = upper(CM.brand) and
  upper(c.sector)  = upper(CM.sector) and
  upper(c.channel) = upper(CM.channel)
LEFT OUTER JOIN
  YTD
ON
  c.month   = YTD.month and
  upper(c.country) = upper(YTD.country) and
  upper(c.region)  = upper(YTD.region) and
  upper(c.brand)   = upper(YTD.brand) and
  upper(c.sector)  = upper(YTD.sector) and
  upper(c.channel) = upper(YTD.channel)
LEFT OUTER JOIN
  LM
ON
  c.month   = LM.month and
  upper(c.country) = upper(LM.country) and
  upper(c.region)  = upper(LM.region) and
  upper(c.brand)   = upper(LM.brand) and
  upper(c.sector)  = upper(LM.sector) and
  upper(c.channel) = upper(LM.channel)
LEFT OUTER JOIN
  YTD_LY
ON
  c.month   = YTD_LY.month and
  upper(c.country) = upper(YTD_LY.country) and
  upper(c.region)  = upper(YTD_LY.region) and
  upper(c.brand)   = upper(YTD_LY.brand) and
  upper(c.sector)  = upper(YTD_LY.sector) and
  upper(c.channel) = upper(YTD_LY.channel)
