#ga_sessions_daily_andrex_emea_uk

WITH
  base AS (
  SELECT
    *
  FROM
   `185006019.ga_sessions_*` --- change table
  WHERE
    _TABLE_SUFFIX = FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 2 DAY)) ),
  sessions AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    clientId,
    visitNumber,
    visitStartTime,
    CONCAT(fullVisitorId, CAST(visitStartTime AS INT64)) AS SessionId,
    SUM(totals.visits) AS Sessions,
    SUM(totals.pageviews) AS Pageviews,
    SUM(totals.bounces) AS Bounces,
    SUM(totals.timeOnSite) AS timeOnSite
  FROM
    base b
  GROUP BY
    1,
    2,
    3,
    4,
    5 ),
  users AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    CONCAT(fullVisitorId, CAST(visitStartTime AS INT64)) AS SessionId,
    clientId,
    fullVisitorId,
    visitNumber,
    COUNT(DISTINCT fullVisitorId) AS UsersD,
    COUNT(DISTINCT(
        CASE
          WHEN totals.newVisits = 1 THEN fullVisitorId
        ELSE
        NULL
      END
        )) / COUNT(DISTINCT CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))) AS PercentageNewSessions,
    COUNT(DISTINCT(CASE
          WHEN totals.newVisits = 1 THEN fullVisitorId
        ELSE
        NULL
      END
        )) AS NewUsers,
    COUNT(DISTINCT CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))) / COUNT(DISTINCT fullVisitorId) AS SessionsPerUser,
  FROM
    base
  GROUP BY
    1,
    2,
    3,
    4,
    5 ),
  landingPage AS (
  SELECT
    PARSE_DATE("%Y%m%d",
      date) AS Date,
    clientId,
    CONCAT(fullVisitorId, CAST(visitStartTime AS INT64)) AS SessionId,
    channelGrouping AS Channel,
    trafficSource.source AS Source,
    trafficSource.medium AS Medium,
    trafficSource.campaign AS Campaign,
    geoNetwork.country AS GACountry,
    geoNetwork.region AS Region,
    geoNetwork.city AS City,
    hitNumber,
    page.pagePath AS LandingPage,
    page.pageTitle AS LandingPageTitle,
    device.deviceCategory AS DeviceCategory,
  FROM
    base,
    UNNEST(hits) AS hits
  WHERE
    hits.isEntrance = TRUE
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14 ),
  output AS (
  SELECT
    s.Date,
    "185006019" AS GAViewID, --- change GAviewID
    "Andrex" AS Brand, --- change Brand
    "EMEA" AS Region, --- change Region
    "FC" AS Sector, --- change Sector
    "United Kingdom" AS WebsiteCountry, --- change Argentina
    "UK" as CountryCode, --- change CountryCode
    s.SessionId,
    GACountry,
    Region as GARegion,
    Channel,
    Source,
    Medium,
    Campaign,
    City,
    LandingPage.LandingPage,
    LandingPageTitle,
    DeviceCategory,
    s.clientId,
    IFNULL(SUM(Sessions),
      0) AS Sessions,
    IFNULL(SUM(Pageviews),
      0) AS Pageviews,
    IFNULL(SUM(Bounces),
      0) AS Bounces,
    SUM(NewUsers) AS NewUsers,
  IF
    (timeOnSite IS NULL,
      0,
      timeOnSite) AS TimeOnSiteInSeconds
  FROM
    sessions s
  LEFT JOIN
    users
  ON
    s.SessionId = users.SessionId
    AND s.Date = users.Date
  LEFT JOIN
    landingPage
  ON
    s.SessionId = landingPage.SessionId
    AND s.Date = landingPage.Date
  GROUP BY
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    24)
SELECT
  *
FROM
  output
