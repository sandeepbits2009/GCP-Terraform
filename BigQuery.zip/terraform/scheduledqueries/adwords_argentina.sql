
SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
   adwords_argentina_huggies.keyword_argentina_huggies_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
    adwords_argentina_plenitud.keyword_argentina_plenitud_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
   adwords_argentina_kotex.keyword_argentina_kotex_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
  adwords_argentina_huggies_hipermania.keyword_argentina_huggies_hipermania_checker --NO DATA
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
   adwords_argentina_huggies_morashop.keyword_argentina_huggies_morashop_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
    adwords_argentina_masabrazos.keyword_argentina_masabrazos_checker  