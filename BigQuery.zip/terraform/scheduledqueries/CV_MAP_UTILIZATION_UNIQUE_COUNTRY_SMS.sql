
with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `hmp-emea-reporting.sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),

unique_consumer 
as
(   Select sum(TOT_CONSUMER) TOT_CONSUMER,REGION,COUNTRYCODE from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,TOT_CONSUMER from hmp-emea-reporting.sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED 
    where 	
    ((region = 'KCNA' and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')) or (region <> 'KCNA' and upper(IS_CONTACTABLE) in ('Y','TRUE')))
    AND TIMESTAMP = last_day(date_sub(@run_date, interval 1 month))
    )
    group by REGION,COUNTRYCODE
),

db_acq_epsi 
as
(
    Select sum(NO_OF_CONSUMERS) TOT_CONSUMER,REGION,COUNTRYCODE from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,NO_OF_CONSUMERS from hmp-emea-reporting.sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    where 
    timestamp >= '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')
	AND BRAND = 'NA'
    AND SECTOR = 'NA'
    AND TIMESTAMP = last_day(date_sub(@run_date, interval 1 month))
    )
    group by REGION,COUNTRYCODE

),

epsi_unique_cons as
(
    select TOT_CONSUMER,REGION,COUNTRYCODE from unique_consumer
    union all 
    select TOT_CONSUMER,REGION,COUNTRYCODE from db_acq_epsi
),


sends_base as
(
SELECT 
distinct
Region, 
Country as country_code,
SubscriberID as subscriber_id,
date(EventDate) as Event_date
from hmp-emea-reporting.sfmc_sms.F_SMS_METRICS
where date(EventDate) <= last_day(date_sub(@run_date, interval 1 month)) and 
sent is true
),

sends_rolling as
(
select count(distinct subscriber_id) sends_rolling_12months, region, country_code from 
sends_base 
where Event_date between last_day(date_sub(@run_date, interval 13 month)) and last_day(date_sub(@run_date, interval 1 month)) 
group by region, country_code
),

sends as
(
select count(distinct subscriber_id) sends, region, country_code from 
sends_base 
group by region, country_code
),


sms_sends as
(
Select 
sends_rolling_12months,
sends.sends as sends,
sends.country_code as country_code,
sends.region as region
from 
sends left join sends_rolling 
on sends.country_code = sends_rolling.country_code 
and sends.region = sends_rolling.region
)

Select 
			  last_day(date_sub(@run_date, interval 1 month)) as date,
			  cast(base_country.TOT_CONSUMER as INT64) as TOT_CONSUMER,
              base_country.sends_rolling_12months as Sends_rolling_12_months,
              base_country.sends as Sends,
              base_country.country_code as Countrycode,
              base_country.region as Region,
              case 
              when base_country.country_code in ('UK','GB') then 'United Kingdom' 
              when base_country.country_code ='UN' then 'Unknown' else base_country.country_code_desc end as COUNTRYCODE_DESC,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends/base_country.TOT_CONSUMER,2) end as Utilization,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends_rolling_12months/base_country.TOT_CONSUMER,2) end as Utilization_rolling_12_months,
              from
              (
                    SELECT 
                    base.TOT_CONSUMER ,
                    base.sends_rolling_12months,
                    base.sends,
                    base.country_code,
                    base.region   ,
                    country_desc.country_code_desc as country_code_desc
                    from   
                    (
						Select 
							epsi_unique_cons.TOT_CONSUMER ,
							sms_sends.sends_rolling_12months,
							sms_sends.sends,
							sms_sends.country_code,
							sms_sends.region
							from 
							sms_sends 
						inner join 
						epsi_unique_cons 
						on sms_sends.country_code = epsi_unique_cons.COUNTRYCODE 
						and sms_sends.region = epsi_unique_cons.region
                     ) base 
                left join 
                country_desc country_desc 
                ON base.country_code =  country_desc.country_code 
)base_country


