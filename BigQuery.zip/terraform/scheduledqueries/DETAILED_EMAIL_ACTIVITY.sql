


--INSERT INTO dev-hmpemea-reporting.sfmc_email.F_DETAILED_EMAIL_ACTIVITY_INTERMEDIATE
------------------------------------ Sends Base Dataset -------------------------------------------
With Sends as
(
select
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, Date(EVENT_DATE) as EVENTDATE,EVENT_DATE as TIMESTAMP, DOMAIN, 
upper(COUNTRY_CODE) as COUNTRYCODE, 
EMAIL_NAME, JOURNEY_NAME, 
Case when upper(REGION)="AUS" then "APAC" else REGION end as REGION,
Case when UPPER(BRAND)='GOODNITES' then 'GoodNites'
when UPPER(BRAND)='PULL-UPS' then 'Pull-Ups'
when UPPER(BRAND)='VIVA' then 'Viva'
when UPPER(BRAND)='SCOTT' then 'Scott'
when UPPER(BRAND)='KLEENEX' then 'Kleenex'
when UPPER(BRAND)='COTTONELLE' then 'Cottonelle'
when UPPER(BRAND)='DEPEND' then 'Depend'
when UPPER(BRAND)='POISE' then 'Poise'
when UPPER(BRAND)='UBYKOTEX' then 'UByKotex'
when UPPER(BRAND)='HUGGIES' then 'Huggies'
when UPPER(BRAND)='PLENITUD' then 'Plenitud'
when UPPER(BRAND)='ANDREX' then 'Andrex'
when UPPER(BRAND)='SHIKMA' then 'Shikma'
when UPPER(BRAND)='TITULIM' then 'Titulim'
when UPPER(BRAND)='MOLETT' then 'Molett'
when UPPER(BRAND)='LILY' then 'Lily'
when UPPER(BRAND)='NIKOL' then 'Nikol'
when UPPER(BRAND)='INTIMUS' then 'Intimus'
when UPPER(BRAND)='HAKLE' then 'Hakle'
when UPPER(BRAND)='SCOTTEX' then 'Scottex'
when UPPER(BRAND)='LAVIE' then 'Lavie'
when UPPER(BRAND)='NALAVIE' then 'Lavie'
when UPPER(BRAND)='NEVE' then 'Neve'
when UPPER(BRAND)='SUAVE' then 'Suave'      
when UPPER(BRAND)='KOTEX' then 'Kotex'
when UPPER(BRAND)='DURAMAX' then 'Duramax'
when UPPER(BRAND)='DRYNITES' then 'DryNites'
when BRAND='LaVie' then 'Lavie'
when BRAND='nalavie' then 'Lavie'
when BRAND='PullUps' then 'Pull-Ups'
else BRAND end as BRAND, 
case when BRAND in ('Molett','Lily') then 'FC' else SECTOR end as SECTOR, 
TOUCH_ID, CAMPAIGN, SUBJECT_LINE, SUBJECTLINE_GENERAL

FROM sfmc_email.sends

where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)

group by JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, EVENTDATE, TIMESTAMP, DOMAIN, upper(COUNTRY_CODE), EMAIL_NAME, JOURNEY_NAME, REGION, BRAND, SECTOR, TOUCH_ID, CAMPAIGN, SUBJECT_LINE, SUBJECTLINE_GENERAL
),

------------------------------------ Clicks Base Dataset -------------------------------------------
Clicks as
(
SELECT 
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, URL,LINK_CONTENT,
sum(TOTAL_CLICK) as TOTAL_CLICK, 
sum(NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED
 
FROM 
	(
	SELECT 
	JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, URL, IS_UNIQUE, LINK_CONTENT,
	1 as TOTAL_CLICK, --Total CLICK
	CASE WHEN SUBSCRIBER_ID is not null and IS_UNIQUE=True THEN 1 ELSE 0 END as NUM_SUBSCRIBERS_CLICKED --Calculation of measure 'NUM_SUBSCRIBERS_CLICKED'
	
	FROM sfmc_email.clicks 
	where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)

	)
group by
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, URL,LINK_CONTENT
),


------------------------------------ Opens Base Dataset -------------------------------------------
Opens as
(
select 
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, 
sum(TOTAL_OPENS) as TOTAL_OPENS

from (
SELECT 
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID, IS_UNIQUE, 
1 as TOTAL_OPENS

FROM sfmc_email.open
where Date(EVENT_DATE) between DATE_SUB(current_date(), INTERVAL 92 DAY) and DATE_SUB(current_date(), INTERVAL 2 DAY)
)
group by
JOB_ID, LIST_ID, BATCH_ID, SUBSCRIBER_ID
),


Clicks2 as 
(
					select EVENTDATE, CASE WHEN COUNTRYCODE='UK' THEN 'GB' ELSE COUNTRYCODE END as COUNTRYCODE, EMAIL_NAME, REGION, BRAND, SECTOR,  
					LINK_CONTENT, URL, sum(TOTAL_CLICK) as TOTAL_CLICK, sum(NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED,
					sum(UNIQUE_CLICKS) as UNIQUE_CLICKS
						from		
								(
								select 
								snds.JOB_ID, snds.LIST_ID, snds.BATCH_ID, snds.SUBSCRIBER_ID, snds.EVENTDATE, snds.TIMESTAMP, snds.COUNTRYCODE, snds.EMAIL_NAME,
								snds.REGION, snds.BRAND, snds.SECTOR, clks.LINK_CONTENT,clks.URL,
								sum(TOTAL_CLICK) as TOTAL_CLICK, sum(NUM_SUBSCRIBERS_CLICKED) as NUM_SUBSCRIBERS_CLICKED,
								sum(CASE WHEN clks.SUBSCRIBER_ID||clks.URL is not null THEN 1 ELSE 0 END) as UNIQUE_CLICKS					
									from 
									Sends as snds
									left outer join
									Clicks as clks
									on snds.JOB_ID=clks.JOB_ID
									and snds.LIST_ID=clks.LIST_ID
									and snds.BATCH_ID=clks.BATCH_ID
									and snds.SUBSCRIBER_ID=clks.SUBSCRIBER_ID
							
								group by
								snds.JOB_ID, snds.LIST_ID, snds.BATCH_ID, snds.SUBSCRIBER_ID, snds.EVENTDATE, snds.TIMESTAMP, snds.DOMAIN, snds.COUNTRYCODE, snds.EMAIL_NAME, snds.JOURNEY_NAME, snds.REGION, snds.BRAND, snds.SECTOR, snds.TOUCH_ID, snds.CAMPAIGN, snds.SUBJECT_LINE, snds.SUBJECTLINE_GENERAL,clks.LINK_CONTENT,clks.URL
					
								)
						group by
						EVENTDATE, CASE WHEN COUNTRYCODE='UK' THEN 'GB' ELSE COUNTRYCODE END, EMAIL_NAME, REGION, BRAND, SECTOR,  
						LINK_CONTENT, URL
						
)
------------------------------------- Final View query ---------------------------------------------------
-- Abbreviation used
-- snds : Sends Base Dataset
-- clks : Clicks Base Dataset
-- bnc : Bounce Base Dataset
-- Unsubs : unsubscribes base dataset
-- S_C : Resultant intermediate of Sends and Clicks join
-- S_C_B : Resultant intermediate of Sends , Clicks and bounce join
-- S_C_B_O : Resultant intermediate of Sends , Clicks , bounce and Unsubscribe join

select 
REGION, BRAND, SECTOR, EMAIL_NAME, TIMESTAMP, LINK_CONTENT, URL, COUNTRYCODE, 
CAST(sum(TOTAL_CLICK) as NUMERIC) as TOTAL_CLICK, 
CAST(sum(UNIQUE_CLICKS) as NUMERIC) as UNIQUE_CLICKS,
CAST(sum(TOTAL_OPENS) as NUMERIC) as TOTAL_OPENS, 
CAST(sum(UNIQUE_OPENS) as NUMERIC) as UNIQUE_OPENS,
CAST(sum(SENDS) as NUMERIC) as SENDS
from
	(
select 	S_O.EVENTDATE as TIMESTAMP, S_O.COUNTRYCODE, S_O.EMAIL_NAME,  S_O.REGION, S_O.BRAND, S_O.SECTOR, LINK_CONTENT, URL,
		sum(S_O.SENDS) as SENDS, sum(S_O.TOTAL_OPENS) as TOTAL_OPENS, sum(S_O.UNIQUE_OPENS) as UNIQUE_OPENS,
		sum(TOTAL_CLICK) as TOTAL_CLICK, sum(UNIQUE_CLICKS) as UNIQUE_CLICKS
		from	
				(
				select 	snds.EVENTDATE, snds.COUNTRYCODE, snds.EMAIL_NAME, snds.REGION, snds.BRAND, snds.SECTOR, count(snds.SUBSCRIBER_ID) as SENDS,				
				sum(Opens.TOTAL_OPENS) as TOTAL_OPENS, sum(CASE WHEN Opens.SUBSCRIBER_ID is not null THEN 1 ELSE 0 END) as UNIQUE_OPENS --Calculation of measure 'UNIQUE_OPENS'
				
					from	
						Sends as snds
						left outer join
						Opens
						on 	snds.JOB_ID=Opens.JOB_ID
						and snds.LIST_ID=Opens.LIST_ID
						and snds.BATCH_ID=Opens.BATCH_ID
						and snds.SUBSCRIBER_ID=Opens.SUBSCRIBER_ID
					
				group by
				snds.EVENTDATE, snds.COUNTRYCODE, snds.EMAIL_NAME, snds.REGION, snds.BRAND, snds.SECTOR
				
    )S_O
		left outer join 
		Clicks2 as clks2
		on	coalesce(S_O.EVENTDATE,'1900-01-01')= coalesce(clks2.EVENTDATE,'1900-01-01')
		and coalesce(S_O.COUNTRYCODE,'')= coalesce(clks2.COUNTRYCODE,'')
		and coalesce(S_O.EMAIL_NAME, '')= coalesce(clks2.EMAIL_NAME,'')
		and coalesce(S_O.REGION, '')= coalesce(clks2.REGION,'')
		and coalesce(S_O.BRAND, '')= coalesce(clks2.BRAND,'')
		and coalesce(S_O.SECTOR, '')= coalesce(clks2.SECTOR,'')

	group by S_O.EVENTDATE, S_O.COUNTRYCODE, S_O.EMAIL_NAME,  S_O.REGION, S_O.BRAND, S_O.SECTOR, LINK_CONTENT, URL
)	
group by
REGION, BRAND, SECTOR, EMAIL_NAME, TIMESTAMP, LINK_CONTENT, URL, COUNTRYCODE
