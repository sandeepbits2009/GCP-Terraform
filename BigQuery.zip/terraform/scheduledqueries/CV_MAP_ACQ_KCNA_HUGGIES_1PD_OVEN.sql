




with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
)
Select 
REGION ,
a.COUNTRY_CODE ,
DATE,
IN_AGE_CONSUMERS, 
CATEGORY_PURCHASE_CONSUMERS ,
PRE_CATEGORY_PURCHASE_CONSUMERS, 
OTHER_CONSUMERS , 
country_desc.Country_Code_Desc as COUNTRY_DESC
from 
sfmc_crm_onepd.ACQ_KCNA_HUGGIES_1PD_OVEN a
left join 
country_desc
on a.country_code = country_desc.country_code 
WHERE DATE < '2021-03-31'




