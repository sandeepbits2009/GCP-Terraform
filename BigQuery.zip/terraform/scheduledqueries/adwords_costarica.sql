
SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
   adwords_costarica_huggies.keyword_costarica_huggies_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
   adwords_costarica_kotex.keyword_costarica_kotex_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
    adwords_costarica_plenitud.keyword_costarica_plenitud_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
    adwords_costarica_scott_kleenex.adwords_costarica_scott_kleenex_checker 
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
   impressions
  FROM
    adwords_costarica_scott_kleenex1.adwords_costarica_scott_kleenex_1_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
   adwords_costarica_scott_kleenex2.keyword_costarica_scott_kleenex_2_checker 