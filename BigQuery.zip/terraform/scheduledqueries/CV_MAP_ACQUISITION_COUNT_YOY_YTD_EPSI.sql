






--insert into sfmc_crm_onepd.CV_MAP_ACQUISITION_COUNT_YOY_YTD_EPSI
with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
agg_base as
(
select 
TIMESTAMP,
REGION,
IS_CONTACTABLE,
COUNTRYCODE,
SECTOR,
BRAND,
AGE_IN_MONTHS,
	sum(NO_OF_CONSUMERS) as TOT_CONSUMER,
	case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<0 then 'PREGNANT'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 and upper(region)='KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<6 and upper(region)<>'KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 then 'ACTIVE_BABY'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'OTHER' else '' 
end as CC_JOURNEY_NAME,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<-4 then 'PREGNANT -9 TO -4 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-4 AND AGE_IN_MONTHS<0 then 'PREGNANT -3 TO 0 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 then 'NEWBORN 0 TO 3 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=3 AND AGE_IN_MONTHS<6  and upper(region)<>'KCNA'then 'NEWBORN 3 TO 6 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<12 then 'ACTIVE_BABY 6 TO 12 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=12 AND AGE_IN_MONTHS<24 then 'ACTIVE_BABY 12 TO 24 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=24 AND AGE_IN_MONTHS<36 then 'ACTIVE_BABY 24 TO 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'NO DUE DATE/DOB' else '' 
end as CC_JOURNEY_DETAIL ,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<0 then 'PREGNANT'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 and upper(region)='KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<6 and upper(region)<>'KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 then 'ACTIVE_BABY'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'NO DUE DATE/DOB' else '' 
end as CC_JOURNEY_SUMMARY,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<3 then 'POME'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 and upper(region)='KCNA' then 'ACTIVE_BABY'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=3 AND AGE_IN_MONTHS<36 and upper(region)<>'KCNA' then 'ACTIVE_BABY' else ''
end as CC_JOURNEY_POME_ACTIVEBABY
	from
	sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
	where
((AGE_IN_MONTHS != 888888 ) and sector!= 'BCC'
and REGION="KCNA"  and BRAND != 'NA' 

and upper(IS_CONTACTABLE) in ('TRUE','Y')
and TIMESTAMP >="2021-03-31")
or
((AGE_IN_MONTHS != 888888 ) and SECTOR='BCC' and (AGE_IN_MONTHS between (-9) and (144)) 
and REGION="KCNA"  and BRAND != 'NA' 

and upper(IS_CONTACTABLE) in ('TRUE','Y')
and TIMESTAMP >="2021-03-31")

	
group by 
TIMESTAMP,REGION,IS_CONTACTABLE,COUNTRYCODE,SECTOR,BRAND,AGE_IN_MONTHS


UNION ALL

select 
TIMESTAMP,
REGION,
IS_CONTACTABLE,
COUNTRYCODE,
SECTOR,
BRAND,
AGE_IN_MONTHS,
TOT_CONSUMER,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<0 then 'PREGNANT'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 and upper(region)='KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<6 and upper(region)<>'KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 then 'ACTIVE_BABY'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'OTHER' else '' 
end as CC_JOURNEY_NAME,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<-4 then 'PREGNANT -9 TO -4 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-4 AND AGE_IN_MONTHS<0 then 'PREGNANT -3 TO 0 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 then 'NEWBORN 0 TO 3 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=3 AND AGE_IN_MONTHS<6  and upper(region)<>'KCNA'then 'NEWBORN 3 TO 6 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<12 then 'ACTIVE_BABY 6 TO 12 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=12 AND AGE_IN_MONTHS<24 then 'ACTIVE_BABY 12 TO 24 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=24 AND AGE_IN_MONTHS<36 then 'ACTIVE_BABY 24 TO 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'NO DUE DATE/DOB' else '' 
end as CC_JOURNEY_DETAIL ,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<0 then 'PREGNANT'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 and upper(region)='KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<6 and upper(region)<>'KCNA' then 'NEWBORN'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 then 'ACTIVE_BABY'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'NO DUE DATE/DOB' else '' 
end as CC_JOURNEY_SUMMARY,
case 
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<3 then 'POME'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 and upper(region)='KCNA' then 'ACTIVE_BABY'
    when SECTOR = 'BCC' AND AGE_IN_MONTHS>=3 AND AGE_IN_MONTHS<36 and upper(region)<>'KCNA' then 'ACTIVE_BABY' else ''
end as CC_JOURNEY_POME_ACTIVEBABY

from sfmc_crm_onepd.F_DB_HEALTH_MONTHLY_VALIDATED


where  (AGE_IN_MONTHS != 9999 and AGE_IN_MONTHS >=(-9))
 and TIMESTAMP < '2021-03-31'

and upper(IS_CONTACTABLE) in('TRUE','Y')
and REGION="KCNA" 




),
agg_base2 as 
(

    Select    
    TIMESTAMP, COUNTRYCODE,
	
	CASE WHEN UPPER(IS_CONTACTABLE) = 'TRUE' THEN 'Y' ELSE IS_CONTACTABLE  END AS IS_CONTACTABLE,
	
	BRAND, SECTOR, REGION, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY,
    sum(TOT_CONSUMER) as TOT_CONSUMER_DBH 
    from agg_base  
    group by 
    TIMESTAMP, COUNTRYCODE, 
	IS_CONTACTABLE, BRAND, SECTOR, REGION, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY
    order by 
    TIMESTAMP, COUNTRYCODE,
	
	IS_CONTACTABLE, BRAND, SECTOR, REGION, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY

),
YTD_YoY_data as 
(
select 
COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY,
sum(case when METRIC_TYPE="YOY" then TOT_CONSUMER_DBH else 0 end) as TOT_CONSUMER_DBH_PREV_YEAR,
sum(case when METRIC_TYPE="YTD" then TOT_CONSUMER_DBH else 0 end) as TOT_CONSUMER_DBH_DEC_PREV_YEAR 
from
(
	select 
	COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY,
	sum(TOT_CONSUMER_DBH) as TOT_CONSUMER_DBH, "YOY" as METRIC_TYPE
	from
	agg_base2
	Where 
	TIMESTAMP=LAST_DAY(date_sub(current_date(), interval 13 month), month) 
    group by COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND,CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY

union all

	select 
	COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY,
	sum(TOT_CONSUMER_DBH) as TOT_CONSUMER_DBH, "YTD" as METRIC_TYPE
	from
	agg_base2
    ---- this filter is used to get get where timestamp is 31st dec of the Prev year
	Where 
	TIMESTAMP=LAST_DAY(date_sub(current_date(), interval 1 year), year) 
    group by COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND,CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY

)
group by
 COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY
),
base4 as
(
SELECT  
			base_CCmap_CU.TIMESTAMP,
            base_CCmap_CU.COUNTRYCODE,
            base_CCmap_CU.IS_CONTACTABLE,
            base_CCmap_CU.BRAND,
            base_CCmap_CU.SECTOR,
            base_CCmap_CU.REGION,
            base_Ccmap_CU.TOT_CONSUMER_DBH,
            base_Ccmap_CU.CC_JOURNEY_NAME,
            base_Ccmap_CU.CC_JOURNEY_SUMMARY,
            base_Ccmap_CU.CC_JOURNEY_DETAIL,
            base_Ccmap_CU.CC_JOURNEY_POME_ACTIVEBABY,
			case 
            when base_CCmap_CU.COUNTRYCODE in ('UK','GB') then 'United Kingdom' 
            when base_CCmap_CU.COUNTRYCODE='UN' then 'Unknown' else base_CCmap_CU.COUNTRYCODE_DESC end as COUNTRYCODE_DESC,
			TOT_CONSUMER_DBH_PREV_YEAR,
            TOT_CONSUMER_DBH_DEC_PREV_YEAR,
            TOT_CONSUMER_DBH_PREV_MON,
			---- YTD and YOY calculations are done here
			case when TOT_CONSUMER_DBH_PREV_YEAR = 0 then 0 else ((TOT_CONSUMER_DBH-TOT_CONSUMER_DBH_PREV_YEAR)/TOT_CONSUMER_DBH_PREV_YEAR) end as YOY_GROWTH_RATE,
			case when TOT_CONSUMER_DBH_DEC_PREV_YEAR = 0 then 0 else ((TOT_CONSUMER_DBH-TOT_CONSUMER_DBH_DEC_PREV_YEAR)/TOT_CONSUMER_DBH_DEC_PREV_YEAR) end as YTD_GROWTH_RATE,
            case when TOT_CONSUMER_DBH_PREV_MON = 0 then 0 else ((TOT_CONSUMER_DBH - TOT_CONSUMER_DBH_PREV_MON )/ TOT_CONSUMER_DBH_PREV_MON) end as TOT_CONSUMER_DBH_GROWTH
			from   
                    (
                    select 
					base_Ccmap.TIMESTAMP,
                    base_Ccmap.COUNTRYCODE,
                    base_Ccmap.IS_CONTACTABLE,
                    base_Ccmap.BRAND,
                    base_Ccmap.SECTOR,
                    base_Ccmap.REGION,
                    base_Ccmap.CC_JOURNEY_NAME,
                    base_Ccmap.CC_JOURNEY_SUMMARY,
                    base_Ccmap.CC_JOURNEY_DETAIL,
                    base_Ccmap.CC_JOURNEY_POME_ACTIVEBABY,
                    base_Ccmap.TOT_CONSUMER_DBH,
					base_Ccmap.COUNTRYCODE_DESC,
					PREV_month.TOT_CONSUMER_DBH   as TOT_CONSUMER_DBH_PREV_MON
					from
                            (
                            select 
							TIMESTAMP, COUNTRYCODE,
							IS_CONTACTABLE, BRAND, SECTOR, REGION, CC_JOURNEY_NAME, CC_JOURNEY_SUMMARY, CC_JOURNEY_DETAIL, CC_JOURNEY_POME_ACTIVEBABY,
                            TOT_CONSUMER_DBH,
							Country_Code_Desc as COUNTRYCODE_DESC
							from 
							(select * from agg_base2 where TIMESTAMP=last_day(date_sub(current_date(), interval 1 month))) as base
							left join 
							country_desc desc_map
							on
							base.COUNTRYCODE=desc_map.country_code
                            ) base_Ccmap
                            left join
					--- Interval is set to 2 so to get previous month data
					        (select * from agg_base2 where TIMESTAMP=last_day(date_sub(current_date(), interval 2 month))) PREV_month
					         on
					         base_Ccmap.COUNTRYCODE=PREV_month.COUNTRYCODE and
					         base_Ccmap.IS_CONTACTABLE=PREV_month.IS_CONTACTABLE and
					         base_Ccmap.REGION=PREV_month.REGION and 
					         base_Ccmap.BRAND=PREV_month.BRAND and 
					         base_Ccmap.SECTOR=PREV_month.SECTOR and 
							 base_Ccmap.CC_JOURNEY_NAME=PREV_month.CC_JOURNEY_NAME and
							 base_Ccmap.CC_JOURNEY_SUMMARY=PREV_month.CC_JOURNEY_SUMMARY and
							 base_Ccmap.CC_JOURNEY_DETAIL=PREV_month.CC_JOURNEY_DETAIL and
							 base_Ccmap.CC_JOURNEY_POME_ACTIVEBABY=PREV_month.CC_JOURNEY_POME_ACTIVEBABY
							 
                    )base_CCmap_CU
				---- join here is performed without timestamp because this level has been removed in YTD_YoY_data subquery 
			left join
            YTD_YoY_data on
			base_Ccmap_CU.COUNTRYCODE=YTD_YoY_data.COUNTRYCODE and
			base_Ccmap_CU.IS_CONTACTABLE=YTD_YoY_data.IS_CONTACTABLE and
			base_Ccmap_CU.REGION=YTD_YoY_data.REGION and 
			base_CCmap_CU.BRAND=YTD_YoY_data.BRAND and 
            base_CCmap_CU.SECTOR=YTD_YoY_data.SECTOR and
			base_CCmap_CU.CC_JOURNEY_NAME=YTD_YoY_data.CC_JOURNEY_NAME and
			base_CCmap_CU.CC_JOURNEY_SUMMARY=YTD_YoY_data.CC_JOURNEY_SUMMARY and
			base_CCmap_CU.CC_JOURNEY_DETAIL=YTD_YoY_data.CC_JOURNEY_DETAIL and
			base_CCmap_CU.CC_JOURNEY_POME_ACTIVEBABY=YTD_YoY_data.CC_JOURNEY_POME_ACTIVEBABY



),

base5 as
(
Select 
case when base4.TIMESTAMP is null then  f_text.TIMESTAMP else base4.TIMESTAMP end as TIMESTAMP,
case when base4.COUNTRYCODE is null then  f_text.COUNTRYCODE else base4.COUNTRYCODE end as COUNTRYCODE,
case when base4.IS_CONTACTABLE is null then  f_text.IS_CONTACTABLE else base4.IS_CONTACTABLE end as IS_CONTACTABLE,
case when base4.BRAND is null then  f_text.BRAND else base4.BRAND end as BRAND,
case when base4.SECTOR is null then  f_text.SECTOR else base4.SECTOR end as SECTOR,
case when base4.REGION is null then  f_text.REGION else base4.REGION end as REGION,

case when base4.CC_JOURNEY_NAME is null then  f_text.CC_JOURNEY_NAME else base4.CC_JOURNEY_NAME end as CC_JOURNEY_NAME,
case when base4.CC_JOURNEY_SUMMARY is null then  f_text.CC_JOURNEY_SUMMARY else base4.CC_JOURNEY_SUMMARY end as CC_JOURNEY_SUMMARY,
case when base4.CC_JOURNEY_DETAIL is null then  f_text.CC_JOURNEY_DETAIL else base4.CC_JOURNEY_DETAIL end as CC_JOURNEY_DETAIL,
case when base4.CC_JOURNEY_POME_ACTIVEBABY is null then  f_text.CC_JOURNEY_POME_ACTIVEBABY else base4.CC_JOURNEY_POME_ACTIVEBABY end as CC_JOURNEY_POME_ACTIVEBABY,
f_text.Tot_Consumer_YTD,
f_text.tot_consumer,
base4.COUNTRYCODE_DESC,
base4.TOT_CONSUMER_DBH_PREV_YEAR,
base4.TOT_CONSUMER_DBH_DEC_PREV_YEAR,
base4.TOT_CONSUMER_DBH_PREV_MON,
base4.YOY_GROWTH_RATE,
base4.YTD_GROWTH_RATE,
base4.TOT_CONSUMER_DBH_GROWTH,
base4.TOT_CONSUMER_DBH,
case 
	  when base4.TOT_CONSUMER_DBH_PREV_MON = 0 then '0'
	  when ((base4.TOT_CONSUMER_DBH - base4.TOT_CONSUMER_DBH_PREV_MON)/base4.TOT_CONSUMER_DBH_PREV_MON)<= -0.02 then 'Red'
	  when base4.TOT_CONSUMER_DBH=base4.TOT_CONSUMER_DBH_PREV_MON then 'Yellow'
	  when base4.TOT_CONSUMER_DBH_GROWTH > 0.2 then 'Light Green'
	  else 'White'
end as TOT_CONS_CHECK,
from 
base4 full outer join (select * from  sfmc_crm_onepd.CV_MAP_ACQUISITION_COUNT_F_TEXT_EPSI where TIMESTAMP=last_day(date_sub(current_date(), interval 1 month))) as f_text
on 
base4.TIMESTAMP =	  f_text.TIMESTAMP and
trim(lower(base4.COUNTRYCODE)) =	trim(lower(f_text.COUNTRYCODE ))and
trim(lower(base4.IS_CONTACTABLE)) =	trim(lower(f_text.IS_CONTACTABLE)) and
trim(lower(base4.BRAND)) =	        trim(lower(f_text.BRAND)) and
trim(lower(base4.SECTOR)) =      	trim(lower(f_text.SECTOR)) and
trim(lower(base4.REGION ))=	        trim(lower(f_text.REGION)) and
trim(lower(base4.CC_JOURNEY_NAME)) =trim(lower(f_text.CC_JOURNEY_NAME)) and
trim(lower(base4.CC_JOURNEY_SUMMARY ))=	 trim(lower(f_text.CC_JOURNEY_SUMMARY)) and
trim(lower(base4.CC_JOURNEY_DETAIL)) =	 trim(lower(f_text.CC_JOURNEY_DETAIL)) and
trim(lower(base4.CC_JOURNEY_POME_ACTIVEBABY ))=	 trim(lower(f_text.CC_JOURNEY_POME_ACTIVEBABY))
)
select 
TIMESTAMP	,
COUNTRYCODE	,
REGION	,
SECTOR	,
BRAND	,
IS_CONTACTABLE	,
CC_JOURNEY_NAME	,
CC_JOURNEY_SUMMARY	,
CC_JOURNEY_DETAIL	,
CC_JOURNEY_POME_ACTIVEBABY	,
EXTRACT(YEAR from TIMESTAMP) as YEAR,
EXTRACT(MONTH from TIMESTAMP) as MONTH,
COUNTRYCODE_DESC	,
TOT_CONS_CHECK	,
TOT_CONSUMER	,
TOT_CONSUMER_YTD	,
YOY_GROWTH_RATE	,
YTD_GROWTH_RATE	,
cast(TOT_CONSUMER_DBH as INT64) as TOT_CONSUMER_DBH	,
cast(TOT_CONSUMER_DBH_PREV_YEAR as INT64) as TOT_CONSUMER_DBH_PREV_YR	,
cast(TOT_CONSUMER_DBH_DEC_PREV_YEAR as INT64) as TOT_CONSUMER_DBH_DEC_PREV_YR	,
cast(TOT_CONSUMER_DBH_PREV_MON as INT64) as TOT_CONSUMER_DBH_PREV_MON	,
TOT_CONSUMER_DBH_GROWTH	
from base5



