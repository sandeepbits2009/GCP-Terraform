

--insert into sfmc_crm_onepd.CV_MAP_UNIQUE_CONSUMER_BRAND_EPSI 

--------   Comments are written in top  of the code , wherever needed -----------

---------------------------------
---Adjust dataset name everywhere
with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
--- Aggregating data at the required level
--- this subquery will process 2 months of data
--- Reminder : Add filter to get data dynamically

Agg_base as
(
select 
Timestamp, 
Countrycode, 
is_contactable, 
Brand, 
sector, 
region, 
no_of_consumers, 
Tot_consumer, 
active_no_of_consumers,
EXTRACT(MONTH from TIMESTAMP) as MONTH,
EXTRACT(YEAR from TIMESTAMP) as YEAR
from
(
SELECT 
Region, 
Timestamp, 
Countrycode, 
Brand, 
Sector, 
Is_contactable, 
sum(No_OF_CONSUMERS) as No_OF_CONSUMERS, 
sum(No_OF_CONSUMERS) as TOT_CONSUMER, 
sum(ENGAGED_CONSUMER_COUNT) as ACTIVE_NO_OF_CONSUMERS
from
sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
where BRAND <> 'NA'
and Timestamp >= "2021-03-31"
and 
(
(upper(REGION)='KCNA' and SECTOR='BCC' and AGE_IN_MONTHS=9999)
OR 
(upper(REGION)='KCNA' and SECTOR<>'BCC')
)
group by 
Region, 
Timestamp, 
Countrycode, 
Brand, 
Sector, 
Is_contactable
order by 
Region, 
Timestamp, 
Countrycode, 
Brand, 
Sector, 
Is_contactable
)

UNION ALL 

SELECT 

Timestamp, 
Countrycode, 
is_contactable, 
Brand, 
sector, 
region, 
sum(No_OF_CONSUMERS) as No_OF_CONSUMERS, 
sum(No_OF_CONSUMERS) as TOT_CONSUMER, 
sum(ACTIVE_NO_OF_CONSUMERS) as ACTIVE_NO_OF_CONSUMERS,
EXTRACT(MONTH from TIMESTAMP) as MONTH,
EXTRACT(YEAR from TIMESTAMP) as YEAR
from 
sfmc_crm_onepd.F_DB_HEALTH_MONTHLY_VALIDATED
where Timestamp < "2021-03-31"
and region = 'KCNA'
and 
(
(upper(REGION)='KCNA' and SECTOR='BCC' and AGE_IN_MONTHS=9999)
OR 
(upper(REGION)='KCNA' and SECTOR<>'BCC')
)

group by 
Region, 
Timestamp, 
Countrycode, 
Brand, 
Sector, 
Is_contactable
order by 
Region, 
Timestamp, 
Countrycode, 
Brand, 
Sector, 
Is_contactable
),

---- This query takes care of the metrics need to get YTD and YOY numbers
---- Query contains a union of data from same moth prev year and december of previous year

YTD_YoY_data as 
(
select 
COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND,
sum(case when METRIC_TYPE="YOY" then TOT_CONSUMER else 0 end) as TOT_CONSUMER_PREV_YEAR,
sum(case when METRIC_TYPE="YTD" then TOT_CONSUMER else 0 end) as TOT_CONSUMER_DEC_PREV_YEAR 
from
(
	select 
	COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND,
	sum(No_OF_CONSUMERS) as TOT_CONSUMER, "YOY" as METRIC_TYPE
	from
	--sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    Agg_base
	Where 
    TIMESTAMP=LAST_DAY(date_sub(current_date(), interval 13 month), month) 
    
    group by 
    COUNTRYCODE,
    IS_CONTACTABLE,
    REGION,
    SECTOR,
    BRAND

union all

	select 
	COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND,
	sum(No_OF_CONSUMERS) as TOT_CONSUMER, "YTD" as METRIC_TYPE
	from
	--sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    ---- this filter is used to get get where timestamp is 31st dec of the Prev year
    Agg_base
	Where 
    TIMESTAMP=LAST_DAY(date_sub(current_date(), interval 1 year), year) 
    
    group by COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND

)
group by
COUNTRYCODE,IS_CONTACTABLE,REGION,SECTOR,BRAND
),

WIC_metrics as
(

select 
TIMESTAMP,COUNTRYCODE,BRAND,SECTOR,REGION,
sum(TOT_CONSUMER) as TOT_CONSUMER,
sum(ACTIVE_NO_OF_CONSUMERS) as ACTIVE_NO_OF_CONSUMERS


from Agg_base where REGION="KCNA" and TIMESTAMP=last_day(date_sub(current_date(), interval 1 month))

group by TIMESTAMP,COUNTRYCODE,BRAND,SECTOR,REGION

)


----- Main query starts here

select 
TIMESTAMP,
COUNTRYCODE,
IS_CONTACTABLE as ISCONTACTABLE,
BRAND,
SECTOR,
REGION,
case when (REGION='KCNA' AND upper(IS_CONTACTABLE)='N') or (REGION='KCNA' AND upper(IS_CONTACTABLE)='FALSE') then TOT_CONSUMER_AGG_WIC else TOT_CONSUMER end as NO_OF_CONSUMERS,
----Modifying TOT_CONSUMER and ACTIVE_NO_OF_CONSUMERS
case when (REGION='KCNA' AND upper(IS_CONTACTABLE)='N') or (REGION='KCNA' AND upper(IS_CONTACTABLE)='FALSE') then TOT_CONSUMER_AGG_WIC else TOT_CONSUMER end as TOT_CONSUMER,
case when (REGION='KCNA' AND upper(IS_CONTACTABLE)='N') or (REGION='KCNA' AND upper(IS_CONTACTABLE)='FALSE') then ACTIVE_NO_OF_CONSUMERS_AGG_WIC else ACTIVE_NO_OF_CONSUMERS end as ACTIVE_NO_OF_CONSUMERS,

----- Creating UNENGAGED_CONSUMERS  metrics
case 
when (upper(IS_CONTACTABLE)='Y' or upper(IS_CONTACTABLE)='TRUE') then ACTIVE_NO_OF_CONSUMERS*(-1) else  ACTIVE_NO_OF_CONSUMERS end as UNENGAGED_CONSUMERS,


--- Modifying IS_CONTACTABLE
case 
when upper(IS_CONTACTABLE)='Y' or upper(IS_CONTACTABLE)='TRUE' then 'With Opt In'
when upper(IS_CONTACTABLE)='N' or upper(IS_CONTACTABLE)='FALSE' then 'Total' end as IS_CONTACTABLE,

---- corrections need for country code are done below 
case 
when COUNTRYCODE in ('UK','GB') then 'United Kingdom' 
when COUNTRYCODE='UN' then 'Unknown' else COUNTRYCODE_DESC end as COUNTRYCODE_DESC,
MONTH,
YEAR,
TOT_CONSUMER_PREV,
NO_OF_CONSUMERS_PREV,
YOY_GROWTH_RATE,
YTD_GROWTH_RATE,
TOT_CONSUMER_DEC_PREV_YEAR,
TOT_CONSUMER_PREV_YEAR,
TOT_CONSUMER_NON_CUM,
TOT_CONSUMER_AGG_WIC,
ACTIVE_NO_OF_CONSUMERS_AGG_WIC,

---Duplicated columns
ACTIVE_NO_OF_CONSUMERS as ACTIVE_NO_OF_CONSUMERS_BASE,
TOT_CONSUMER as TOT_CONSUMER_BASE ,
MONTH as MONTH_PREV,
MONTH as MONTH_PREV_YEAR,
YEAR as YEAR_PREV ,
YEAR as YEAR_PREV_YEAR

from
	(
	select
	base_CCmap_CU_YY.TIMESTAMP,
    base_CCmap_CU_YY.COUNTRYCODE,
    base_CCmap_CU_YY.IS_CONTACTABLE,
    base_CCmap_CU_YY.BRAND,
    base_CCmap_CU_YY.SECTOR,
    base_CCmap_CU_YY.REGION,
    base_CCmap_CU_YY.TOT_CONSUMER,
    base_CCmap_CU_YY.NO_OF_CONSUMERS,
    base_CCmap_CU_YY.ACTIVE_NO_OF_CONSUMERS, 
    base_CCmap_CU_YY.MONTH,
    base_CCmap_CU_YY.YEAR,
    base_CCmap_CU_YY.COUNTRYCODE_DESC,
    base_CCmap_CU_YY.TOT_CONSUMER_PREV,
    base_CCmap_CU_YY.NO_OF_CONSUMERS_PREV,
    base_CCmap_CU_YY.YOY_GROWTH_RATE,
    base_CCmap_CU_YY.YTD_GROWTH_RATE,
    base_CCmap_CU_YY.TOT_CONSUMER_DEC_PREV_YEAR,
    base_CCmap_CU_YY.TOT_CONSUMER_PREV_YEAR,
    base_CCmap_CU_YY.TOT_CONSUMER_NON_CUM,
	WIC_metrics.TOT_CONSUMER as TOT_CONSUMER_AGG_WIC,
    WIC_metrics.ACTIVE_NO_OF_CONSUMERS as ACTIVE_NO_OF_CONSUMERS_AGG_WIC 

	from
		(
			select 
			base_CCmap_CU.TIMESTAMP,
            base_CCmap_CU.COUNTRYCODE,
            base_CCmap_CU.IS_CONTACTABLE,
            base_CCmap_CU.BRAND,
            base_CCmap_CU.SECTOR,
            base_CCmap_CU.REGION,
            base_CCmap_CU.TOT_CONSUMER,
            base_CCmap_CU.NO_OF_CONSUMERS,
            base_CCmap_CU.ACTIVE_NO_OF_CONSUMERS,
			MONTH,
            YEAR,
			COUNTRYCODE_DESC,
			TOT_CONSUMER_PREV,
            NO_OF_CONSUMERS_PREV,
            TOT_CONSUMER_PREV_YEAR,
            TOT_CONSUMER - TOT_CONSUMER_PREV as TOT_CONSUMER_NON_CUM,
			---- YTD and YOY calculations are done here
			case when TOT_CONSUMER_PREV_YEAR = 0 then 0 else ((TOT_CONSUMER-TOT_CONSUMER_PREV_YEAR)/TOT_CONSUMER_PREV_YEAR) end as YOY_GROWTH_RATE,
			case when TOT_CONSUMER_DEC_PREV_YEAR = 0 then 0 else ((TOT_CONSUMER-TOT_CONSUMER_DEC_PREV_YEAR)/TOT_CONSUMER_DEC_PREV_YEAR) end as YTD_GROWTH_RATE,
			TOT_CONSUMER_DEC_PREV_YEAR
			from   
				(
					select 
					base_Ccmap.TIMESTAMP,base_Ccmap.COUNTRYCODE,base_Ccmap.IS_CONTACTABLE,base_Ccmap.BRAND,base_Ccmap.SECTOR,base_Ccmap.REGION,base_Ccmap.TOT_CONSUMER,base_Ccmap.NO_OF_CONSUMERS,base_Ccmap.ACTIVE_NO_OF_CONSUMERS,
					base_Ccmap.MONTH,base_Ccmap.YEAR,
					COUNTRYCODE_DESC,
					
					PREV_month.TOT_CONSUMER as TOT_CONSUMER_PREV,PREV_month.NO_OF_CONSUMERS as NO_OF_CONSUMERS_PREV ,
					
					------ Below are all the calculations used to get non cumulative numbers
					(base_Ccmap.TOT_CONSUMER-PREV_month.TOT_CONSUMER) as TOT_CONSUMER_NON_CUM
	
					from
						(
							select 
							TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,BRAND,SECTOR,REGION,TOT_CONSUMER,NO_OF_CONSUMERS,ACTIVE_NO_OF_CONSUMERS,
							MONTH,YEAR,
							Country_Code_Desc as COUNTRYCODE_DESC
							from 
							(select * from Agg_base where TIMESTAMP=last_day(date_sub(current_date(), interval 1 month))) as base
							left join 
							country_desc desc_map
							on
							base.COUNTRYCODE=desc_map.country_code
	
						) base_CCmap
					left join
					--- Interval is set to 2 so to get previous month data
					(select * from Agg_base where TIMESTAMP=last_day(date_sub(current_date(), interval 2 month))) PREV_month
					on
					base_Ccmap.COUNTRYCODE=PREV_month.COUNTRYCODE and
					base_Ccmap.IS_CONTACTABLE=PREV_month.IS_CONTACTABLE and
					base_Ccmap.REGION=PREV_month.REGION and 
					base_Ccmap.BRAND=PREV_month.BRAND and 
					base_Ccmap.SECTOR=PREV_month.SECTOR  
                    
					
				)base_CCmap_CU
			left join
			YTD_YoY_data 
			---- join here is performed without timestamp because this level has been removed in YTD_YoY_data subquery 
			on
			base_Ccmap_CU.COUNTRYCODE=YTD_YoY_data.COUNTRYCODE and
			base_Ccmap_CU.IS_CONTACTABLE=YTD_YoY_data.IS_CONTACTABLE and
			base_Ccmap_CU.REGION=YTD_YoY_data.REGION and 
			base_CCmap_CU.BRAND=YTD_YoY_data.BRAND and 
			base_CCmap_CU.SECTOR=YTD_YoY_data.SECTOR 
            
		)base_CCmap_CU_YY
	left join
	WIC_metrics 
	---- join here is performed for without is_contactable metrics
	on
	base_CCmap_CU_YY.COUNTRYCODE=WIC_metrics.COUNTRYCODE and
	base_CCmap_CU_YY.REGION=WIC_metrics.REGION and 
	base_CCmap_CU_YY.BRAND=WIC_metrics.BRAND and 
	base_CCmap_CU_YY.SECTOR=WIC_metrics.SECTOR 
)





