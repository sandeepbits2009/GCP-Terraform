
--insert into sfmc_crm_onepd.CV_MAP_ACQUISITION_DATASOURCE_F
with 
base as
(
    select 
	TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,DATASOURCE,sum(TOT_COUNT) as TOT_COUNT,MKT_EVENT,BRAND,SECTOR,REGION, cast(AGE_IN_MONTHS as INT64) as AGE_IN_MONTHS ,MKT_SUBEVENT,DATASOURCE_TYPE


    from sfmc_crm_onepd.F_CONSUMER_ACQUISITIONS_DATASOURCE_COUNTS_VALIDATED
	where  --TIMESTAMP>last_day(date_sub(current_date(), interval 1 month))
  TIMESTAMP between date_sub(date_sub(current_date(), INTERVAL 1 day), interval 6 month) and date_sub(current_date(), INTERVAL 2 day)
	AND COUNTRYCODE in ('HK','IN','MY','PH','SG','TH','TW','VN')

    group by 
    TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,DATASOURCE,MKT_EVENT,BRAND,SECTOR,REGION,AGE_IN_MONTHS,MKT_SUBEVENT,DATASOURCE_TYPE

),
time_dimension as 
(
	select 
	DATE_SQL,
    YEAR as YEAR_ACQ_COUNT,
    QUARTER as QUARTER_ACQ_COUNT,
    MONTH as MONTH_ACQ_COUNT,
    WEEK as WEEK_ACQ_COUNT
	
	from sfmc_crm_onepd.time_dimension
	where DATE_SQL  between last_day(date_sub(current_date(), interval 14 month)) and current_date()
	
),
DS_map as
(
	select 
	DATASOURCE,MKT_EVENT,BRAND,SECTOR,REGION,MARKETING_SUB_EVENT,SOURCE_BRAND

	from 
	
	sfmc_crm_onepd.ACQ_DATASOURCE_LOOKUP

	group by 
	DATASOURCE,MKT_EVENT,BRAND,SECTOR,REGION,MARKETING_SUB_EVENT,SOURCE_BRAND

),
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
---Aggeregating without is_contactable field to prepare data for customer count correction

cc_correction as
(
    select 
	TIMESTAMP,COUNTRYCODE,DATASOURCE,sum(TOT_COUNT) as TOT_COUNT_CC,MKT_EVENT,BRAND,SECTOR,REGION,AGE_IN_MONTHS   ,MKT_SUBEVENT,DATASOURCE_TYPE


    from base

   Where REGION='KCNA' and --TIMESTAMP>last_day(date_sub(current_date(), interval 1 month))
  TIMESTAMP between date_sub(date_sub(current_date(), INTERVAL 1 day), interval 6 month) and date_sub(current_date(), INTERVAL 2 day)
	AND COUNTRYCODE in ('HK','IN','MY','PH','SG','TH','TW','VN')
    group by 
    TIMESTAMP,COUNTRYCODE,DATASOURCE,MKT_EVENT,BRAND,SECTOR,REGION,AGE_IN_MONTHS,MKT_SUBEVENT,DATASOURCE_TYPE

)

select 
TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,
YEAR_ACQ_COUNT,QUARTER_ACQ_COUNT,MONTH_ACQ_COUNT,WEEK_ACQ_COUNT,
SECTOR,REGION,BRAND,AGE_IN_MONTHS,
CASE WHEN COUNTRYCODE IN ('GB','UK') THEN 'United Kingdom' 
     WHEN COUNTRYCODE = 'UN' THEN 'Unknown'
     ELSE Country_Code_Desc END AS COUNTRYCODE_DESC ,

FLOOR(AGE_IN_MONTHS/12)   as CC_AGE_IN_YEAR,
case when upper(IS_CONTACTABLE) in ('Y','TRUE') then 'With Opt-In' else 'Total' end as CC_CONTACTABLE,

case 
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<=-7 then '-9 TO -7 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-6 AND AGE_IN_MONTHS<=-4 then '-6 TO -4 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=-3 AND AGE_IN_MONTHS<=-1 then '-3 TO -1 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<=2 then '0 TO 2 M'
when SECTOR = 'BCC' AND REGION!='KCNA' AND AGE_IN_MONTHS>=3 AND AGE_IN_MONTHS<=5 then '3 TO 5 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<=8 then '6 TO 8 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=9 AND AGE_IN_MONTHS<=11 then '9 TO 11 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=12 AND AGE_IN_MONTHS<=14 then '12 TO 14 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=15 AND AGE_IN_MONTHS<=17 then '15 TO 17 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=18 AND AGE_IN_MONTHS<=20 then '18 TO 20 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=21 AND AGE_IN_MONTHS<=23 then '21 TO 23 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=24 AND AGE_IN_MONTHS<=26 then '24 TO 26 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=27 AND AGE_IN_MONTHS<=29 then '27 TO 29 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=30 AND AGE_IN_MONTHS<=32 then '30 TO 32 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=33 AND AGE_IN_MONTHS<=35 then '33 TO 35 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!= 999999999 then 'MORE THAN 36 M'
when SECTOR = 'BCC' AND AGE_IN_MONTHS= 999999999 then 'NO DUE DATE/DOB' else '' end as CC_Journey,

case when AGE_IN_MONTHS>=-9 AND AGE_IN_MONTHS<0 then TOT_COUNT else 0 end as CC_TOT_PREGNANT_9_TO_0,

case
when COUNTRYCODE in ('US','CA') and AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<3 then TOT_COUNT
when COUNTRYCODE not in ('US','CA') and AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<6 then TOT_COUNT else 0 end as CC_TOT_NEW_BORN_0_TO_6,

case when AGE_IN_MONTHS>=6 AND AGE_IN_MONTHS<36 then TOT_COUNT else 0 end as CC_TOT_ACTIVE_BABY_6_TO_36,
case when AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS!=999999999 then TOT_COUNT else 0 end as CC_TOT_MORE_36 ,

case when AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS<39 then TOT_COUNT else 0 end as CC_TOT_MONTH_36_TO_39,
case when AGE_IN_MONTHS>=39 AND AGE_IN_MONTHS<42 then TOT_COUNT else 0 end as CC_TOT_MONTH_39_TO_42,
case when AGE_IN_MONTHS>=42 AND AGE_IN_MONTHS<45 then TOT_COUNT else 0 end as CC_TOT_MONTH_42_TO_45,
case when AGE_IN_MONTHS>=45 AND AGE_IN_MONTHS<48 then TOT_COUNT else 0 end as CC_TOT_MONTH_45_TO_48,
case when AGE_IN_MONTHS>=48 AND AGE_IN_MONTHS<51 then TOT_COUNT else 0 end as CC_TOT_MONTH_48_TO_51,
case when AGE_IN_MONTHS>=51 AND AGE_IN_MONTHS<54 then TOT_COUNT else 0 end as CC_TOT_MONTH_51_TO_54,
case when AGE_IN_MONTHS>=54 AND AGE_IN_MONTHS<57 then TOT_COUNT else 0 end as CC_TOT_MONTH_54_TO_57,
case when AGE_IN_MONTHS>=57 AND AGE_IN_MONTHS<60 then TOT_COUNT else 0 end as CC_TOT_MONTH_57_TO_60,
case when AGE_IN_MONTHS>=60 AND AGE_IN_MONTHS<72 then TOT_COUNT else 0 end as CC_TOT_YEAR_5_TO_6,
case when AGE_IN_MONTHS>=72 AND AGE_IN_MONTHS<84 then TOT_COUNT else 0 end as CC_TOT_YEAR_6_TO_7,
case when AGE_IN_MONTHS>=84 AND AGE_IN_MONTHS<96 then TOT_COUNT else 0 end as CC_TOT_YEAR_7_TO_8,
case when AGE_IN_MONTHS>=96 AND AGE_IN_MONTHS<108 then TOT_COUNT else 0 end as CC_TOT_YEAR_8_TO_9,
case when AGE_IN_MONTHS>=108 AND AGE_IN_MONTHS<120 then TOT_COUNT else 0 end as CC_TOT_YEAR_9_TO_10,
case when AGE_IN_MONTHS>=120 AND AGE_IN_MONTHS<132 then TOT_COUNT else 0 end as CC_TOT_YEAR_10_TO_11,
case when AGE_IN_MONTHS>=132 AND AGE_IN_MONTHS<144 then TOT_COUNT else 0 end as CC_TOT_YEAR_11_TO_12,
case when AGE_IN_MONTHS>=-12 AND AGE_IN_MONTHS<0 then TOT_COUNT else 0 end as CC_TOT_YEAR__1_TO_0,
case when AGE_IN_MONTHS>=0 AND AGE_IN_MONTHS<12 then TOT_COUNT else 0 end as CC_TOT_YEAR_0_TO_1,
case when AGE_IN_MONTHS>=12 AND AGE_IN_MONTHS<24 then TOT_COUNT else 0 end as CC_TOT_YEAR_1_TO_2,
case when AGE_IN_MONTHS>=24 AND AGE_IN_MONTHS<36 then TOT_COUNT else 0 end as CC_TOT_YEAR_2_TO_3,
case when AGE_IN_MONTHS>=36 AND AGE_IN_MONTHS<48 then TOT_COUNT else 0 end as CC_TOT_YEAR_3_TO_4,

TOT_COUNT,
CASE WHEN MKT_SUBEVENT IS NULL THEN 'Not Available' 
	 WHEN TRIM(MKT_SUBEVENT) = '' THEN 'Unclassified'
	 ELSE MKT_SUBEVENT END AS MKT_SUBEVENT,
CASE WHEN MKT_EVENT IS NULL THEN 'Not Available' 
	 WHEN TRIM(MKT_EVENT) = '' THEN 'Unclassified'
	 ELSE MKT_EVENT END AS MKT_EVENT,
DATASOURCE_TYPE,
DATASOURCE,
CASE WHEN SOURCE_BRAND IS NULL THEN 'Not Available' 
	 WHEN TRIM(SOURCE_BRAND) = '' THEN 'Unclassified'
	 ELSE SOURCE_BRAND END AS SOURCE_BRAND, 
cast(Null as string) as APPLICATION_SOURCETYPE


from
    (
	select
	TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,AGE_IN_MONTHS,TOT_COUNT,
	Country_Code_Desc,
	YEAR_ACQ_COUNT,QUARTER_ACQ_COUNT,MONTH_ACQ_COUNT,WEEK_ACQ_COUNT,
	corr_base_cc_TS.DATASOURCE,corr_base_cc_TS.BRAND,corr_base_cc_TS.SECTOR,corr_base_cc_TS.REGION,corr_base_cc_TS.DATASOURCE_TYPE,
	case when corr_base_cc_TS.REGION='KCNA' then DS_map.MARKETING_SUB_EVENT else corr_base_cc_TS.MKT_SUBEVENT end as MKT_SUBEVENT,
	case when corr_base_cc_TS.REGION='KCNA' then DS_map.MKT_EVENT else corr_base_cc_TS.MKT_EVENT end as MKT_EVENT,
	SOURCE_BRAND
	from	
		(
			select 
			TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,DATASOURCE,MKT_EVENT,BRAND,SECTOR,REGION,AGE_IN_MONTHS,MKT_SUBEVENT,DATASOURCE_TYPE,TOT_COUNT,
			Country_Code_Desc,
			YEAR_ACQ_COUNT,QUARTER_ACQ_COUNT,MONTH_ACQ_COUNT,WEEK_ACQ_COUNT
			from
				(
					select 
					TIMESTAMP,COUNTRYCODE,IS_CONTACTABLE,DATASOURCE,MKT_EVENT,BRAND,SECTOR,REGION,AGE_IN_MONTHS,MKT_SUBEVENT,DATASOURCE_TYPE,TOT_COUNT,
					Country_Code_Desc
					from
						(
							select 
							base.TIMESTAMP,base.COUNTRYCODE,base.IS_CONTACTABLE,base.DATASOURCE,base.MKT_EVENT,base.BRAND,base.SECTOR,base.REGION,base.AGE_IN_MONTHS,base.MKT_SUBEVENT,base.DATASOURCE_TYPE,
							COALESCE(case when base.REGION='KCNA' and UPPER(IS_CONTACTABLE) IN ('FALSE','N') then TOT_COUNT_CC else TOT_COUNT end,0) as TOT_COUNT
							from
							base
							left join
							cc_correction
							on
							base.TIMESTAMP=cc_correction.TIMESTAMP and 
							base.COUNTRYCODE=cc_correction.COUNTRYCODE and
							base.DATASOURCE=cc_correction.DATASOURCE and
							base.MKT_EVENT=cc_correction.MKT_EVENT and
							base.BRAND=cc_correction.BRAND and
							base.SECTOR=cc_correction.SECTOR and
							base.REGION=cc_correction.REGION and
							base.AGE_IN_MONTHS=cc_correction.AGE_IN_MONTHS and
							base.MKT_SUBEVENT=cc_correction.MKT_SUBEVENT and
							base.DATASOURCE_TYPE=cc_correction.DATASOURCE_TYPE
						) corr_base
					left join
					country_desc desc_map
					on
					corr_base.COUNTRYCODE=desc_map.country_code
					)corr_base_w_cc
			inner join 
			time_dimension TD_map
			on
			corr_base_w_cc.TIMESTAMP=TD_map.DATE_SQL
		)corr_base_cc_TS
	left join
	DS_map
	on
	corr_base_cc_TS.DATASOURCE=DS_map.DATASOURCE and
	corr_base_cc_TS.BRAND=DS_map.BRAND and
	corr_base_cc_TS.SECTOR=DS_map.SECTOR and
	corr_base_cc_TS.REGION=DS_map.REGION
  Where TIMESTAMP between date_sub(date_sub(current_date(), INTERVAL 1 day), interval 6 month) and date_sub(current_date(), INTERVAL 2 day)
	AND COUNTRYCODE in ('HK','IN','MY','PH','SG','TH','TW','VN')
)