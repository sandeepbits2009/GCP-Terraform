


--insert into sfmc_crm_onepd.CV_MAP_UTILIZATION_UNIQUE_COUNTRY_TREND_KCNA


with 
country_desc as
(
    select 
    LAND1 as country_code,LANDX as Country_Code_Desc

    from 
    `sfmc_email.T005T`

    where SPRAS='E'
    group by 
    country_code,Country_Code_Desc
),
unique_consumer 
as
(   Select 
    sum(TOT_CONSUMER) TOT_CONSUMER,
    REGION,
    yearmonth from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,TOT_CONSUMER,FORMAT_DATE("%Y%m", TIMESTAMP) yearmonth 
	from sfmc_crm_onepd.F_MAP_UNIQUE_CONSUMER_VALIDATED 
    where 
    ((region = 'KCNA' and timestamp < '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')) or (region <> 'KCNA' and upper(IS_CONTACTABLE) in ('Y','TRUE')))
    AND TIMESTAMP BETWEEN last_day(date_sub(CURRENT_DATE(), interval 8 month)) AND last_day(date_sub(CURRENT_DATE(), interval 1 month))
    --AND COUNTRYCODE <> 'UN'
    )
    WHERE REGION = 'KCNA'
    group by REGION,yearmonth
),

db_acq_epsi 
as
(
    Select sum(NO_OF_CONSUMERS) TOT_CONSUMER,REGION, yearmonth from
    (
    Select TIMESTAMP, COUNTRYCODE, IS_CONTACTABLE,REGION,NO_OF_CONSUMERS, FORMAT_DATE("%Y%m", TIMESTAMP) yearmonth
    from sfmc_crm_onepd.F_DBACQUISITION_EPSI_VALIDATED
    where 
    timestamp >= '2021-03-31' and upper(IS_CONTACTABLE) in ('Y','TRUE')
    AND TIMESTAMP BETWEEN last_day(date_sub(CURRENT_DATE(), interval 8 month)) AND last_day(date_sub(CURRENT_DATE(), interval 1 month))
    --AND COUNTRYCODE <> 'UN'
    AND BRAND = 'NA'
    AND SECTOR = 'NA'
    )
    WHERE REGION = 'KCNA'
    group by REGION,yearmonth

),

epsi_unique_cons as
(
    select TOT_CONSUMER,REGION, yearmonth  from unique_consumer
    union all 
    select TOT_CONSUMER,REGION, yearmonth  from db_acq_epsi
),
sends_base as
(
SELECT 
distinct
Region,  
subscriber_id , 
date(Event_date) Event_date
from sfmc_email.sends
where date(Event_date) <= last_day(date_sub(CURRENT_DATE(), interval 1 month)) 
AND REGION = 'KCNA' 
--AND country_code <> 'UN'
------union on email_subscriber will happen here.
union all 
SELECT 
distinct
Region,  
subscriberid , 
date(Eventdate) Event_date
from sfmc_crm_onepd.email_subscriber 
where date(Eventdate) <= last_day(date_sub(CURRENT_DATE(), interval 1 month))
AND REGION = 'KCNA' 
--AND countrycode <> 'UN'
),
sends_rolling as
(
select count(distinct subscriber_id) sends_rolling_12months, 
region,  
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 1 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 13 month)) and last_day(date_sub(CURRENT_DATE(), interval 1 month)) 
group by region,  yearmonth
union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 2 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 14 month)) and last_day(date_sub(CURRENT_DATE(), interval 2 month)) 
group by region,  yearmonth
union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 3 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 15 month)) and last_day(date_sub(CURRENT_DATE(), interval 3 month)) 
group by region,  yearmonth
union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 4 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 16 month)) and last_day(date_sub(CURRENT_DATE(), interval 4 month)) 
group by region,  yearmonth
union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 5 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 17 month)) and last_day(date_sub(CURRENT_DATE(), interval 5 month)) 
group by region,  yearmonth
union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 6 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 18 month)) and last_day(date_sub(CURRENT_DATE(), interval 6 month)) 
group by region,  yearmonth
union all 
select count(distinct subscriber_id) sends_rolling_12months, 
region, 
 
FORMAT_DATE("%Y%m", last_day(date_sub(CURRENT_DATE(), interval 7 month))) yearmonth
from 
sends_base 
where Event_date between last_day(date_sub(CURRENT_DATE(), interval 19 month)) and last_day(date_sub(CURRENT_DATE(), interval 7 month)) 
group by region, yearmonth
)


Select 
			  cast(base_country.TOT_CONSUMER as INT64) as TOT_CONSUMER,
              base_country.sends_rolling_12months as SENDS,
              base_country.region as REGION,
              base_country.yearmonth as YEARMONTH,
              case when base_country.TOT_CONSUMER = 0 then 0 else round(base_country.sends_rolling_12months/base_country.TOT_CONSUMER,2) end as UTILIZATION
              from
              (
                    SELECT 
                    base.TOT_CONSUMER ,
                    base.sends_rolling_12months,
                    base.region,
                    base.yearmonth 
                    from   
                    (
						Select 
							epsi_unique_cons.TOT_CONSUMER ,
							sends_rolling.sends_rolling_12months,
							epsi_unique_cons.yearmonth ,
							epsi_unique_cons.region
							from 
							sends_rolling 
						inner join 
						epsi_unique_cons 
                        on
						sends_rolling.region = epsi_unique_cons.region
                        AND sends_rolling.yearmonth = epsi_unique_cons.yearmonth
                     ) base 
            )base_country









