WITH
dates as (
SELECT 
    CONCAT(FORMAT_DATETIME("%Y-%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01") as CM_FROM_CY ,
    FORMAT_DATETIME("%Y%m",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)) as CM_FROM_CY_YYMM,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH)) as CM_TO_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH)) as CM_TO_CY_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as YTD_FROM_CY,
    FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH)), "-01-01") as date)) as YTD_FROM_CY_YYMM,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as YTD_TO_CY_YYMM,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_CY,
	CONCAT(FORMAT_DATETIME("%Y-%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)),"-01") as LM_FROM_CY,
	FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 2 MONTH), MONTH)) as LM_TO_CY,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as YTD_LY_FROM_CY,
	FORMAT_DATETIME("%Y%m",cast(CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH)), "-01-01") as date)) as YTD_LY_FROM_CY_YYMM,
    FORMAT_DATETIME("%Y-%m-%d",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY,
	FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 13 MONTH), MONTH)) as YTD_LY_TO_CY_YYMM,
    CONCAT(FORMAT_DATETIME("%Y",DATETIME_SUB(DATE_VALUE,INTERVAL 1 YEAR)), "01") as  R12_FROM_CY,
    FORMAT_DATETIME("%Y%m",LAST_DAY(DATETIME_SUB(DATE_VALUE,INTERVAL 1 MONTH), MONTH))as R12_TO_CY
FROM 
    (select current_date() as DATE_VALUE)
),
    
/* Retail Search data is taken from KEYWORDS_BASELINE view & rest of the channels from US_BASELINE view  & personalization from vw_spends_personalization view upon the data is aggregated on month, brand, sector & channel*/
  
SOURCE AS (

SELECT 
    (case when MEDIA_TYPE='SEARCH' then 'BRAND SEARCH' else MEDIA_TYPE end)  as channel,
    brand,
    (CASE WHEN (BRAND = 'HUGGIES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'KLEENEX' AND SECTOR = '') THEN 'FC'
      WHEN (BRAND = 'DEPEND' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'POISE' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'GOODNITES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'PULL-UPS' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'MULTI-BRAND' AND SECTOR = '') THEN 'NOT APPLICABLE'
      WHEN (BRAND = 'SCOTT' AND SECTOR = '') THEN 'FC' ELSE SECTOR END ) AS SECTOR,
    FORMAT_DATETIME("%Y%m",DATE) as month,
    sum(NET_SPEND) as SPEND,
	SUM(IMPRESSIONS) as IMPRESSIONS,
	SUM(CLICKS) as CLICKS,
	SUM(VIDEO_COMPLETES) as VIDEO_COMPLETES,
    sum(VIDEO_STARTS) as VIDEO_STARTS,
	0 as TOTAL_SPEND
      FROM kc_viz_mindshare_baseline.CV_MAP_MEDIA_SPEND_US_BASELINE
      where  
        (DATE BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select YTD_TO_CY from dates) AS date))
		and MEDIA_TYPE in ('SEARCH','OLA','NATIONAL TV','SOCIAL OLA','AUDIO','OLV','SOCIAL OLV','PRINT')
      GROUP BY
        month,
        brand,
        sector,
        MEDIA_TYPE

UNION ALL

SELECT 
    (case when MEDIA_TYPE='SEARCH' then 'RETAIL SEARCH' else MEDIA_TYPE end)  as channel,
    brand,
    (CASE WHEN (BRAND = 'HUGGIES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'KLEENEX' AND SECTOR = '') THEN 'FC'
      WHEN (BRAND = 'DEPEND' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'POISE' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'GOODNITES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'PULL-UPS' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'MULTI-BRAND' AND SECTOR = '') THEN 'NOT APPLICABLE'
      WHEN (BRAND = 'SCOTT' AND SECTOR = '') THEN 'FC' ELSE SECTOR END ) AS SECTOR,
    FORMAT_DATETIME("%Y%m",DATE) as month,
    sum(NET_SPEND) as SPEND,
	SUM(IMPRESSIONS) as IMPRESSIONS,
	SUM(CLICKS) as CLICKS,
	0 as  VIDEO_COMPLETES,
	0 as VIDEO_STARTS,
	0 as TOTAL_SPEND
      FROM kc_viz_mindshare_baseline.CV_MAP_PAID_SEARCH_US_KEYWORDS_BASELINE
      where  
        (DATE BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select YTD_TO_CY from dates) AS date))
		and MEDIA_TYPE='SEARCH'
      GROUP BY
      month,
      brand,
      sector,
      MEDIA_TYPE

UNION ALL

select 
    'PERSONALIZATION'  as channel,
    upper(a.Brand) as Brand, 
    a.Sector, 
    FORMAT_DATETIME("%Y%m",cast(a.DATE as date)) as month,
    a.SPEND as SPEND,
	0 as IMPRESSIONS,
	0 as CLICKS,
	0 as VIDEO_COMPLETES,
    0 as VIDEO_STARTS,
    b.TOTAL_SPEND as TOTAL_SPEND from 

(select SUM(Total_Media_Spend_Actual) AS SPEND,
concat(Year,'-',
(case when upper(Month)='JAN' then '01' when upper(Month)='FEB' then '02' when upper(Month)='MAR' then '03' when upper(Month)='APR' then '04'
      when upper(Month)='MAY' then '05' when upper(Month)='JUN' then '06' when upper(Month)='JUL' then '07' when upper(Month)='AUG' then '08'
      when upper(Month)='SEP' then '09' when upper(Month)='OCT' then '10' when upper(Month)='NOV' then '11' else '12' end),'-','01') as DATE,
      (CASE WHEN (BRAND = 'HUGGIES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'KLEENEX' AND SECTOR = '') THEN 'FC'
      WHEN (BRAND = 'DEPEND' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'POISE' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'GOODNITES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'PULL-UPS' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'MULTI-BRAND' AND SECTOR = '') THEN 'NOT APPLICABLE'
      WHEN (BRAND = 'SCOTT' AND SECTOR = '') THEN 'FC' ELSE SECTOR END ) AS SECTOR,Brand
     from kc_viz_ga360.vw_spends_personalization WHERE Pers_NonPers_Flag='Personalized'
     GROUP BY DATE,Sector,Brand) a

left outer join

(select SUM(Total_Media_Spend_Actual) AS TOTAL_SPEND,
concat(Year,'-',
(case when upper(Month)='JAN' then '01' when upper(Month)='FEB' then '02' when upper(Month)='MAR' then '03' when upper(Month)='APR' then '04'
      when upper(Month)='MAY' then '05' when upper(Month)='JUN' then '06' when upper(Month)='JUL' then '07' when upper(Month)='AUG' then '08'
      when upper(Month)='SEP' then '09' when upper(Month)='OCT' then '10' when upper(Month)='NOV' then '11' else '12' end),'-','01') as DATE,
      (CASE WHEN (BRAND = 'HUGGIES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'KLEENEX' AND SECTOR = '') THEN 'FC'
      WHEN (BRAND = 'DEPEND' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'POISE' AND SECTOR = '') THEN 'AFC'
      WHEN (BRAND = 'GOODNITES' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'PULL-UPS' AND SECTOR = '') THEN 'BCC'
      WHEN (BRAND = 'MULTI-BRAND' AND SECTOR = '') THEN 'NOT APPLICABLE'
      WHEN (BRAND = 'SCOTT' AND SECTOR = '') THEN 'FC' ELSE SECTOR END ) AS SECTOR,Brand
     from kc_viz_ga360.vw_spends_personalization
     GROUP BY DATE,Sector,Brand)b

     on a.DATE = b.DATE and a.Sector = b.Sector and a.Brand = b.Brand
     where  
        (cast(a.DATE as date) BETWEEN CAST((select YTD_LY_FROM_CY from dates) AS date) AND CAST((select YTD_TO_CY from dates) AS date))

),

/* Current month for Brand Paid Search, Retail Paid Search,Social OLA,Social OLV,OLA,OLV,Audio,National TV,Print,Personalization aggregated month wise(on month, brand, sector & channel) */

CM as (

SELECT 
    channel,
    brand,
    sector,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
    sum(SOURCE.SPEND) as SPEND,
	SUM(SOURCE.IMPRESSIONS) as IMPRESSIONS,
	SUM(SOURCE.CLICKS) as CLICKS,
	SUM(SOURCE.VIDEO_COMPLETES) as VIDEO_COMPLETES,
    sum(SOURCE.VIDEO_STARTS) as VIDEO_STARTS,
	sum(TOTAL_SPEND) as TOTAL_SPEND
      FROM SOURCE
      where  
        SOURCE.month  = (select CM_FROM_CY_YYMM from dates) 
      GROUP BY
        month,
        brand,
        sector,
        channel
),

/* last month's CM for Brand Paid Search, Retail Paid Search,Social OLA,Social OLV,OLA,OLV,Audio,National TV,Print,Personalization aggregated month wise(on month, brand, sector & channel) */

LM as (

SELECT 
    channel,
    brand,
    sector,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
    sum(SOURCE.SPEND) as SPEND,
	SUM(SOURCE.IMPRESSIONS) as IMPRESSIONS,
	SUM(SOURCE.CLICKS) as CLICKS,
	SUM(SOURCE.VIDEO_COMPLETES) as VIDEO_COMPLETES,
    sum(SOURCE.VIDEO_STARTS) as VIDEO_STARTS,
	sum(TOTAL_SPEND) as TOTAL_SPEND
      FROM SOURCE
      where  
        SOURCE.month = (select LM_CY from dates)
      GROUP BY
        month,
        brand,
        sector,
        channel
),

/* Year to date(YTD) for Brand Paid Search, Retail Paid Search,Social OLA,Social OLV,OLA,OLV,Audio,National TV,Print,Personalization aggregated month wise(on month, brand, sector & channel) */

YTD as (

SELECT 
    channel,
    brand,
    sector,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
	sum(SOURCE.SPEND) as SPEND,
	SUM(SOURCE.IMPRESSIONS) as IMPRESSIONS,
	SUM(SOURCE.CLICKS) as CLICKS,
	SUM(SOURCE.VIDEO_COMPLETES) as VIDEO_COMPLETES,
    sum(SOURCE.VIDEO_STARTS) as VIDEO_STARTS,
	sum(TOTAL_SPEND) as TOTAL_SPEND
      FROM SOURCE
      where  
        SOURCE.month BETWEEN (select YTD_FROM_CY_YYMM from dates) AND (select YTD_TO_CY_YYMM from dates)
      GROUP BY
        month,
        brand,
        sector,
        channel

),

/* Year to date(YTD) of last year for Brand Paid Search, Retail Paid Search,Social OLA,Social OLV,OLA,OLV aggregated month wise(on month, brand, sector & channel) */

YTD_LY as (

SELECT 
    channel,
    brand,
    sector,
    concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
	sum(SOURCE.SPEND) as SPEND,
	SUM(SOURCE.IMPRESSIONS) as IMPRESSIONS,
	SUM(SOURCE.CLICKS) as CLICKS,
	SUM(SOURCE.VIDEO_COMPLETES) as VIDEO_COMPLETES,
    sum(SOURCE.VIDEO_STARTS) as VIDEO_STARTS,
	sum(TOTAL_SPEND) as TOTAL_SPEND
      FROM SOURCE
      where  
        SOURCE.month BETWEEN (select YTD_LY_FROM_CY_YYMM from dates) AND (select YTD_LY_TO_CY_YYMM from dates)
      GROUP BY
        month,
        brand,
        sector,
        channel
),

combination AS (
  SELECT
    DISTINCT
	month,
    channel,
    brand,
    sector
    FROM CM)

SELECT
  concat(substr((select CM_FROM_CY from dates),1,4),substr((select CM_FROM_CY from dates),6,2)) as month,
  c.channel,
  'US' as country,
  'KCNA' as region,
  c.brand,
  c.sector,
  
      /* MONTHLY DATA */
  CM.SPEND as SPEND_CM,
  CM.IMPRESSIONS as IMPRESSIONS_CM,
  CM.CLICKS as CLICKS_CM,
  CM.VIDEO_COMPLETES as VIDEO_COMPLETES_CM,
  CM.VIDEO_STARTS as VIDEO_STARTS_CM,
  CM.TOTAL_SPEND as TOTAL_SPEND_CM,
  
      /* LAST MONTH DATA */
  LM.SPEND as SPEND_LM,
  LM.IMPRESSIONS as IMPRESSIONS_LM,
  LM.CLICKS as CLICKS_LM,
  LM.VIDEO_COMPLETES as VIDEO_COMPLETES_LM,
  LM.VIDEO_STARTS as VIDEO_STARTS_LM,
  LM.TOTAL_SPEND as TOTAL_SPEND_LM,
  
      /* YTD DATA */
  YTD.SPEND AS SPEND_YTD,
  YTD.IMPRESSIONS as IMPRESSIONS_YTD,
  YTD.CLICKS as CLICKS_YTD,
  YTD.VIDEO_COMPLETES  as VIDEO_COMPLETES_YTD,
  YTD.VIDEO_STARTS as VIDEO_STARTS_YTD,
  YTD.TOTAL_SPEND as TOTAL_SPEND_YTD,
 
      /* YTD_LY DATA */
  YTD_LY.SPEND as SPEND_YTD_LY,
  YTD_LY.IMPRESSIONS as IMPRESSIONS_YTD_LY,
  YTD_LY.CLICKS as CLICKS_YTD_LY,
  YTD_LY.VIDEO_COMPLETES as VIDEO_COMPLETES_YTD_LY,
  YTD_LY.VIDEO_STARTS as VIDEO_STARTS_YTD_LY,
  YTD_LY.TOTAL_SPEND as TOTAL_SPEND_YTD_LY
  	     
  FROM
    combination c
  LEFT OUTER JOIN
    CM
  ON
    c.month   = CM.month      and
    c.brand   = CM.brand      and
    c.sector  = CM.sector     and
    c.channel = CM.channel    
  LEFT OUTER JOIN           
    LM                        
  ON                          
    c.month   = LM.month      and
    c.brand   = LM.brand      and
    c.sector  = LM.sector     and
    c.channel = LM.channel 
  LEFT OUTER JOIN         
    YTD                       
  ON                          
    c.month   = YTD.month     and
    c.brand   = YTD.brand     and
    c.sector  = YTD.sector    and
    c.channel = YTD.channel 	
  LEFT OUTER JOIN
    YTD_LY
  ON
    c.month   = YTD_LY.month  and
    c.brand   = YTD_LY.brand  and
    c.sector  = YTD_LY.sector and
    c.channel = YTD_LY.channel 
