--create or replace table media_checker_tool.adwords_chile AS(
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
    adwords_chile_huggies.keyword_chile_huggies_checker
  UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM
    adwords_chile_kotex.keyword_chile_kotex_checker 
   UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM adwords_chile_plenitud.keyword_chile_plenitud_checker
   UNION ALL
  SELECT
    customer_id,
    date,
    ad_group_name,
    campaign_id,
    campaign_name,
    clicks,
    customer_descriptive_name AS account_descriptive_name,
    impressions
  FROM adwords_chile_plenitud1.keyword_chile_plenitud_1_checker 
