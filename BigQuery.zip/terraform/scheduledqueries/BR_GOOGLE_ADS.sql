
--insert into dev-hmpemea-reporting.media_checker_tool.table_adwords_brazil

WITH br_google_ads as (

select customer_id, date, ad_group_name, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_brazil_intimus_new_api.brazil_googleads_intimus_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_brazil_plenitud_new_api.brazil_googleads_plenitud_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_new_api.brazil_googleads_huggies_checker

)

select 
customer_id, date, Null as ad_group_id, ad_group_name, Null as campaign_id, campaign_name, 
clicks, account_descriptive_name, impressions
from br_google_ads 