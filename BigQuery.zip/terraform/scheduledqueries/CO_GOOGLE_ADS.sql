
---
WITH co_google_ads as (
select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_colombia_huggies.keyword_colombia_huggies_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_colombia_kotex.keyword_colombia_kotex_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_colombia_plenitud.keyword_colombia_plenitud_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_colombia_scott.keyword_colombia_scott_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_colombia_scott_youtube.keyword_colombia_scott_youtube_checker

UNION ALL

select customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, customer_descriptive_name as account_descriptive_name, impressions
from adwords_colombia_kleenex.keyword_colombia_kleenex_checker
)

select 
customer_id, date, ad_group_name, campaign_id, campaign_name, 
clicks, account_descriptive_name, impressions
from co_google_ads 