def pytest_addoption(parser):
    parser.addoption("--key_path", action="store", default="default name")