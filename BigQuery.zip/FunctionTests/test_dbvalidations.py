import sys
import pytest
from google.cloud import bigquery
from google.oauth2 import service_account

@pytest.fixture()
def name(pytestconfig):
    return pytestconfig.getoption("key_path")

def test_chnl_grp(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=["https://www.googleapis.com/auth/cloud-platform"],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select count(*) from kc_emeareporting.channel_grouping_f """
    query2 = """ select count(*) from kc_emeareporting.channel_grouping_f """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2
