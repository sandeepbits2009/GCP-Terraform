with 

gigya as
(
	select 
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
),


sfmc_temp as
(
select distinct subscriberkey, case when upper(BRAND) in ("HUGGIES","DRYNITES","PULLUPS") then "HUGGIES"
else upper(BRAND) END as BRAND 
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,case when upper(BRAND) in ("HUGGIES","DRYNITES","PULLUPS") then "BCC"
when upper(BRAND)="ANDREX" or upper(BRAND)="KLEENEX" then "FC" 
END as SECTOR
from `refined_layer.SUBSCRIBER_DATA_VALIDATED` 
/*
union all 
select distinct subscriberkey,  "HUGGIES" as BRAND 
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"BCC" as SECTOR
from `landing_layer.BCC_Subscribers_Data_new`
*/
),

SFMC_AND_GA as
(
select distinct 
COALESCE(SFMC_temp.subscriberkey,gm.GIGYAID) as GIGYAID
,COALESCE(gm.CLIENTID) as CLIENTID
,UPPER(COALESCE(SFMC_temp.BRAND	,gm.BRAND		 )) as BRAND 
,COALESCE(SFMC_temp.COUNTRY_CODE,gm.COUNTRY_CODE ) as COUNTRY_CODE
,COALESCE(SFMC_temp.REGION      ,gm.REGION       ) as REGION
,COALESCE(SFMC_temp.SECTOR      ,gm.SECTOR       ) as SECTOR
from gigya gm full outer join SFMC_temp on 
SFMC_temp.subscriberkey =gm.GIGYAID AND
upper(SFMC_temp.BRAND) = upper(gm.BRAND) AND
SFMC_temp.COUNTRY_CODE = gm.COUNTRY_CODE AND
SFMC_temp.REGION = gm.REGION AND
SFMC_temp.SECTOR = gm.SECTOR
),

total_score AS
(
select 
case when lower(sg.BRAND)=lower(hva.BRAND) then CLIENTID END as CLIENTID
,GIGYAID
,sg.BRAND
,sg.COUNTRY_CODE
,sg.REGION      
,sg.SECTOR      
,count(distinct sg.CLIENTID) OVER (PARTITION BY Gigyaid_or_clientid) as Multi_Device_Login
,count(distinct sg.BRAND) OVER (PARTITION BY Gigyaid_or_clientid) as Multi_Brand_Login
,sum(no_non_bounce_session) OVER (PARTITION BY Gigyaid_or_clientid) as total_all_brand_sessions
,sum(PRODUCT_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid) as total_product_viewed
,sum(THEME_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid) as total_content_viewed
,sum(LOGIN_CNT) OVER (PARTITION BY Gigyaid_or_clientid) as TOTAL_LOGIN_CNT
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(no_non_bounce_session) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as total_non_bounce_sessions
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(PRODUCT_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as br_total_product_viewed
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(THEME_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as br_total_content_viewed
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(LOGIN_CNT) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as br_TOTAL_LOGIN_CNT
from SFMC_AND_GA sg 
 left join staging_layer.HVA_SCORE_AGG hva on hva.Gigyaid_or_clientid=sg.GIGYAID --and lower(sg.BRAND)=lower(hva.BRAND)
where CROSS_BRAND is not null 
),

each_brand_total_score AS
(
select 
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION      
,SECTOR      
,if((Multi_Device_Login)>1,"True","False") as MULTI_DEVICE_LOGIN
,if((Multi_Brand_Login)>1,"True","False") as MULTI_BRAND_LOGIN
,round(safe_divide(total_non_bounce_sessions,total_all_brand_sessions)*5,2) as NO_NON_BOUNCE_SESSION_SCORE
,round(safe_divide(br_total_product_viewed,total_product_viewed)*5,2) as TOTAL_PRODUCT_VIEWED_SCORE
,round(safe_divide(br_total_content_viewed,total_content_viewed)*5,2) as TOTAL_CONTENT_VIEWED_SCORE
,round(safe_divide(br_TOTAL_LOGIN_CNT,TOTAL_LOGIN_CNT)*5,2) as LOGIN_CNT_SCORE
 from total_score
)

    
select
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION      
,SECTOR 
,MULTI_DEVICE_LOGIN
,MULTI_BRAND_LOGIN
,NO_NON_BOUNCE_SESSION_SCORE
,TOTAL_PRODUCT_VIEWED_SCORE
,TOTAL_CONTENT_VIEWED_SCORE
,LOGIN_CNT_SCORE
,round(safe_divide(
(
COALESCE(no_non_bounce_session_score,0) +
COALESCE(total_product_viewed_score ,0) +
COALESCE(total_content_viewed_score ,0) +
COALESCE(LOGIN_CNT_score            ,0) 
),4),2)
as BRAND_AFFINITY_SCORE 
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from each_brand_total_score
