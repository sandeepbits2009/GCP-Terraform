MERGE staging_layer.CROSS_BRAND X
USING 
(
with 

delta_records AS
(
select distinct CLIENTID
, COALESCE(userId,if (customDimensions.index = 11 , customDimensions.value,null)) as GIGYAID
,"Andrex" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"FC" as SECTOR
from `hmp-emea-reporting.185006019.ga_sessions_*`
, unnest(customDimensions) customDimensions 
where COALESCE(userId,if (customDimensions.index = 11 , customDimensions.value,null)) is not null
AND _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)) --"20211115"

union all

select distinct CLIENTID
, COALESCE(userId,if (customDimensions.index = 1 , customDimensions.value,null)) as GIGYAID
,"Kleenex" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"FC" as SECTOR
from `hmp-emea-reporting.183942593.ga_sessions_*`
, unnest(customDimensions) customDimensions 
where COALESCE(userId,if (customDimensions.index = 1 , customDimensions.value,null)) is not null
AND _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)) --"20211115"


union all

select distinct CLIENTID
, COALESCE(userId,if (customDimensions.index = 4 , customDimensions.value,null)) as GIGYAID
,"Huggies" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"BCC" as SECTOR
from `hmp-emea-reporting.234507856.ga_sessions_*`
, unnest(customDimensions) customDimensions 
where COALESCE(userId,if (customDimensions.index = 4 , customDimensions.value,null)) is not null
AND _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)) --"20211115"
),

gigya AS
(
select 
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION      
,SECTOR 
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND GIGYAID in (select distinct GIGYAID from staging_layer.ID_RESOLUTION 
	where clientid in (select distinct clientid from delta_records))
),


sfmc_temp as
(select * from (
select distinct subscriberkey, 
case when upper(BRAND) in ("HUGGIES","DRYNITES","PULLUPS") then "HUGGIES"
else upper(BRAND) END as BRAND 
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,case when upper(BRAND) in ("HUGGIES","DRYNITES","PULLUPS") then "BCC"
when upper(BRAND)="ANDREX" or upper(BRAND)="KLEENEX" then "FC" 
END as SECTOR
,ROW_NUMBER() OVER(PARTITION BY SubscriberKey,Brand ORDER BY DT_Stamp_DS DESC,Onboarded_Date desc,DT_Stamp_SFMC desc) as rn
from `refined_layer.SUBSCRIBER_DATA_VALIDATED`
)where rn=1 
/*
select distinct subscriberkey,  "HUGGIES" as BRAND 
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"BCC" as SECTOR
from `landing_layer.BCC_Subscribers_Data_new`
*/
),

SFMC_AND_GA as
(
	select distinct * from (
	select *
	,ROW_NUMBER() OVER(PARTITION BY COALESCE(GIGYAID,CLIENTID),Brand ORDER BY COUNTRY_CODE DESC,REGION desc,SECTOR desc) as rn
	from	(
select distinct 
COALESCE(SFMC_temp.subscriberkey,gm.GIGYAID,delta.GIGYAID) as GIGYAID
,COALESCE(gm.CLIENTID ,delta.CLIENTID) as CLIENTID
,UPPER(COALESCE(SFMC_temp.BRAND	,gm.BRAND		 ,delta.BRAND		 )) as BRAND 
,COALESCE(SFMC_temp.COUNTRY_CODE,gm.COUNTRY_CODE ,delta.COUNTRY_CODE ) as COUNTRY_CODE
,COALESCE(SFMC_temp.REGION      ,gm.REGION       ,delta.REGION       ) as REGION
,COALESCE(SFMC_temp.SECTOR      ,gm.SECTOR       ,delta.SECTOR       ) as SECTOR
from gigya gm full outer join SFMC_temp on 
SFMC_temp.subscriberkey =gm.GIGYAID AND
upper(SFMC_temp.BRAND) = upper(gm.BRAND) AND
SFMC_temp.COUNTRY_CODE = gm.COUNTRY_CODE AND
SFMC_temp.REGION = gm.REGION AND
SFMC_temp.SECTOR = gm.SECTOR
full outer join delta_records delta on 
delta.GIGYAID=COALESCE(gm.GIGYAID,SFMC_temp.subscriberkey) AND
upper(delta.BRAND)=upper(COALESCE(gm.BRAND,SFMC_temp.BRAND)) AND
delta.COUNTRY_CODE=COALESCE(gm.COUNTRY_CODE,SFMC_temp.COUNTRY_CODE) AND
delta.REGION=COALESCE(gm.REGION,SFMC_temp.REGION) AND
delta.SECTOR=COALESCE(gm.SECTOR,SFMC_temp.SECTOR)
	)
	)where rn=1
),

total_score AS
(
	select *
,ROW_NUMBER() OVER(PARTITION BY COALESCE(GIGYAID,CLIENTID),Brand ORDER BY COUNTRY_CODE DESC,REGION desc,SECTOR desc) as rn
	from(
select distinct
case when lower(sg.BRAND)=lower(hva.BRAND) then CLIENTID END as CLIENTID
,GIGYAID
,sg.BRAND
,sg.COUNTRY_CODE
,sg.REGION      
,sg.SECTOR      
,count(distinct sg.CLIENTID) OVER (PARTITION BY Gigyaid_or_clientid) as Multi_Device_Login
,count(distinct sg.BRAND) OVER (PARTITION BY Gigyaid_or_clientid) as Multi_Brand_Login
,sum(no_non_bounce_session) OVER (PARTITION BY Gigyaid_or_clientid) as total_all_brand_sessions
,sum(PRODUCT_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid) as total_product_viewed
,sum(THEME_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid) as total_content_viewed
,sum(LOGIN_CNT) OVER (PARTITION BY Gigyaid_or_clientid) as TOTAL_LOGIN_CNT
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(no_non_bounce_session) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as total_non_bounce_sessions
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(PRODUCT_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as br_total_product_viewed
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(THEME_CONTENT_CONSUMPTION_CNT) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as br_total_content_viewed
,(case when lower(sg.BRAND)=lower(hva.BRAND) then sum(LOGIN_CNT) OVER (PARTITION BY Gigyaid_or_clientid,hva.BRAND) END) as br_TOTAL_LOGIN_CNT
from SFMC_AND_GA sg 
 left join staging_layer.HVA_SCORE_AGG hva on hva.Gigyaid_or_clientid=sg.GIGYAID --and lower(sg.BRAND)=lower(hva.BRAND)
where CROSS_BRAND is not null 
)
),

each_brand_total_score AS
(
select distinct
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION      
,SECTOR      
,if((Multi_Device_Login)>1,"True","False") as MULTI_DEVICE_LOGIN
,if((Multi_Brand_Login)>1,"True","False") as MULTI_BRAND_LOGIN
,round(safe_divide(total_non_bounce_sessions,total_all_brand_sessions)*5,2) as NO_NON_BOUNCE_SESSION_SCORE
,round(safe_divide(br_total_product_viewed,total_product_viewed)*5,2) as TOTAL_PRODUCT_VIEWED_SCORE
,round(safe_divide(br_total_content_viewed,total_content_viewed)*5,2) as TOTAL_CONTENT_VIEWED_SCORE
,round(safe_divide(br_TOTAL_LOGIN_CNT,TOTAL_LOGIN_CNT)*5,2) as LOGIN_CNT_SCORE
 from total_score
 where rn=1
)

    
select distinct
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION      
,SECTOR 
,MULTI_DEVICE_LOGIN
,MULTI_BRAND_LOGIN
,NO_NON_BOUNCE_SESSION_SCORE
,TOTAL_PRODUCT_VIEWED_SCORE
,TOTAL_CONTENT_VIEWED_SCORE
,LOGIN_CNT_SCORE
,round(safe_divide(
(
COALESCE(no_non_bounce_session_score,0) +
COALESCE(total_product_viewed_score ,0) +
COALESCE(total_content_viewed_score ,0) +
COALESCE(LOGIN_CNT_score            ,0) 
),4),2)
as BRAND_AFFINITY_SCORE 
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from each_brand_total_score
) Y
ON COALESCE(X.GIGYAID,'A') = COALESCE(Y.GIGYAID,'A') AND COALESCE(X.CLIENTID,'A') = COALESCE(Y.CLIENTID,'A') AND upper(X.BRAND) = upper(Y.BRAND)
 AND X.COUNTRY_CODE = Y.COUNTRY_CODE AND X.REGION = Y.REGION AND X.SECTOR = Y.SECTOR
WHEN MATCHED THEN
UPDATE set 
 X.BRAND_AFFINITY_SCORE = Y.BRAND_AFFINITY_SCORE
,X.UPDATE_DTM = Y.UPDATE_DTM
WHEN NOT MATCHED THEN
INSERT (
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION      
,SECTOR 
,MULTI_DEVICE_LOGIN
,MULTI_BRAND_LOGIN
,NO_NON_BOUNCE_SESSION_SCORE
,TOTAL_PRODUCT_VIEWED_SCORE
,TOTAL_CONTENT_VIEWED_SCORE
,LOGIN_CNT_SCORE
,BRAND_AFFINITY_SCORE
,INSERT_DTM
,UPDATE_DTM
) VALUES 
(
Y.CLIENTID
,Y.GIGYAID
,Y.BRAND
,Y.COUNTRY_CODE
,Y.REGION      
,Y.SECTOR 
,Y.MULTI_DEVICE_LOGIN
,Y.MULTI_BRAND_LOGIN
,Y.NO_NON_BOUNCE_SESSION_SCORE
,Y.TOTAL_PRODUCT_VIEWED_SCORE
,Y.TOTAL_CONTENT_VIEWED_SCORE
,Y.LOGIN_CNT_SCORE
,Y.BRAND_AFFINITY_SCORE
,Y.INSERT_DTM
,Y.UPDATE_DTM
)
