MERGE staging_layer.HVA_SCORE_AGG X
USING 
(

with 
/*
delta_records
(
select distinct clientid from `hmp-emea-reporting.234507856.ga_sessions_*` 
	where _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
	--_table_suffix between 'YYYYMMDD' AND 'YYYYMMDD'
)*/

hva AS
(
select * from `kc_cdplite_lookup.LKP_HVA_SCORE`
where Brand='Huggies' and Region='EMEA' and Country='UK' and Sector='BCC'
),

-- GA All distinct clientID, GigyaID

gigya as
(select distinct
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND upper(BRAND        )="HUGGIES"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="BCC" 
),

bcc_tracking_data as
(
    select * from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
    where upper(BRAND) in ("HUGGIES","DRYNITES","PULLUPS")
),

email_interaction_cnt as
(
    
select SubscriberKey,Brand,count(distinct JobID) as EMAIL_INTERACTION_CNT
from 
(
select distinct SubscriberKey,Brand,JobID,timestamp(lastopen_date) as Open_or_click_date
from bcc_tracking_data where lastopen_date is not null and lower(brand) in('huggies','drynites','pullups')
union all 
select distinct SubscriberKey,Brand,JobID,timestamp(lastClick_date) as Open_or_click_date
from bcc_tracking_data where lastClick_date is not null and lower(brand) in('huggies','drynites','pullups')
)
where DATE_DIFF(current_date(),extract(date from (Open_or_click_date)),DAY) <=180
and DATE_DIFF(current_date(),extract(date from (Open_or_click_date)),DAY) >0
group by 1,2
),

fc_sub as
(select * from(
select 
*, ROW_NUMBER() OVER(PARTITION BY SubscriberKey,case when lower(brand) in('huggies','drynites','pullups') then "HUGGIES"
else lower(brand) END 
ORDER BY DT_Stamp_DS DESC,Onboarded_Date desc,DT_Stamp_SFMC desc) as rn
from `refined_layer.SUBSCRIBER_DATA_VALIDATED` where lower(brand) in('huggies','drynites','pullups')
)where rn=1
),

huggies_url as
(
select *
,lower(ltrim(rtrim(split(url,".co.uk")[SAFE_OFFSET(1)]))) as lkp_url_without_www
,lower(ltrim(rtrim(substr(url,9)))) as lkp_url_without_http
 from kc_cdplite_lookup.LKP_HUGGIES_URL_CATEGORY
),

all_sub_data as
(
select distinct subscriberkey, case when lower(brand) in('huggies','drynites','pullups') then "HUGGIES"
else lower(brand) END as BRAND from `refined_layer.SUBSCRIBER_DATA_VALIDATED`
),

sub_brand_cnt as 
(
    select SubscriberKey,count(distinct Brand) Brand_count from all_sub_data
    where brand is not null
    group by 1 --having Brand_count>1
),

entire_data_for_delta_records AS
(
select COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,COALESCE(ga.clientid,gigya.clientid) as clientid
,channelGrouping,trafficsource
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
,sum(totals.timeOnSite) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) total_timeOnSite
--,count(distinct visitNumber) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) total_num_sessions
,countif((DATE_DIFF(CURRENT_DATE(),(EXTRACT (date FROM TIMESTAMP_SECONDS(visitstarttime))),DAY) >=0)
      AND (DATE_DIFF(CURRENT_DATE(),(EXTRACT (date FROM TIMESTAMP_SECONDS(visitstarttime))),DAY) <=90)
) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) total_num_sessions

,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) no_non_bounce_session
,countif((lower(channelGrouping)='organic search' or lower(channelGrouping)='direct' or lower(channelGrouping)='email') 
or ((lower(channelGrouping)='social') and lower(trafficsource.medium)!='paid_social' )) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) as NON_MEDIA_ASSISTED_SESSION_CNT
,countif(lower(channelGrouping)='direct') OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) as DIRECT_ACCESS_SESSION_CNT
,countif(lower(channelGrouping)='organic search' and
     brand_lkp.br is not null) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) as BRANDED_SEARCH_ACCESS_SESSION_CNT
,countif(lower(channelGrouping)='organic search' and
     brand_lkp.br is null) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) as NON_BRANDED_SEARCH_ACCESS_SESSION_CNT
,countif(lower(channelGrouping)='social' and lower(trafficsource.medium)!='paid_social' ) OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) as SHARED_OR_SOCIAL_ACCESS_SESSION_CNT
,countif(lower(channelGrouping)='email') OVER (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid)) as EMAIL_ACCESS_SESSION_CNT
,row_number() over (PARTITION BY COALESCE(gigya.gigyaid,ga.clientid) ORDER BY visitstarttime desc) as ret_feq_rn
from `hmp-emea-reporting.234507856.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid

left join 

  (
  select distinct lower(brand) br from huggies_url where brand is not null
  union all select distinct lower(product_category) br from huggies_url where product_category is not null
  union all select distinct lower( product_type ) br from huggies_url where product_type is not null
  union all select distinct lower( content_category ) br from huggies_url where content_category is not null
  union all select distinct lower( content_theme ) br from huggies_url where content_theme is not null
  union all select distinct "find_out_more" as br from huggies_url
  )brand_lkp
  on lower(channelGrouping)='organic search' and lower(trim(trafficsource.keyword)) = lower(brand_lkp.br)
  where ( _table_suffix between FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY))
	AND FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)))
/*
where (ga.clientid in 
	(select clientid from Gigya)  --All level2 data
)
*/
),

B_HVA as
(
select distinct
Gigyaid_or_clientid
,total_timeOnSite
,total_num_sessions
,no_non_bounce_session
,NON_MEDIA_ASSISTED_SESSION_CNT
,DIRECT_ACCESS_SESSION_CNT
,BRANDED_SEARCH_ACCESS_SESSION_CNT
,NON_BRANDED_SEARCH_ACCESS_SESSION_CNT
,SHARED_OR_SOCIAL_ACCESS_SESSION_CNT
,EMAIL_ACCESS_SESSION_CNT
,count(distinct clientid) OVER (PARTITION BY Gigyaid_or_clientid) as MULTIPLE_DEVICE_LOGIN_CNT


,countif(hits.type = "PAGE" and (DATE_DIFF(CURRENT_DATE(),(EXTRACT (date FROM TIMESTAMP_SECONDS(visitstarttime))),DAY) >=0)
      AND (DATE_DIFF(CURRENT_DATE(),(EXTRACT (date FROM TIMESTAMP_SECONDS(visitstarttime))),DAY) <=90)) OVER (PARTITION BY Gigyaid_or_clientid) as pageviews

,countif(
((lkp_url_without_www=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] 
or lkp_url_without_http=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)]) and (content_category is not null or content_theme is not null))) OVER (PARTITION BY Gigyaid_or_clientid) as THEME_CONTENT_CONSUMPTION_CNT
,countif( 
((lkp_url_without_www=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] 
or lkp_url_without_http=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)]) and (product_category is not null or product_type is not null))) OVER (PARTITION BY Gigyaid_or_clientid) as PRODUCT_CONTENT_CONSUMPTION_CNT 
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventLabel) in ('facebook' ,'twitter','instagram'))  OVER (PARTITION BY Gigyaid_or_clientid) as SOCIAL_CLICKS_CNT
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='conversion' and lower(hits.eventInfo.eventAction)="registration")  OVER (PARTITION BY Gigyaid_or_clientid) as REGISTRATION_CNT
,case when(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='conversion' and lower(hits.eventInfo.eventAction)="registration")  then  visitstarttime END as REGISTRATION_DT
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='signin' and lower(hits.eventInfo.eventAction)="form submit" 
and lower(hits.eventInfo.eventLabel)='success')  OVER (PARTITION BY Gigyaid_or_clientid) as LOGIN_CNT
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='subscribe_now' and lower(hits.eventInfo.eventAction)='click') 
 OVER (PARTITION BY Gigyaid_or_clientid) as NEWSLETTER_SUBSCRIPTION_CNT
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='buynow_vendor' and lower(hits.eventInfo.eventAction)='click') 
 OVER (PARTITION BY Gigyaid_or_clientid) as RETAILER_CLICK_OUT_CNT
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='product buy now' and lower(hits.eventInfo.eventAction)="click") 
 OVER (PARTITION BY Gigyaid_or_clientid) as BUY_NOW_CNT

,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='search' and lower(hits.eventInfo.eventAction)='click') 
 OVER (PARTITION BY Gigyaid_or_clientid) as INTERNAL_SITE_SEARCH_CNT
,countif(hits.type = "EVENT" and lower(hits.eventInfo.eventCategory)='review' and lower(hits.eventInfo.eventAction)='click') 
 OVER (PARTITION BY Gigyaid_or_clientid) as ADD_REVIEW_CNT
,max(visitNumber) 
 OVER (PARTITION BY Gigyaid_or_clientid) as FIRST_TIME_VISITORS_CNT
,MAX(visitnumber) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId)  as max_visitnumber
 ,(
    /*(LAG(visitstarttime) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,date ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,date DESC))*/
    NTH_VALUE (visitstarttime,1) OVER (PARTITION BY Gigyaid_or_clientid, fullVisitorId ORDER BY  visitnumber RANGE  1 PRECEDING ) 
) as pre_visitstarttime
,max(visitstarttime) OVER (PARTITION BY Gigyaid_or_clientid) as max_visitstarttime
,countif(split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,
(
(case when hits.type = "PAGE" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "PAGE" then hits.time else null END as currTime1
  , count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
  ,MAX(visitstarttime) OVER (PARTITION BY Gigyaid_or_clientid, DATE_TRUNC((EXTRACT (date FROM TIMESTAMP_SECONDS(ga.visitstarttime))), MONTH),
        DATE_TRUNC((EXTRACT (date FROM TIMESTAMP_SECONDS(ga.visitstarttime))), YEAR)) AS max_month_visitstarttime
,ret_feq_rn
,visitstarttime
,visitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits
left join  
(select url, product_category,product_type, content_category,content_theme,lkp_url_without_www,lkp_url_without_http from huggies_url )url
--on ( lower(ltrim(rtrim(substr(url.url,9))))=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] or 
on lkp_url_without_www=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)]
 --)
),

B_HVA_ACTIVE_MONTHS as
(
SELECT
    *
,IF(
    visitnumber = max_visitnumber AND visitstarttime!=pre_visitstarttime
    ,IF
    (DATE_DIFF(TIMESTAMP_SECONDS(visitstarttime),TIMESTAMP_SECONDS(pre_visitstarttime),DAY) BETWEEN 0 AND 30,
    "True","False"), null) AS ACTIVE_FOR_LAST_MONTH
,IF(
    visitnumber = max_visitnumber AND visitstarttime!=pre_visitstarttime
    ,IF
    (DATE_DIFF(TIMESTAMP_SECONDS(visitstarttime),TIMESTAMP_SECONDS(pre_visitstarttime),DAY) BETWEEN 0 AND 90,
        "True","False"), null) AS ACTIVE_FOR_LAST_3MONTH
/*,IF
    ((DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime))),(DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)),DAY) >=0)
      AND (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime))),(DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)),DAY) <=30),
      "True","False") AS ACTIVE_FOR_LAST_MONTH
  ,IF
    (max_visitstarttime=max_month_visitstarttime,
      NULL,
    IF
      (DATE_DIFF((EXTRACT (date
            FROM
              TIMESTAMP_SECONDS(max_visitstarttime))),(EXTRACT (date
            FROM
              TIMESTAMP_SECONDS(max_month_visitstarttime))),DAY)<=90
        AND (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime))),(DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)),DAY) >=0)
        AND (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime))),(DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY)),DAY) <=30)
        AND (ROW_NUMBER() OVER(PARTITION BY Gigyaid_or_clientid ORDER BY max_month_visitstarttime DESC) in (2,3))
		AND (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_month_visitstarttime)))
  , (EXTRACT (date FROM(TIMESTAMP_SECONDS(LEAD(max_month_visitstarttime) 
        OVER (PARTITION BY Gigyaid_or_clientid ORDER BY Gigyaid_or_clientid,max_month_visitstarttime DESC))))),MONTH)=1)
		,
        "True",NULL)) AS ACTIVE_FOR_LAST_3MONTH*/
        /*
,IF
    ((DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) <=3) and ret_feq_rn=2,
      "True","False") AS Return_frequency_3_days
,IF
    ((DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) >=4 and 
    (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) <=14)) and ret_feq_rn=2,
      "True","False") AS Return_frequency_14_days
,IF
    ((DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) >14 ) and ret_feq_rn=2,
      "True","False") AS Return_frequency_more_than_14_days
      */
,case 
when (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) <=3) and ret_feq_rn=2
    then "3days"
when (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) >=4 and 
    (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) <=14)) and ret_feq_rn=2
    then "upto14"
when (DATE_DIFF((EXTRACT (date FROM TIMESTAMP_SECONDS(max_visitstarttime)))
    ,(EXTRACT (date from TIMESTAMP_SECONDS(visitstarttime))),DAY) >14 ) and ret_feq_rn=2
    then "more14"
END as Return_frequency_slot

,MIN(REGISTRATION_DT) OVER (PARTITION BY Gigyaid_or_clientid) as REGISTRATION_DATE
  FROM B_HVA
),




B1_HVA as
(
select distinct *
,FIRST_VALUE(ACTIVE_FOR_LAST_MONTH) OVER(PARTITION BY Gigyaid_or_clientid ORDER BY ACTIVE_FOR_LAST_MONTH DESC, ACTIVE_FOR_LAST_3MONTH DESC)   AS FINAL_ACTIVE_FOR_LAST_MONTH
,FIRST_VALUE(ACTIVE_FOR_LAST_3MONTH) OVER(PARTITION BY Gigyaid_or_clientid ORDER BY ACTIVE_FOR_LAST_MONTH DESC, ACTIVE_FOR_LAST_3MONTH DESC)  AS FINAL_ACTIVE_FOR_LAST_3MONTH
,FIRST_VALUE(Return_frequency_slot) OVER(PARTITION BY Gigyaid_or_clientid ORDER BY Return_frequency_slot DESC) 
AS FINAL_Return_frequency_slot
from B_HVA_ACTIVE_MONTHS 
),

B2_HVA as
(
select *
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_Pageview_time
 from B1_HVA
),


HVA_FINAL as
(
select distinct
GIGYAID_OR_CLIENTID
,"Huggies" as BRAND
,"UK" AS COUNTRY_CODE
,"EMEA" AS REGION
,"BCC" as SECTOR
,TOTAL_PAGEVIEW_TIME
,TOTAL_TIMEONSITE
,TOTAL_NUM_SESSIONS
,TOTAL_PAGEPATH_COUNT
,PAGEVIEWS
,FINAL_RETURN_FREQUENCY_SLOT
,EMAIL_INTERACTION_CNT
,NO_NON_BOUNCE_SESSION
,BRAND_COUNT
,MULTIPLE_DEVICE_LOGIN_CNT
,REGISTRATION_CNT
,REGISTRATION_DATE
,LOGIN_CNT
,NEWSLETTER_SUBSCRIPTION_CNT
,RETAILER_CLICK_OUT_CNT
,BUY_NOW_CNT
,THEME_CONTENT_CONSUMPTION_CNT
,PRODUCT_CONTENT_CONSUMPTION_CNT
,NON_MEDIA_ASSISTED_SESSION_CNT
,DIRECT_ACCESS_SESSION_CNT
,SHARED_OR_SOCIAL_ACCESS_SESSION_CNT
,BRANDED_SEARCH_ACCESS_SESSION_CNT
,NON_BRANDED_SEARCH_ACCESS_SESSION_CNT
,EMAIL_ACCESS_SESSION_CNT
,INTERNAL_SITE_SEARCH_CNT
,ADD_REVIEW_CNT
,SOCIAL_CLICKS_CNT
,FIRST_TIME_VISITORS_CNT
,(if(total_num_sessions >0,1,0) --if(total_num_sessions >0,1,0)
+ if(total_pagepath_count>2 ,1,0) --if(pageviews>0 ,1,0)
+ if(FINAL_Return_frequency_slot is not null,1,0) --+ if(RETURN_FREQUENCY_SCORE_less_than_3 is not null,1,0)
+ if(sfmc_email.EMAIL_INTERACTION_CNT>0,1,0)--+ if(EMAIL_INTERACTION_SCORE_upto_1_month is not null,1,0)
+ if(no_non_bounce_session>0,no_non_bounce_session,0) --if(no_non_bounce_session>0,1,0)
+ if(s0.Brand_count>1,s0.Brand_count,0)
+ if(MULTIPLE_DEVICE_LOGIN_CNT>1,MULTIPLE_DEVICE_LOGIN_CNT,0)
+ if(b.FINAL_ACTIVE_FOR_LAST_MONTH="True",1,0)
+ if(b.FINAL_ACTIVE_FOR_LAST_3MONTH="True",1,0)
+ if(REGISTRATION_CNT>0,1,0)
+ COALESCE(LOGIN_CNT,0)
--+ if(NEWSLETTER_SUBSCRIPTION_CNT>0,1,0) --Not applicable for Huggies
+ COALESCE(RETAILER_CLICK_OUT_CNT,0)
+ COALESCE(BUY_NOW_CNT                           ,0)
+ COALESCE(THEME_CONTENT_CONSUMPTION_CNT         ,0)
+ COALESCE(PRODUCT_CONTENT_CONSUMPTION_CNT       ,0)
+ COALESCE(NON_MEDIA_ASSISTED_SESSION_CNT        ,0)
+ COALESCE(DIRECT_ACCESS_SESSION_CNT             ,0)
+ COALESCE(SHARED_OR_SOCIAL_ACCESS_SESSION_CNT   ,0)
+ COALESCE(BRANDED_SEARCH_ACCESS_SESSION_CNT     ,0)
+ COALESCE(NON_BRANDED_SEARCH_ACCESS_SESSION_CNT ,0)
+ COALESCE(EMAIL_ACCESS_SESSION_CNT              ,0)
+ COALESCE(INTERNAL_SITE_SEARCH_CNT              ,0)
--+ COALESCE(ADD_REVIEW_CNT                        ,0) --Not applicable for Huggies
+ COALESCE(SOCIAL_CLICKS_CNT                     ,0)
+ if(lower(ltrim(rtrim(fc_sub.optin)))="true",1,0)
+ if(FIRST_TIME_VISITORS_CNT = 1,1,0)
+ if(lower(fc_sub.POME_Consumer)="true",1,0) --+ if(hva.POME_CONSUMER                     is not null,1,0)
+ if(lower(fc_sub.Active_Consumer)="true",1,0) --+ if(hva.ENGAGED_CONSUMER                  is not null,1,0)
+ if(lower(fc_sub.Pollen_Pal)="true",1,0) --+ if(hva.POLLEN_PAL                        is not null,1,0)
+ if(lower(fc_sub.Andrex_Clean_Profiler)="true",1,0) --+ if(hva.ANDREX_CLEAN_PROFILER             is not null,1,0)
--+ if(hva.KLEENEX_ALLERGY                   is not null,1,0) --As SFMC is not sending Not applicable
--+ if(hva.ANDREX_VIDEO_PLAY_ON_FLUSHABILITY is not null,1,0) --As SFMC is not sending Not applicable
) as TOTAL_HVA_CNT

,case 
when total_num_sessions >0 and total_num_sessions <=5 then NO_OF_SESSIONS_1_to_5
when total_num_sessions >5 and total_num_sessions <=10 then (NO_OF_SESSIONS_1_to_5 + NO_OF_SESSIONS_5_to_10)
when total_num_sessions >10 then (NO_OF_SESSIONS_1_to_5 + NO_OF_SESSIONS_5_to_10 + NO_OF_SESSIONS_10_plus)
END as NO_OF_SESSION_SCORE 
,case 
when pageviews>2 and pageviews<=5 THEN hva.PAGE_VIEWS_SCORE_2_plus 
when pageviews>5 and pageviews<=10 THEN hva.PAGE_VIEWS_SCORE_5_plus 
when pageviews>10 THEN hva.PAGE_VIEWS_SCORE_10_plus
END as PAGE_VIEWS_SCORE
--, hva.RETURN_FREQUENCY_SCORE_less_than_3 as RETURN_FREQUENCY_SCORE --RETURN_FREQUENCY_SCORE_4_to_14, RETURN_FREQUENCY_SCORE_14_plus
,case
when FINAL_Return_frequency_slot='3days' then hva.RETURN_FREQUENCY_SCORE_less_than_3
when FINAL_Return_frequency_slot='more14' then hva.RETURN_FREQUENCY_SCORE_4_to_14
when FINAL_Return_frequency_slot='upto14' then hva.RETURN_FREQUENCY_SCORE_14_plus
END as RETURN_FREQUENCY_SCORE
,case
when sfmc_email.EMAIL_INTERACTION_CNT >0 and sfmc_email.EMAIL_INTERACTION_CNT <=1 then hva.EMAIL_INTERACTION_SCORE_upto_1_month
when sfmc_email.EMAIL_INTERACTION_CNT >1 and sfmc_email.EMAIL_INTERACTION_CNT <=5 then hva.EMAIL_INTERACTION_SCORE_1_to_5_month
when sfmc_email.EMAIL_INTERACTION_CNT >10 and sfmc_email.EMAIL_INTERACTION_CNT <=10 then hva.EMAIL_INTERACTION_SCORE_5_plus_months
END as EMAIL_INTERACTION_SCORE
--, hva.EMAIL_INTERACTION_SCORE_upto_1_month as EMAIL_INTERACTION_SCORE --EMAIL_INTERACTION_SCORE_1_to_5_month, EMAIL_INTERACTION_SCORE_5_plus_months
,case when no_non_bounce_session>0 THEN (no_non_bounce_session * hva.NON_BOUNCE_SESSIONS) END as NON_BOUNCE_SESSIONS --, NULL as NON_BOUNCE_SESSIONS
,case when s0.Brand_count>1 then (Brand_count * hva.CROSS_BRAND) END as CROSS_BRAND
, case when MULTIPLE_DEVICE_LOGIN_CNT>1 THEN ( MULTIPLE_DEVICE_LOGIN_CNT * hva.MULTIPLE_DEVICE_LOGIN) END as MULTIPLE_DEVICE_LOGIN
, case when lower(b.FINAL_ACTIVE_FOR_LAST_MONTH)="true" THEN hva.ACTIVE_FOR_LAST_MONTH END as ACTIVE_FOR_LAST_MONTH
, case when lower(b.FINAL_ACTIVE_FOR_LAST_3MONTH)="true" THEN hva.ACTIVE_FOR_LAST_3_MONTHS END as ACTIVE_FOR_LAST_3_MONTHS
,case when REGISTRATION_CNT>0 THEN hva.REGISTRATION END as REGISTRATION
,case when LOGIN_CNT>0 THEN (LOGIN_CNT * hva.LOGIN) END as LOGIN
--,case when NEWSLETTER_SUBSCRIPTION_CNT>0 THEN hva.NEWSLETTER_SUBSCRIPTION END as NEWSLETTER_SUBSCRIPTION
,null as NEWSLETTER_SUBSCRIPTION
,case when RETAILER_CLICK_OUT_CNT>0 THEN (RETAILER_CLICK_OUT_CNT * hva.RETAILER_CLICK_OUT) END as RETAILER_CLICK_OUT
,case when BUY_NOW_CNT>0 THEN (BUY_NOW_CNT * hva.BUY_NOW) END as BUY_NOW
,case when THEME_CONTENT_CONSUMPTION_CNT>0 THEN ( THEME_CONTENT_CONSUMPTION_CNT * hva.THEME_CONTENT_CONSUMPTION) END as THEME_CONTENT_CONSUMPTION
,case when PRODUCT_CONTENT_CONSUMPTION_CNT>0 THEN (PRODUCT_CONTENT_CONSUMPTION_CNT * hva.PRODUCT_CONTENT_CONSUMPTION) END as PRODUCT_CONTENT_CONSUMPTION
,case when NON_MEDIA_ASSISTED_SESSION_CNT>0 THEN (NON_MEDIA_ASSISTED_SESSION_CNT * hva.NON_MEDIA_ASSISTED_SESSION) END as NON_MEDIA_ASSISTED_SESSION
,case when DIRECT_ACCESS_SESSION_CNT>0 THEN (DIRECT_ACCESS_SESSION_CNT * hva.DIRECT_ACCESS_SESSION) END as DIRECT_ACCESS_SESSION
,case when SHARED_OR_SOCIAL_ACCESS_SESSION_CNT>0 THEN ( SHARED_OR_SOCIAL_ACCESS_SESSION_CNT * hva.SHARED_OR_SOCIAL_ACCESS_SESSION) END as SHARED_OR_SOCIAL_ACCESS_SESSION
,case when BRANDED_SEARCH_ACCESS_SESSION_CNT>0 THEN (BRANDED_SEARCH_ACCESS_SESSION_CNT * hva.BRANDED_SEARCH_ACCESS_SESSION) END as BRANDED_SEARCH_ACCESS_SESSION
,case when NON_BRANDED_SEARCH_ACCESS_SESSION_CNT>0 THEN (NON_BRANDED_SEARCH_ACCESS_SESSION_CNT * hva.NON_BRANDED_SEARCH_ACCESS_SESSION) END as NON_BRANDED_SEARCH_ACCESS_SESSION
,case when EMAIL_ACCESS_SESSION_CNT>0 THEN (EMAIL_ACCESS_SESSION_CNT * hva.EMAIL_ACCESS_SESSION) END as EMAIL_ACCESS_SESSION
,case when INTERNAL_SITE_SEARCH_CNT>0 THEN (INTERNAL_SITE_SEARCH_CNT * hva.INTERNAL_SITE_SEARCH) END as INTERNAL_SITE_SEARCH
--,case when ADD_REVIEW_CNT>0 THEN (ADD_REVIEW_CNT * hva.ADD_REVIEW) END as ADD_REVIEW
,null as ADD_REVIEW
,case when SOCIAL_CLICKS_CNT>0 THEN (SOCIAL_CLICKS_CNT * hva.SOCIAL_CLICKS) END as SOCIAL_CLICKS
,case when lower(fc_sub.optin)="true" THEN hva.Profile_Opt_Ins END as Profile_Opt_Ins
,case when FIRST_TIME_VISITORS_CNT = 1 THEN hva.FIRST_TIME_VISITORS END as FIRST_TIME_VISITORS
,case when lower(fc_sub.POME_Consumer)="true" then hva.POME_CONSUMER END as POME_CONSUMER --, hva.POME_CONSUMER as POME_CONSUMER
,case when lower(fc_sub.Active_Consumer)="true" then hva.ENGAGED_CONSUMER END as ENGAGED_CONSUMER --, hva.ENGAGED_CONSUMER as ENGAGED_CONSUMER
,case when lower(fc_sub.Pollen_Pal)="true" then hva.POLLEN_PAL END as POLLEN_PAL --, hva.POLLEN_PAL as POLLEN_PAL
,case when lower(fc_sub.Andrex_Clean_Profiler)="true" then hva.ANDREX_CLEAN_PROFILER END as ANDREX_CLEAN_PROFILER--, hva.ANDREX_CLEAN_PROFILER as ANDREX_CLEAN_PROFILER
--, hva.KLEENEX_ALLERGY as KLEENEX_ALLERGY --As SFMC is not sending Not applicable
--, hva.ANDREX_VIDEO_PLAY_ON_FLUSHABILITY as ANDREX_VIDEO_PLAY_ON_FLUSHABILITY --As SFMC is not sending Not applicable
 from B2_HVA b,(select * from hva)hva
 left join sub_brand_cnt s0 on b.Gigyaid_or_clientid =s0.SubscriberKey
 left join fc_sub on b.Gigyaid_or_clientid=fc_sub.SubscriberKey
 left join email_interaction_cnt sfmc_email on b.Gigyaid_or_clientid=sfmc_email.SubscriberKey
 --order by 1
)

select distinct *
,(COALESCE(NO_OF_SESSION_SCORE             ,0)+
COALESCE(PAGE_VIEWS_SCORE                 ,0)+
COALESCE(RETURN_FREQUENCY_SCORE           ,0)+
COALESCE(EMAIL_INTERACTION_SCORE          ,0)+
COALESCE(NON_BOUNCE_SESSIONS              ,0)+
COALESCE(CROSS_BRAND                      ,0)+
COALESCE(MULTIPLE_DEVICE_LOGIN            ,0)+
COALESCE(ACTIVE_FOR_LAST_MONTH            ,0)+
COALESCE(ACTIVE_FOR_LAST_3_MONTHS         ,0)+
COALESCE(REGISTRATION                     ,0)+
COALESCE(LOGIN                            ,0)+
COALESCE(NEWSLETTER_SUBSCRIPTION          ,0)+
COALESCE(RETAILER_CLICK_OUT               ,0)+
COALESCE(BUY_NOW                          ,0)+
COALESCE(THEME_CONTENT_CONSUMPTION        ,0)+
COALESCE(PRODUCT_CONTENT_CONSUMPTION      ,0)+
COALESCE(NON_MEDIA_ASSISTED_SESSION       ,0)+
COALESCE(DIRECT_ACCESS_SESSION            ,0)+
COALESCE(SHARED_OR_SOCIAL_ACCESS_SESSION  ,0)+
COALESCE(BRANDED_SEARCH_ACCESS_SESSION    ,0)+
COALESCE(NON_BRANDED_SEARCH_ACCESS_SESSION,0)+
COALESCE(EMAIL_ACCESS_SESSION             ,0)+
COALESCE(INTERNAL_SITE_SEARCH             ,0)+
COALESCE(ADD_REVIEW                       ,0)+
COALESCE(SOCIAL_CLICKS                    ,0)+
COALESCE(Profile_Opt_Ins                  ,0)+
COALESCE(FIRST_TIME_VISITORS              ,0)+
COALESCE(POME_CONSUMER                    ,0)+
COALESCE(ENGAGED_CONSUMER                 ,0)+
COALESCE(POLLEN_PAL						  ,0)+
COALESCE(ANDREX_CLEAN_PROFILER            ,0)
)
as AGG_HVA_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
 from HVA_FINAL

) Y
ON --X.GigyaID = Y.GigyaID AND X.clientID = Y.clientID 
X.Gigyaid_or_clientid = Y.Gigyaid_or_clientid
and X.Brand = Y.Brand and X.Country_Code = Y.Country_Code and X.Region = Y.Region and X.sector=Y.sector
WHEN MATCHED THEN
UPDATE set 
X.GIGYAID_OR_CLIENTID                =Y.GIGYAID_OR_CLIENTID
,X.BRAND                             =Y.BRAND
,X.COUNTRY_CODE                      =Y.COUNTRY_CODE
,X.REGION                            =Y.REGION
,X.SECTOR                            =Y.SECTOR
,X.TOTAL_PAGEVIEW_TIME                   =Y.TOTAL_PAGEVIEW_TIME
,X.TOTAL_TIMEONSITE                      =Y.TOTAL_TIMEONSITE
,X.TOTAL_NUM_SESSIONS                    =Y.TOTAL_NUM_SESSIONS
,X.TOTAL_PAGEPATH_COUNT                  =Y.TOTAL_PAGEPATH_COUNT
,X.PAGEVIEWS                             =Y.PAGEVIEWS
,X.FINAL_RETURN_FREQUENCY_SLOT           =Y.FINAL_RETURN_FREQUENCY_SLOT
,X.EMAIL_INTERACTION_CNT                 =Y.EMAIL_INTERACTION_CNT
,X.NO_NON_BOUNCE_SESSION             =Y.NO_NON_BOUNCE_SESSION
,X.BRAND_COUNT                           =Y.BRAND_COUNT
,X.MULTIPLE_DEVICE_LOGIN_CNT             =Y.MULTIPLE_DEVICE_LOGIN_CNT
--,X.REGISTRATION_CNT                      =Y.REGISTRATION_CNT
,X.REGISTRATION_CNT = case when COALESCE(X.REGISTRATION_CNT,0)=0 then Y.REGISTRATION_CNT else X.REGISTRATION_CNT end
--,X.REGISTRATION_DATE                      =Y.REGISTRATION_DATE
,X.REGISTRATION_DATE = case when X.REGISTRATION_DATE is null then Y.REGISTRATION_DATE else X.REGISTRATION_DATE end
,X.LOGIN_CNT                             =Y.LOGIN_CNT
,X.NEWSLETTER_SUBSCRIPTION_CNT           =Y.NEWSLETTER_SUBSCRIPTION_CNT
,X.RETAILER_CLICK_OUT_CNT                =Y.RETAILER_CLICK_OUT_CNT
,X.BUY_NOW_CNT                           =Y.BUY_NOW_CNT
,X.THEME_CONTENT_CONSUMPTION_CNT         =Y.THEME_CONTENT_CONSUMPTION_CNT
,X.PRODUCT_CONTENT_CONSUMPTION_CNT       =Y.PRODUCT_CONTENT_CONSUMPTION_CNT
,X.NON_MEDIA_ASSISTED_SESSION_CNT        =Y.NON_MEDIA_ASSISTED_SESSION_CNT
,X.DIRECT_ACCESS_SESSION_CNT             =Y.DIRECT_ACCESS_SESSION_CNT
,X.SHARED_OR_SOCIAL_ACCESS_SESSION_CNT   =Y.SHARED_OR_SOCIAL_ACCESS_SESSION_CNT
,X.BRANDED_SEARCH_ACCESS_SESSION_CNT     =Y.BRANDED_SEARCH_ACCESS_SESSION_CNT
,X.NON_BRANDED_SEARCH_ACCESS_SESSION_CNT =Y.NON_BRANDED_SEARCH_ACCESS_SESSION_CNT
,X.EMAIL_ACCESS_SESSION_CNT              =Y.EMAIL_ACCESS_SESSION_CNT
,X.INTERNAL_SITE_SEARCH_CNT              =Y.INTERNAL_SITE_SEARCH_CNT
,X.ADD_REVIEW_CNT                        =Y.ADD_REVIEW_CNT
,X.SOCIAL_CLICKS_CNT                     =Y.SOCIAL_CLICKS_CNT
,X.FIRST_TIME_VISITORS_CNT               =Y.FIRST_TIME_VISITORS_CNT
,X.TOTAL_HVA_CNT                     =Y.TOTAL_HVA_CNT
,X.NO_OF_SESSION_SCORE               =Y.NO_OF_SESSION_SCORE
,X.PAGE_VIEWS_SCORE                  =Y.PAGE_VIEWS_SCORE
,X.RETURN_FREQUENCY_SCORE            =Y.RETURN_FREQUENCY_SCORE
,X.EMAIL_INTERACTION_SCORE           =Y.EMAIL_INTERACTION_SCORE
,X.NON_BOUNCE_SESSIONS               =Y.NON_BOUNCE_SESSIONS
,X.CROSS_BRAND                       =Y.CROSS_BRAND
,X.MULTIPLE_DEVICE_LOGIN             =Y.MULTIPLE_DEVICE_LOGIN
,X.ACTIVE_FOR_LAST_MONTH             =Y.ACTIVE_FOR_LAST_MONTH
,X.ACTIVE_FOR_LAST_3_MONTHS          =Y.ACTIVE_FOR_LAST_3_MONTHS
,X.REGISTRATION = case when X.REGISTRATION is null then Y.REGISTRATION else X.REGISTRATION end
,X.LOGIN                             =Y.LOGIN
,X.NEWSLETTER_SUBSCRIPTION           =Y.NEWSLETTER_SUBSCRIPTION
,X.RETAILER_CLICK_OUT                =Y.RETAILER_CLICK_OUT
,X.BUY_NOW                           =Y.BUY_NOW
,X.THEME_CONTENT_CONSUMPTION         =Y.THEME_CONTENT_CONSUMPTION
,X.PRODUCT_CONTENT_CONSUMPTION       =Y.PRODUCT_CONTENT_CONSUMPTION
,X.NON_MEDIA_ASSISTED_SESSION        =Y.NON_MEDIA_ASSISTED_SESSION
,X.DIRECT_ACCESS_SESSION             =Y.DIRECT_ACCESS_SESSION
,X.SHARED_OR_SOCIAL_ACCESS_SESSION   =Y.SHARED_OR_SOCIAL_ACCESS_SESSION
,X.BRANDED_SEARCH_ACCESS_SESSION     =Y.BRANDED_SEARCH_ACCESS_SESSION
,X.NON_BRANDED_SEARCH_ACCESS_SESSION =Y.NON_BRANDED_SEARCH_ACCESS_SESSION
,X.EMAIL_ACCESS_SESSION              =Y.EMAIL_ACCESS_SESSION
,X.INTERNAL_SITE_SEARCH              =Y.INTERNAL_SITE_SEARCH
,X.ADD_REVIEW                        =Y.ADD_REVIEW
,X.SOCIAL_CLICKS                     =Y.SOCIAL_CLICKS
,X.PROFILE_OPT_INS                   =Y.PROFILE_OPT_INS
,X.FIRST_TIME_VISITORS               =Y.FIRST_TIME_VISITORS
,X.POME_CONSUMER                     =Y.POME_CONSUMER
,X.ENGAGED_CONSUMER                  =Y.ENGAGED_CONSUMER
,X.POLLEN_PAL                        =Y.POLLEN_PAL
,X.ANDREX_CLEAN_PROFILER             =Y.ANDREX_CLEAN_PROFILER
,X.AGG_HVA_SCORE                     =Y.AGG_HVA_SCORE
,X.UPDATE_DTM = Y.UPDATE_DTM

/* 
##########################################################################################################
I have below logic to update data only for delta history 
but as we have to update data every time for entire history for 6 score fields (as scores dependent upon CURRENT_DATE)
Calculating only 6 score fields out of entire data is complex calculations which are dependent on unnesting hits and hits.type 
so entire macthed 6 months data will get updated every day for HVA_SCORE and new records will get inserted
##########################################################################################################

*/
/*
##########################################################################################################
 X.NO_OF_SESSION_SCORE = case when X.NO_OF_SESSION_SCORE < 3 or X.NO_OF_SESSION_SCORE is null then Y.NO_OF_SESSION_SCORE else X.NO_OF_SESSION_SCORE end
,X.PAGE_VIEWS_SCORE   = case when X.PAGE_VIEWS_SCORE is null then Y.PAGE_VIEWS_SCORE else X.PAGE_VIEWS_SCORE end              
,X.RETURN_FREQUENCY_SCORE = Y.RETURN_FREQUENCY_SCORE
,X.EMAIL_INTERACTION_SCORE = Y.EMAIL_INTERACTION_SCORE
,X.NON_BOUNCE_SESSIONS = Y.NON_BOUNCE_SESSIONS
,X.CROSS_BRAND = case when X.CROSS_BRAND is null then Y.CROSS_BRAND else X.CROSS_BRAND end
,X.MULTIPLE_DEVICE_LOGIN = Y.MULTIPLE_DEVICE_LOGIN
,X.ACTIVE_FOR_LAST_MONTH = Y.ACTIVE_FOR_LAST_MONTH
,X.ACTIVE_FOR_LAST_3_MONTHS = Y.ACTIVE_FOR_LAST_3_MONTHS
,X.REGISTRATION = case when X.REGISTRATION is null then Y.REGISTRATION else X.REGISTRATION end
,X.LOGIN  = Y.LOGIN                          
,X.NEWSLETTER_SUBSCRIPTION = case when X.NEWSLETTER_SUBSCRIPTION is null then Y.NEWSLETTER_SUBSCRIPTION else X.NEWSLETTER_SUBSCRIPTION end
,X.RETAILER_CLICK_OUT = Y.RETAILER_CLICK_OUT
,X.BUY_NOW = X.BUY_NOW + Y.BUY_NOW
,X.THEME_CONTENT_CONSUMPTION       = X.THEME_CONTENT_CONSUMPTION       + Y.THEME_CONTENT_CONSUMPTION      
,X.PRODUCT_CONTENT_CONSUMPTION     = X.PRODUCT_CONTENT_CONSUMPTION     + Y.PRODUCT_CONTENT_CONSUMPTION    
,X.NON_MEDIA_ASSISTED_SESSION      = X.NON_MEDIA_ASSISTED_SESSION      + Y.NON_MEDIA_ASSISTED_SESSION     
,X.DIRECT_ACCESS_SESSION           = X.DIRECT_ACCESS_SESSION           + Y.DIRECT_ACCESS_SESSION          
,X.SHARED_OR_SOCIAL_ACCESS_SESSION = X.SHARED_OR_SOCIAL_ACCESS_SESSION + Y.SHARED_OR_SOCIAL_ACCESS_SESSION
,X.BRANDED_SEARCH_ACCESS_SESSION   = X.BRANDED_SEARCH_ACCESS_SESSION   + Y.BRANDED_SEARCH_ACCESS_SESSION  
,X.NON_BRANDED_SEARCH_ACCESS_SESSION = X.BRANDED_SEARCH_ACCESS_SESSION   + Y.BRANDED_SEARCH_ACCESS_SESSION 
,X.EMAIL_ACCESS_SESSION = X.EMAIL_ACCESS_SESSION + Y.EMAIL_ACCESS_SESSION         
,X.INTERNAL_SITE_SEARCH = X.INTERNAL_SITE_SEARCH + Y.INTERNAL_SITE_SEARCH         
,X.ADD_REVIEW    = X.ADD_REVIEW    + Y.ADD_REVIEW                    
,X.SOCIAL_CLICKS = X.SOCIAL_CLICKS + Y.SOCIAL_CLICKS                 
,X.Profile_Opt_Ins = case when X.Profile_Opt_Ins is null then Y.Profile_Opt_Ins else X.Profile_Opt_Ins end
,X.FIRST_TIME_VISITORS = Y.FIRST_TIME_VISITORS
,X.POME_CONSUMER = case when X.POME_CONSUMER is null then Y.POME_CONSUMER else X.POME_CONSUMER end
,X.ENGAGED_CONSUMER = case when X.ENGAGED_CONSUMER is null then Y.ENGAGED_CONSUMER else X.ENGAGED_CONSUMER end
,X.POLLEN_PAL = case when X.POLLEN_PAL is null then Y.POLLEN_PAL else X.POLLEN_PAL end
,X.ANDREX_CLEAN_PROFILER  = case when X.ANDREX_CLEAN_PROFILER is null then Y.ANDREX_CLEAN_PROFILER else X.ANDREX_CLEAN_PROFILER end   
##########################################################################################################        
*/



WHEN NOT MATCHED THEN
INSERT (
GIGYAID_OR_CLIENTID
,BRAND
,COUNTRY_CODE
,REGION
,SECTOR
,TOTAL_PAGEVIEW_TIME                   
,TOTAL_TIMEONSITE                      
,TOTAL_NUM_SESSIONS                    
,TOTAL_PAGEPATH_COUNT                  
,PAGEVIEWS                             
,FINAL_RETURN_FREQUENCY_SLOT           
,EMAIL_INTERACTION_CNT                 
,NO_NON_BOUNCE_SESSION             
,BRAND_COUNT                           
,MULTIPLE_DEVICE_LOGIN_CNT             
,REGISTRATION_CNT            
,REGISTRATION_DATE          
,LOGIN_CNT                             
,NEWSLETTER_SUBSCRIPTION_CNT           
,RETAILER_CLICK_OUT_CNT                
,BUY_NOW_CNT                           
,THEME_CONTENT_CONSUMPTION_CNT         
,PRODUCT_CONTENT_CONSUMPTION_CNT       
,NON_MEDIA_ASSISTED_SESSION_CNT        
,DIRECT_ACCESS_SESSION_CNT             
,SHARED_OR_SOCIAL_ACCESS_SESSION_CNT   
,BRANDED_SEARCH_ACCESS_SESSION_CNT     
,NON_BRANDED_SEARCH_ACCESS_SESSION_CNT 
,EMAIL_ACCESS_SESSION_CNT              
,INTERNAL_SITE_SEARCH_CNT              
,ADD_REVIEW_CNT                        
,SOCIAL_CLICKS_CNT                     
,FIRST_TIME_VISITORS_CNT               
,TOTAL_HVA_CNT
,NO_OF_SESSION_SCORE
,PAGE_VIEWS_SCORE
,RETURN_FREQUENCY_SCORE
,EMAIL_INTERACTION_SCORE
,NON_BOUNCE_SESSIONS
,CROSS_BRAND
,MULTIPLE_DEVICE_LOGIN
,ACTIVE_FOR_LAST_MONTH
,ACTIVE_FOR_LAST_3_MONTHS
,REGISTRATION
,LOGIN
,NEWSLETTER_SUBSCRIPTION
,RETAILER_CLICK_OUT
,BUY_NOW
,THEME_CONTENT_CONSUMPTION
,PRODUCT_CONTENT_CONSUMPTION
,NON_MEDIA_ASSISTED_SESSION
,DIRECT_ACCESS_SESSION
,SHARED_OR_SOCIAL_ACCESS_SESSION
,BRANDED_SEARCH_ACCESS_SESSION
,NON_BRANDED_SEARCH_ACCESS_SESSION
,EMAIL_ACCESS_SESSION
,INTERNAL_SITE_SEARCH
,ADD_REVIEW
,SOCIAL_CLICKS
,PROFILE_OPT_INS
,FIRST_TIME_VISITORS
,POME_CONSUMER
,ENGAGED_CONSUMER
,POLLEN_PAL
,ANDREX_CLEAN_PROFILER
,AGG_HVA_SCORE
,INSERT_DTM
,UPDATE_DTM                       


) VALUES 
(
Y.GIGYAID_OR_CLIENTID
,Y.BRAND
,Y.COUNTRY_CODE
,Y.REGION
,Y.SECTOR
,Y.TOTAL_PAGEVIEW_TIME                   
,Y.TOTAL_TIMEONSITE                      
,Y.TOTAL_NUM_SESSIONS                    
,Y.TOTAL_PAGEPATH_COUNT                  
,Y.PAGEVIEWS                             
,Y.FINAL_RETURN_FREQUENCY_SLOT           
,Y.EMAIL_INTERACTION_CNT                 
,Y.NO_NON_BOUNCE_SESSION             
,Y.BRAND_COUNT                           
,Y.MULTIPLE_DEVICE_LOGIN_CNT             
,Y.REGISTRATION_CNT             
,Y.REGISTRATION_DATE         
,Y.LOGIN_CNT                             
,Y.NEWSLETTER_SUBSCRIPTION_CNT           
,Y.RETAILER_CLICK_OUT_CNT                
,Y.BUY_NOW_CNT                           
,Y.THEME_CONTENT_CONSUMPTION_CNT         
,Y.PRODUCT_CONTENT_CONSUMPTION_CNT       
,Y.NON_MEDIA_ASSISTED_SESSION_CNT        
,Y.DIRECT_ACCESS_SESSION_CNT             
,Y.SHARED_OR_SOCIAL_ACCESS_SESSION_CNT   
,Y.BRANDED_SEARCH_ACCESS_SESSION_CNT     
,Y.NON_BRANDED_SEARCH_ACCESS_SESSION_CNT 
,Y.EMAIL_ACCESS_SESSION_CNT              
,Y.INTERNAL_SITE_SEARCH_CNT              
,Y.ADD_REVIEW_CNT                        
,Y.SOCIAL_CLICKS_CNT                     
,Y.FIRST_TIME_VISITORS_CNT               
,Y.TOTAL_HVA_CNT
,Y.NO_OF_SESSION_SCORE
,Y.PAGE_VIEWS_SCORE
,Y.RETURN_FREQUENCY_SCORE
,Y.EMAIL_INTERACTION_SCORE
,Y.NON_BOUNCE_SESSIONS
,Y.CROSS_BRAND
,Y.MULTIPLE_DEVICE_LOGIN
,Y.ACTIVE_FOR_LAST_MONTH
,Y.ACTIVE_FOR_LAST_3_MONTHS
,Y.REGISTRATION
,Y.LOGIN
,Y.NEWSLETTER_SUBSCRIPTION
,Y.RETAILER_CLICK_OUT
,Y.BUY_NOW
,Y.THEME_CONTENT_CONSUMPTION
,Y.PRODUCT_CONTENT_CONSUMPTION
,Y.NON_MEDIA_ASSISTED_SESSION
,Y.DIRECT_ACCESS_SESSION
,Y.SHARED_OR_SOCIAL_ACCESS_SESSION
,Y.BRANDED_SEARCH_ACCESS_SESSION
,Y.NON_BRANDED_SEARCH_ACCESS_SESSION
,Y.EMAIL_ACCESS_SESSION
,Y.INTERNAL_SITE_SEARCH
,Y.ADD_REVIEW
,Y.SOCIAL_CLICKS
,Y.PROFILE_OPT_INS
,Y.FIRST_TIME_VISITORS
,Y.POME_CONSUMER
,Y.ENGAGED_CONSUMER
,Y.POLLEN_PAL
,Y.ANDREX_CLEAN_PROFILER
,Y.AGG_HVA_SCORE
,Y.INSERT_DTM
,Y.UPDATE_DTM
)
