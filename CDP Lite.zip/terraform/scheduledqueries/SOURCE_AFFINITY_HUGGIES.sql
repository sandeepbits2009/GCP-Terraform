with 

--fetching gigyaid for all clientids
gigya as
(
	select 
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND upper(BRAND        )="HUGGIES"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="BCC" 
),

--fetching ga data for all gigyaid's or clientid's along with there affinity slot(timeslot)

entire_data_for_delta_records AS
(
select 
ga.clientid as final_clientid
,gigya.gigyaid as final_gigyaid,
COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,case 
when (REGEXP_CONTAINS(lower(trafficSource.source),r"bing")) then "bing"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"facebook")) then "facebook"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"google")) then "google"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"instagram")) then "instagram"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"kctd")) then "kctd"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"newsletter")) then "newsletter"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"pinterest")) then "pinterest"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"sfmc")) then "sfmc"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"twitter")) then "twitter"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"youtube")) then "youtube"
when (REGEXP_CONTAINS(lower(trafficSource.source),r"direct")) then "direct"
else "Not Known"
end as SourceSlot
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
from `hmp-emea-reporting.234507856.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid
),

--calculating aggregated data for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B_SourceSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,SourceSlot
, count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) as SourceSlot_total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) as SourceSlot_no_non_bounce_session
,
(
    (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) 
) as preTime
,hits.time as currTime
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid) total_timeOnSite
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) SourceSlot_total_timeOnSite
,count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid) total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid) no_non_bounce_session
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) as SourceSlot_total_hits
,countif(split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid) as total_page_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) as SourceSlot_total_page_count
,
(
(case when hits.type = "PAGE" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "PAGE" then hits.time else null END as currTime1
--,hits.time,hits.type,visitId,visitStartTime,date,hits.hitnumber
,hits.type as hits_type
,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits

where  SourceSlot is not null 
),

--recalculating aggregated data from above data block for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B1_SourceSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,SourceSlot
,SourceSlot_total_num_sessions
,SourceSlot_no_non_bounce_session
,SourceSlot_total_hits
,total_timeOnSite
,total_num_sessions	
,no_non_bounce_session
,total_hits
,total_pagepath_count
,total_page_count
,SourceSlot_total_page_count
,SourceSlot_total_timeOnSite
--,SUM(COALESCE(round(safe_divide((currTime-preTime),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) as SourceSlot_total_timeOnSite
,SUM(COALESCE(round(safe_divide((case when hits_type = "PAGE" then currTime-preTime ELSE 0 END),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,SourceSlot) as SourceSlot_Pageview_time
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_Pageview_time  
from B_SourceSlot
),

--calculating various GA scores percentage for clientid or gigyaid

inter_SourceSlot as
(
select 
distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,A.Gigyaid_or_clientid_nm
,SourceSlot
,total_page_count
,SourceSlot_total_page_count
,round(safe_divide(SourceSlot_total_page_count,total_page_count)*5,2) as SourceSlot_total_page_count_score
,SourceSlot_Pageview_time
,total_Pageview_time
,round(safe_divide(SourceSlot_Pageview_time,total_Pageview_time)*5,2) as SourceSlot_Pageview_time_score
,SourceSlot_total_timeOnSite
,total_timeOnSite
,round(safe_divide(SourceSlot_total_timeOnSite,total_timeOnSite)*5,2) as SourceSlot_total_timeOnSite_score
,SourceSlot_no_non_bounce_session
,SourceSlot_total_num_sessions
,round(safe_divide(SourceSlot_no_non_bounce_session,SourceSlot_total_num_sessions)*5,2) as SourceSlot_no_non_bounce_session_score
,SourceSlot_total_num_sessions as SourceSlot_total_num_visits
,total_num_sessions as total_num_visits
,round(safe_divide(SourceSlot_no_non_bounce_session,total_num_sessions)*5,2) as SourceSlot_total_num_visits_score
,SourceSlot_total_hits
,total_hits
,round(safe_divide(SourceSlot_total_hits,total_hits)*5,2) as SourceSlot_total_hits_score
from B1_SourceSlot
),

--calculating final score percentage for clientid or gigyaid by combining GA and SFMC data for timeslot

final_SourceSlot as
(

select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,Gigyaid_or_clientid_nm
,SourceSlot as SOURCE_SLOT
,SourceSlot_total_page_count_score
,SourceSlot_Pageview_time_score
,SourceSlot_total_timeOnSite_score
,SourceSlot_no_non_bounce_session_score
,SourceSlot_total_num_visits_score
,SourceSlot_total_hits_score
,round(safe_divide(
(
COALESCE(SourceSlot_total_page_count_score,0) +
COALESCE(SourceSlot_Pageview_time_score,0) + 
COALESCE(SourceSlot_total_timeOnSite_score,0) + 
COALESCE(SourceSlot_no_non_bounce_session_score,0) + 
COALESCE(SourceSlot_total_num_visits_score,0) + 
COALESCE(SourceSlot_total_hits_score,0)
),6),2)
as SOURCE_SCORE
from inter_SourceSlot as inter

)

--fetching required fields for clientid and gigyaid

select distinct
final_clientid as CLIENTID
,final_gigyaid as GIGYAID
,"Huggies" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"BCC" as SECTOR
,SOURCE_SLOT
,SOURCE_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from final_SourceSlot
where SOURCE_SLOT is not null