MERGE staging_layer.PRODUCT_AFFINITY X
USING 
(
with 

delta_records AS
(
select distinct clientid from `hmp-emea-reporting.183942593.ga_sessions_*` 
	where _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
),

gigya as
(
	select distinct
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
	,row_number() over (partition by CLIENTID,BRAND,COUNTRY_CODE,REGION,SECTOR order by CLIENTID desc,GIGYAID desc) as rn
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND GIGYAID in (select distinct GIGYAID from staging_layer.ID_RESOLUTION 
	where clientid in (select distinct clientid from delta_records)) 
	AND upper(BRAND        )="KLEENEX"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="FC" 
),

entire_data_for_delta_records AS
(
select 
ga.clientid as final_clientid
,gigya.gigyaid as final_gigyaid,
COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
from `hmp-emea-reporting.183942593.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid and rn=1
where (ga.clientid in (select distinct clientid from Gigya) or ga.clientid in (select distinct clientid from delta_records))
AND ( _table_suffix between FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY))
	AND FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)))

),


--calculating aggregated data for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B_product as
(
select --distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,url.product_type as productSlot
, count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid,url.product_type) as productSlot_total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid,url.product_type) as productSlot_no_non_bounce_session
,
(
   case when hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null then ((LAG(hits.time)
    OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
     ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)))
     END 
) as preTime
,(
   case when hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null then hits.time
     END 
) as currTime
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid) total_timeOnSite
,count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid) total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid) no_non_bounce_session
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid,url.product_type) as productSlot_total_hits
,countif(hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,countif(hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid,url.product_type) as ProductSlot_total_pagepath_count
,
(
(case when hits.type = "EVENT" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "EVENT" then hits.time else null END as currTime1
--,hits.time,hits.type,visitId,visitStartTime,date,hits.hitnumber
,hits.type as hits_type
,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits
,kc_cdplite_lookup.LKP_KLEENEX_URL_CATEGORY url
where -- url.product_type is not null and
( lower(ltrim(rtrim(substr(url.url,9))))=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)]
or lower(ltrim(rtrim(split(url.url,".co.uk")[SAFE_OFFSET(1)])))=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] )
),

--recalculating aggregated data from above data block for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B1_product as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,productSlot
,productSlot_total_num_sessions
,productSlot_no_non_bounce_session
,productSlot_total_hits
,total_timeOnSite
,total_num_sessions	
,no_non_bounce_session
,total_hits
,total_pagepath_count
,productSlot_total_pagepath_count
,SUM(COALESCE(round(safe_divide((currTime-preTime),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,productSlot) as productSlot_total_timeOnSite
,SUM(COALESCE(round(safe_divide((case when hits_type = "EVENT" then currTime-preTime ELSE 0 END),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,productSlot) as productSlot_Eventview_time
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_eventview_time  
from B_product
),

--calculating various GA scores percentage for clientid or gigyaid

inter_product as
(
select 
distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,A.Gigyaid_or_clientid_nm
,productSlot
,total_pagepath_count
,productSlot_total_pagepath_count
,round(safe_divide(productSlot_total_pagepath_count,total_pagepath_count)*5,2) as productSlot_total_pagepath_count_score
,productSlot_Eventview_time
,total_Eventview_time
,round(safe_divide(productSlot_Eventview_time,total_Eventview_time)*5,2) as productSlot_Eventview_time_score
,productSlot_total_timeOnSite
,total_timeOnSite
,round(safe_divide(productSlot_total_timeOnSite,total_timeOnSite)*5,2) as productSlot_total_timeOnSite_score
,productSlot_no_non_bounce_session
,productSlot_total_num_sessions
,round(safe_divide(productSlot_no_non_bounce_session,productSlot_total_num_sessions)*5,2) as productSlot_no_non_bounce_session_score
,productSlot_total_num_sessions as productSlot_total_num_visits
,total_num_sessions as total_num_visits
,round(safe_divide(productSlot_no_non_bounce_session,total_num_sessions)*5,2) as productSlot_total_num_visits_score
,productSlot_total_hits
,total_hits
,round(safe_divide(productSlot_total_hits,total_hits)*5,2) as productSlot_total_hits_score
from B1_product
),

--calculating final score percentage for clientid or gigyaid by combining GA and SFMC data for timeslot

final_product as
(

select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,Gigyaid_or_clientid_nm
,productSlot as PRODUCT_SLOT
,productSlot_total_pagepath_count_score
,productSlot_Eventview_time_score
,productSlot_total_timeOnSite_score
,productSlot_no_non_bounce_session_score
,productSlot_total_num_visits_score
,productSlot_total_hits_score
,round(safe_divide(
(
COALESCE(productSlot_total_pagepath_count_score,0) +
COALESCE(productSlot_Eventview_time_score,0) + 
COALESCE(productSlot_total_timeOnSite_score,0) + 
COALESCE(productSlot_no_non_bounce_session_score,0) + 
COALESCE(productSlot_total_num_visits_score,0) + 
COALESCE(productSlot_total_hits_score,0)
),6),2)
as PRODUCT_SCORE
from inter_product as inter

)

--fetching required fields for clientid and gigyaid

select 
final_clientid as CLIENTID
,final_gigyaid as GIGYAID
,"Kleenex" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"FC" as SECTOR
,PRODUCT_SLOT
,PRODUCT_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from final_product
where PRODUCT_SLOT is not null
) Y
ON COALESCE(X.GIGYAID,'A') = COALESCE(Y.GIGYAID,'A') AND COALESCE(X.CLIENTID,'A') = COALESCE(Y.CLIENTID,'A') and X.Brand = Y.Brand and X.Country_Code = Y.Country_Code and X.Region = Y.Region and X.sector = Y.sector and  X.PRODUCT_SLOT = Y.PRODUCT_SLOT
WHEN MATCHED THEN
UPDATE set 
 X.PRODUCT_SCORE = Y.PRODUCT_SCORE
,X.UPDATE_DTM = Y.UPDATE_DTM
WHEN NOT MATCHED THEN
INSERT (
clientID,
GigyaID,
Brand,
Country_Code,
Region,
sector,
PRODUCT_SLOT,
PRODUCT_SCORE,
INSERT_DTM,
UPDATE_DTM
) VALUES 
(
Y.clientID,
Y.GigyaID,
Y.Brand,
Y.Country_Code,
Y.Region,
Y.sector,
Y.PRODUCT_SLOT,
Y.PRODUCT_SCORE,
Y.INSERT_DTM,
Y.UPDATE_DTM
)

