MERGE staging_layer.TIME_AFFINITY X
USING 
(
with 

--fetching delta records for yesterday's data.

delta_records AS
(
select distinct clientid from `hmp-emea-reporting.185006019.ga_sessions_*` 
	where _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
),

--fetching gigyaid for all clientids
gigya as
(
	select distinct
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND GIGYAID in (select distinct GIGYAID from staging_layer.ID_RESOLUTION 
	where clientid in (select distinct clientid from delta_records))
	AND upper(BRAND        )="ANDREX"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="FC" 
),

--fetching ga data for all gigyaid's or clientid's along with there affinity slot(timeslot)

entire_data_for_delta_records AS
(
select 
ga.clientid as final_clientid
,gigya.gigyaid as final_gigyaid,
COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,case 
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (0,1,2) then "0000-0300"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (3,4,5) then "0300-0600"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (6,7,8) then "0600-0900"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (9,10,11) then "0900-1200"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (12,13,14) then "1200-1500"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (15,16,17) then "1500-1800"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (18,19,20) then "1800-2100"
when (EXTRACT(hour from TIMESTAMP_SECONDS (visitstarttime))) in (21,22,23) then "2100-2359"
else NULL
end as TimeSlot
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
from `hmp-emea-reporting.185006019.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid
where (ga.clientid in (select distinct clientid from Gigya) or ga.clientid in (select distinct clientid from delta_records))
AND ( _table_suffix between FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY))
	AND FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)))
),

--SFMC timeslot and SFMC_Time_Score for each SubscriberKey/GigyaID

sfmc_fc as
(
select gigya.clientid as sfmc_clientid, * from (
select SubscriberKey,lastopen_Timeslot,(A+B+C+D)/4 as SFMC_Time_Score from(
select sub_open.SubscriberKey,lastopen_Timeslot
,lastopen_count,lastclick_count
,t_lastopen_date,t_LastSend_Date,t_LastClick_Date
,round(safe_divide(lastopen_count,t_LastSend_Date)*5) as A
,round(safe_divide(lastclick_count,t_lastopen_date)*5) as B
,round(safe_divide(lastopen_count,t_lastopen_date)*5) as C
,round(safe_divide(lastclick_count,t_LastClick_Date)*5) as D
from
(select SubscriberKey, 
case 
when (EXTRACT(hour from timestamp(lastopen_date))) in (0,1,2) then "0000-0300"
when (EXTRACT(hour from timestamp(lastopen_date))) in (3,4,5) then "0300-0600"
when (EXTRACT(hour from timestamp(lastopen_date))) in (6,7,8) then "0600-0900"
when (EXTRACT(hour from timestamp(lastopen_date))) in (9,10,11) then "0900-1200"
when (EXTRACT(hour from timestamp(lastopen_date))) in (12,13,14) then "1200-1500"
when (EXTRACT(hour from timestamp(lastopen_date))) in (15,16,17) then "1500-1800"
when (EXTRACT(hour from timestamp(lastopen_date))) in (18,19,20) then "1800-2100"
when (EXTRACT(hour from timestamp(lastopen_date))) in (21,22,23) then "2100-2359"
else NULL
end as lastopen_TimeSlot
, count(1) as lastopen_count
from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
group by SubscriberKey,lastopen_TimeSlot 
)sub_open

join (
select SubscriberKey,
case 
when (EXTRACT(hour from timestamp(lastClick_date))) in (0,1,2) then "0000-0300"
when (EXTRACT(hour from timestamp(lastClick_date))) in (3,4,5) then "0300-0600"
when (EXTRACT(hour from timestamp(lastClick_date))) in (6,7,8) then "0600-0900"
when (EXTRACT(hour from timestamp(lastClick_date))) in (9,10,11) then "0900-1200"
when (EXTRACT(hour from timestamp(lastClick_date))) in (12,13,14) then "1200-1500"
when (EXTRACT(hour from timestamp(lastClick_date))) in (15,16,17) then "1500-1800"
when (EXTRACT(hour from timestamp(lastClick_date))) in (18,19,20) then "1800-2100"
when (EXTRACT(hour from timestamp(lastClick_date))) in (21,22,23) then "2100-2359"
else NULL
end as lastClick_TimeSlot
, count(1) as lastClick_count
from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
group by SubscriberKey,lastClick_TimeSlot 
)sub_click
on sub_open.SubscriberKey =sub_click.SubscriberKey and sub_open.lastopen_TimeSlot=sub_click.lastClick_TimeSlot
join (
select SubscriberKey, 
countif(lastopen_date is not null)      as t_lastopen_date
, countif(LastSend_Date is not null )   as t_LastSend_Date
, countif(LastClick_Date is not null )  as t_LastClick_Date
from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
group by SubscriberKey 
)sub_agg
on sub_open.SubscriberKey =sub_agg.SubscriberKey
)sub_time
)sfmc left join gigya on sfmc.SubscriberKey=gigya.GIGYAID
),

--calculating aggregated data for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B_TimeSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,TimeSlot
, count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) as TimeSlot_total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) as TimeSlot_no_non_bounce_session
,
(
    (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) 
) as preTime
,hits.time as currTime
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid) total_timeOnSite
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) TimeSlot_total_timeOnSite
,count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid) total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid) no_non_bounce_session
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) as TimeSlot_total_hits
,countif(split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid) as total_page_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) as TimeSlot_total_page_count
,
(
(case when hits.type = "PAGE" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "PAGE" then hits.time else null END as currTime1
--,hits.time,hits.type,visitId,visitStartTime,date,hits.hitnumber
,hits.type as hits_type
,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits

where  TimeSlot is not null 
),

--recalculating aggregated data from above data block for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B1_TimeSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,TimeSlot
,TimeSlot_total_num_sessions
,TimeSlot_no_non_bounce_session
,TimeSlot_total_hits
,total_timeOnSite
,total_num_sessions	
,no_non_bounce_session
,total_hits
,total_pagepath_count
,total_page_count
,TimeSlot_total_page_count
,TimeSlot_total_timeOnSite
--,SUM(COALESCE(round(safe_divide((currTime-preTime),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) as TimeSlot_total_timeOnSite
,SUM(COALESCE(round(safe_divide((case when hits_type = "PAGE" then currTime-preTime ELSE 0 END),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,TimeSlot) as TimeSlot_Pageview_time
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_Pageview_time  
from B_TimeSlot
),

--calculating various GA scores percentage for clientid or gigyaid

inter_TimeSlot as
(
select 
distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,A.Gigyaid_or_clientid_nm
,TimeSlot
,total_page_count
,TimeSlot_total_page_count
,round(safe_divide(TimeSlot_total_page_count,total_page_count)*5,2) as TimeSlot_total_page_count_score
,TimeSlot_Pageview_time
,total_Pageview_time
,round(safe_divide(TimeSlot_Pageview_time,total_Pageview_time)*5,2) as TimeSlot_Pageview_time_score
,TimeSlot_total_timeOnSite
,total_timeOnSite
,round(safe_divide(TimeSlot_total_timeOnSite,total_timeOnSite)*5,2) as TimeSlot_total_timeOnSite_score
,TimeSlot_no_non_bounce_session
,TimeSlot_total_num_sessions
,round(safe_divide(TimeSlot_no_non_bounce_session,TimeSlot_total_num_sessions)*5,2) as TimeSlot_no_non_bounce_session_score
,TimeSlot_total_num_sessions as TimeSlot_total_num_visits
,total_num_sessions as total_num_visits
,round(safe_divide(TimeSlot_no_non_bounce_session,total_num_sessions)*5,2) as TimeSlot_total_num_visits_score
,TimeSlot_total_hits
,total_hits
,round(safe_divide(TimeSlot_total_hits,total_hits)*5,2) as TimeSlot_total_hits_score
from B1_TimeSlot
),

--calculating final score percentage for clientid or gigyaid by combining GA and SFMC data for timeslot

final_TimeSlot as
(

select distinct
COALESCE(final_clientid,sfmc_fc.sfmc_clientid) as final_clientid
,COALESCE(final_gigyaid,sfmc_fc.SubscriberKey) as final_gigyaid,
COALESCE(Gigyaid_or_clientid,sfmc_fc.SubscriberKey) as Gigyaid_or_clientid
--,Gigyaid_or_clientid_nm
,COALESCE(TimeSlot,sfmc_fc.lastopen_Timeslot) as TIME_SLOT
,TimeSlot_total_page_count_score
,TimeSlot_Pageview_time_score
,TimeSlot_total_timeOnSite_score
,TimeSlot_no_non_bounce_session_score
,TimeSlot_total_num_visits_score
,TimeSlot_total_hits_score
,SFMC_Time_Score
,round(safe_divide(
(
COALESCE(TimeSlot_total_page_count_score,0) +
COALESCE(TimeSlot_Pageview_time_score,0) + 
COALESCE(TimeSlot_total_timeOnSite_score,0) + 
COALESCE(TimeSlot_no_non_bounce_session_score,0) + 
COALESCE(TimeSlot_total_num_visits_score,0) + 
COALESCE(TimeSlot_total_hits_score,0) +
COALESCE(SFMC_Time_Score,0)
),(6+COALESCE(if(SFMC_Time_Score is null,0,null),1))),2)
as TIME_SCORE
from inter_TimeSlot as inter
full join sfmc_fc 
on COALESCE(inter.Gigyaid_or_clientid,inter.final_gigyaid)=sfmc_fc.SubscriberKey 
and inter.TimeSlot=sfmc_fc.lastopen_Timeslot
)

--fetching required fields for clientid and gigyaid

select distinct
final_clientid as CLIENTID
,final_gigyaid as GIGYAID
,"Andrex" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"FC" as SECTOR
,TIME_SLOT
,TIME_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from final_TimeSlot
where TIME_SLOT is not null
) Y
ON COALESCE(X.GIGYAID,'A') = COALESCE(Y.GIGYAID,'A') AND COALESCE(X.CLIENTID,'A') = COALESCE(Y.CLIENTID,'A') AND X.BRAND = Y.BRAND AND X.COUNTRY_CODE = Y.COUNTRY_CODE AND X.REGION = Y.REGION AND X.SECTOR = Y.SECTOR AND  X.TIME_SLOT = Y.TIME_SLOT
WHEN MATCHED THEN
UPDATE SET 
 X.TIME_SCORE = Y.TIME_SCORE
,X.UPDATE_DTM = Y.UPDATE_DTM
WHEN NOT MATCHED THEN
INSERT (
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION
,SECTOR
,TIME_SLOT
,TIME_SCORE
,INSERT_DTM
,UPDATE_DTM
) VALUES 
(
Y.CLIENTID
,Y.GIGYAID
,Y.BRAND
,Y.COUNTRY_CODE
,Y.REGION
,Y.SECTOR
,Y.TIME_SLOT
,Y.TIME_SCORE
,Y.INSERT_DTM
,Y.UPDATE_DTM
)