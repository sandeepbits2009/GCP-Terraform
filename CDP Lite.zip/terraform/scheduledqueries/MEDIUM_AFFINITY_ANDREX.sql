with 

--fetching gigyaid for all clientids
gigya as
(
	select 
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
     from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND upper(BRAND        )="ANDREX"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="FC" 
),

--fetching ga data for all gigyaid's or clientid's along with there affinity slot(timeslot)

entire_data_for_delta_records AS
(
select 
ga.clientid as final_clientid
,gigya.gigyaid as final_gigyaid,
COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,case 
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"ppc")) then "ppc"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"email")) then "email"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"ola")) then "ola"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"olv")) then "olv"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"organic")) then "organic"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"paid_social")) then "paid_social"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"pinterest")) then "pinterest"
when (REGEXP_CONTAINS(lower(trafficSource.Medium),r"sms")) then "sms"
else "Not Known"
end as MediumSlot
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
from `hmp-emea-reporting.185006019.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid
),

--calculating aggregated data for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B_MediumSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,MediumSlot
, count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) as MediumSlot_total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) as MediumSlot_no_non_bounce_session
,
(
    (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) 
) as preTime
,hits.time as currTime
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid) total_timeOnSite
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) MediumSlot_total_timeOnSite
,count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid) total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid) no_non_bounce_session
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) as MediumSlot_total_hits
,countif(split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid) as total_page_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) as MediumSlot_total_page_count
,
(
(case when hits.type = "PAGE" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "PAGE" then hits.time else null END as currTime1
--,hits.time,hits.type,visitId,visitStartTime,date,hits.hitnumber
,hits.type as hits_type
,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits

where  MediumSlot is not null 
),

--recalculating aggregated data from above data block for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B1_MediumSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,MediumSlot
,MediumSlot_total_num_sessions
,MediumSlot_no_non_bounce_session
,MediumSlot_total_hits
,total_timeOnSite
,total_num_sessions	
,no_non_bounce_session
,total_hits
,total_pagepath_count
,total_page_count
,MediumSlot_total_page_count
,MediumSlot_total_timeOnSite
--,SUM(COALESCE(round(safe_divide((currTime-preTime),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) as MediumSlot_total_timeOnSite
,SUM(COALESCE(round(safe_divide((case when hits_type = "PAGE" then currTime-preTime ELSE 0 END),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,MediumSlot) as MediumSlot_Pageview_time
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_Pageview_time  
from B_MediumSlot
),

--calculating various GA scores percentage for clientid or gigyaid

inter_MediumSlot as
(
select 
distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,A.Gigyaid_or_clientid_nm
,MediumSlot
,total_page_count
,MediumSlot_total_page_count
,round(safe_divide(MediumSlot_total_page_count,total_page_count)*5,2) as MediumSlot_total_page_count_score
,MediumSlot_Pageview_time
,total_Pageview_time
,round(safe_divide(MediumSlot_Pageview_time,total_Pageview_time)*5,2) as MediumSlot_Pageview_time_score
,MediumSlot_total_timeOnSite
,total_timeOnSite
,round(safe_divide(MediumSlot_total_timeOnSite,total_timeOnSite)*5,2) as MediumSlot_total_timeOnSite_score
,MediumSlot_no_non_bounce_session
,MediumSlot_total_num_sessions
,round(safe_divide(MediumSlot_no_non_bounce_session,MediumSlot_total_num_sessions)*5,2) as MediumSlot_no_non_bounce_session_score
,MediumSlot_total_num_sessions as MediumSlot_total_num_visits
,total_num_sessions as total_num_visits
,round(safe_divide(MediumSlot_no_non_bounce_session,total_num_sessions)*5,2) as MediumSlot_total_num_visits_score
,MediumSlot_total_hits
,total_hits
,round(safe_divide(MediumSlot_total_hits,total_hits)*5,2) as MediumSlot_total_hits_score
from B1_MediumSlot
),

--calculating final score percentage for clientid or gigyaid by combining GA and SFMC data for timeslot

final_MediumSlot as
(

select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,Gigyaid_or_clientid_nm
,MediumSlot as MEDIUM_SLOT
,MediumSlot_total_page_count_score
,MediumSlot_Pageview_time_score
,MediumSlot_total_timeOnSite_score
,MediumSlot_no_non_bounce_session_score
,MediumSlot_total_num_visits_score
,MediumSlot_total_hits_score
,round(safe_divide(
(
COALESCE(MediumSlot_total_page_count_score,0) +
COALESCE(MediumSlot_Pageview_time_score,0) + 
COALESCE(MediumSlot_total_timeOnSite_score,0) + 
COALESCE(MediumSlot_no_non_bounce_session_score,0) + 
COALESCE(MediumSlot_total_num_visits_score,0) + 
COALESCE(MediumSlot_total_hits_score,0)
),6),2)
as MEDIUM_SCORE
from inter_MediumSlot as inter

)

--fetching required fields for clientid and gigyaid

select distinct
final_clientid as CLIENTID
,final_gigyaid as GIGYAID
,"Andrex" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"FC" as SECTOR
,MEDIUM_SLOT
,MEDIUM_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from FINAL_MEDIUMSLOT 
where MEDIUM_SLOT is not null