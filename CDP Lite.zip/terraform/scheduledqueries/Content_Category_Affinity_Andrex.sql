with 

--fetching gigyaid for all clientids
gigya as
(
	select distinct
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
    ,row_number() over (partition by CLIENTID,BRAND,COUNTRY_CODE,REGION,SECTOR order by CLIENTID desc,GIGYAID desc) as rn
    from staging_layer.ID_RESOLUTION 
	where CLIENTID is not null 
    AND if(GIGYAID=CLIENTID,1,0)=0 AND GIGYAID is not null
	AND upper(BRAND        )="ANDREX"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="FC" 
),

--fetching ga data for all gigyaid's or clientid's along with there affinity slot(timeslot)

entire_data_for_delta_records AS
(
select 
ga.clientid as final_clientid
,gigya.gigyaid as final_gigyaid,
COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
from `hmp-emea-reporting.185006019.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid and rn=1
),

--calculating aggregated data for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B_content_category as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,url.content_category as content_categorySlot
, count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid,url.content_category) as content_categorySlot_total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid,url.content_category) as content_categorySlot_no_non_bounce_session
,
(
   case when hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null then ((LAG(hits.time)
    OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
     ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)))
     END 
) as preTime
,(
   case when hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null then hits.time
     END 
) as currTime
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid) total_timeOnSite
,count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid) total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid) no_non_bounce_session
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid,url.content_category) as content_categorySlot_total_hits
,countif(hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,countif(hits.type = "PAGE" and split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid,url.content_category) as content_categorySlot_total_pagepath_count
,
(
(case when hits.type = "EVENT" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "EVENT" then hits.time else null END as currTime1
--,hits.time,hits.type,visitId,visitStartTime,date,hits.hitnumber
,hits.type as hits_type
,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits
,kc_cdplite_lookup.LKP_ANDREX_URL_CATEGORY url
where --url.content_category is not null 
( lower(ltrim(rtrim(substr(url.url,9))))=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)]
or lower(ltrim(rtrim(split(url.url,".co.uk")[SAFE_OFFSET(1)])))=split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] )
),

--recalculating aggregated data from above data block for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B1_content_category as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,content_categorySlot
,content_categorySlot_total_num_sessions
,content_categorySlot_no_non_bounce_session
,content_categorySlot_total_hits
,total_timeOnSite
,total_num_sessions	
,no_non_bounce_session
,total_hits
,total_pagepath_count
,content_categorySlot_total_pagepath_count
,SUM(COALESCE(round(safe_divide((currTime-preTime),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,content_categorySlot) as content_categorySlot_total_timeOnSite
,SUM(COALESCE(round(safe_divide((case when hits_type = "EVENT" then currTime-preTime ELSE 0 END),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,content_categorySlot) as content_categorySlot_Eventview_time
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_eventview_time  
from B_content_category
),

--calculating various GA scores percentage for clientid or gigyaid

inter_content_category as
(
select 
distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,A.Gigyaid_or_clientid_nm
,content_categorySlot
,total_pagepath_count
,content_categorySlot_total_pagepath_count
,round(safe_divide(content_categorySlot_total_pagepath_count,total_pagepath_count)*5,2) as content_categorySlot_total_pagepath_count_score
,content_categorySlot_Eventview_time
,total_Eventview_time
,round(safe_divide(content_categorySlot_Eventview_time,total_Eventview_time)*5,2) as content_categorySlot_Eventview_time_score
,content_categorySlot_total_timeOnSite
,total_timeOnSite
,round(safe_divide(content_categorySlot_total_timeOnSite,total_timeOnSite)*5,2) as content_categorySlot_total_timeOnSite_score
,content_categorySlot_no_non_bounce_session
,content_categorySlot_total_num_sessions
,round(safe_divide(content_categorySlot_no_non_bounce_session,content_categorySlot_total_num_sessions)*5,2) as content_categorySlot_no_non_bounce_session_score
,content_categorySlot_total_num_sessions as content_categorySlot_total_num_visits
,total_num_sessions as total_num_visits
,round(safe_divide(content_categorySlot_no_non_bounce_session,total_num_sessions)*5,2) as content_categorySlot_total_num_visits_score
,content_categorySlot_total_hits
,total_hits
,round(safe_divide(content_categorySlot_total_hits,total_hits)*5,2) as content_categorySlot_total_hits_score
from B1_content_category
),

--calculating final score percentage for clientid or gigyaid by combining GA and SFMC data for timeslot

final_content_category as
(

select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,Gigyaid_or_clientid_nm
,content_categorySlot as CONTENT_CATEGORY_SLOT
,content_categorySlot_total_pagepath_count_score
,content_categorySlot_Eventview_time_score
,content_categorySlot_total_timeOnSite_score
,content_categorySlot_no_non_bounce_session_score
,content_categorySlot_total_num_visits_score
,content_categorySlot_total_hits_score
,round(safe_divide(
(
COALESCE(content_categorySlot_total_pagepath_count_score,0) +
COALESCE(content_categorySlot_Eventview_time_score,0) + 
COALESCE(content_categorySlot_total_timeOnSite_score,0) + 
COALESCE(content_categorySlot_no_non_bounce_session_score,0) + 
COALESCE(content_categorySlot_total_num_visits_score,0) + 
COALESCE(content_categorySlot_total_hits_score,0)
),6),2)
as CONTENT_CATEGORY_SCORE
from inter_content_category as inter

)

--fetching required fields for clientid and gigyaid

select distinct
final_clientid as CLIENTID
,final_gigyaid as GIGYAID
,"Andrex" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"FC" as SECTOR
,CONTENT_CATEGORY_SLOT
,CONTENT_CATEGORY_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from final_content_category
where CONTENT_CATEGORY_SLOT is not null
order by CONTENT_CATEGORY_SCORE desc