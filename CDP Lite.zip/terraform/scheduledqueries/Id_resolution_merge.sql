



MERGE staging_layer.ID_RESOLUTION X
USING 
(

With GA as
(

Select
distinct
ClientID,
visitStartTime,
device.deviceCategory ,
device.browser ,
totals.visits,
visitID,
totals.pageviews,
hits.type,
totals.timeOnSite,
totals.bounces,
'Andrex' as Brand  from
`hmp-emea-reporting.185006019.ga_sessions_*`
--,unnest(customDimensions) customDimensions
,unnest(hits) hits
where _table_suffix=FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
UNION ALL

Select
distinct
ClientID,
visitStartTime,
device.deviceCategory ,
device.browser ,
totals.visits,
visitID,
totals.pageviews,
hits.type,
totals.timeOnSite,
totals.bounces,
'Kleenex' as Brand from
`hmp-emea-reporting.183942593.ga_sessions_*`
--,unnest(customDimensions) customDimensions
,unnest(hits) hits
where _table_suffix=FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))

UNION ALL 

Select
distinct
ClientID,
visitStartTime,
device.deviceCategory ,
device.browser ,
totals.visits,
visitID,
totals.pageviews,
hits.type,
totals.timeOnSite,
totals.bounces,
'Huggies' as Brand from
`hmp-emea-reporting.234507856.ga_sessions_*`
--,unnest(customDimensions) customDimensions
,unnest(hits) hits
where _table_suffix=FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))

),


gigya as
(
select distinct clientid, COALESCE(userId,if (customDimensions.index = 11 , customDimensions.value,null)) as Gigyaid
,'Andrex' as Brand
from `hmp-emea-reporting.185006019.ga_sessions_*`, unnest(customDimensions) customDimensions --74319 71537
where COALESCE(userId,if (customDimensions.index = 11 , customDimensions.value,null)) is not null and customDimensions.value != clientID
and _table_suffix=FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
union all 
select distinct clientid, COALESCE(userId,if (customDimensions.index = 1 , customDimensions.value,null)) as Gigyaid
,'Kleenex' as Brand
from `hmp-emea-reporting.183942593.ga_sessions_*`, unnest(customDimensions) customDimensions --74319 71537
where COALESCE(userId,if (customDimensions.index = 1 , customDimensions.value,null)) is not null and customDimensions.value != clientID
and _table_suffix=FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
union all 
select distinct clientid, COALESCE(userId,if (customDimensions.index = 4 , customDimensions.value,null)) as Gigyaid
,'Huggies' as Brand
from `hmp-emea-reporting.234507856.ga_sessions_*`, unnest(customDimensions) customDimensions --74319 71537
where COALESCE(userId,if (customDimensions.index = 4 , customDimensions.value,null)) is not null and customDimensions.value != clientID
and _table_suffix=FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))
),

base as
(

SELECT 
distinct
GA.*,
gigya.Gigyaid
from GA  left join gigya on GA.clientid = gigya.clientid and GA.Brand = gigya.Brand

),

A as

(
Select
distinct 
ClientID as CLIENTID,
Gigyaid as GIGYAID,
Brand AS BRAND,
"UK" as COUNTRY_CODE,
"EMEA" as REGION,
case when brand = 'Huggies' then 'BCC' else 'FC' end as SECTOR,
max(TIMESTAMP_SECONDS(visitStartTime)) over (partition by coalesce(Gigyaid,ClientID))as Last_Visited,
first_value(deviceCategory) over (partition by coalesce(Gigyaid,ClientID) order by visitStartTime desc) as DEVICE,
first_value(browser) over (partition by coalesce(Gigyaid,ClientID) order by visitStartTime desc) as BROWSER
from 
Base
),

 

-- Total Session, Page Count, Event Call Count, Time Spent on Website,

B as
(
Select
DISTINCT
ClientID,
Brand,
count (distinct visitID) total_Sessions,
sum(distinct pageviews) total_pagecount,
countif(type = 'EVENT') total_eventcalls,
sum(distinct timeOnSite) Timespent,
countif(bounces = 1) Bounce_Session,
from
Base
group by
ClientID,
Brand
),

--Multi brand, Device

C as
(
Select
DISTINCT
Gigyaid,
case when count(distinct Brand) > 1 then 'Y' else 'N' end as Multi_Brand_Login,
case when count(distinct deviceCategory) > 1 then 'Y' else 'N' end as Multi_Device_Login
from
Base
group by
Gigyaid
),

--Active Since

D as
(
Select
DISTINCT
ClientID,
TIMESTAMP_SECONDS(min(visitStartTime)) as Active_Since
from
Base
group by
ClientID
),

--getting max visited date at a clientid level
H as 
(
    SELECT DISTINCT  ClientID , max(Last_Visited) Last_Visited from A group by ClientID
)
SELECT distinct 
*
from
(
Select distinct 
A.CLIENTID,
A.GIGYAID,
A.BRAND,
A.COUNTRY_CODE,
A.REGION,
A.SECTOR
,if((lower(A.DEVICE)) in ("mobile", "tablet"), "Mobile",
if((lower(A.DEVICE)) in ("desktop"), "Desktop",null)) as DEVICE,
A.BROWSER,
B.total_Sessions TOTAL_SESSIONS,
B.Bounce_Session BOUNCE_SESSIONS,
B.total_Sessions - B.Bounce_Session as NON_BOUNCE_SESSIONS,
B.total_pagecount TOTAL_PAGECOUNT,
B.total_eventcalls TOTAL_EVENTCALLS,
B.Timespent TOTAL_TIMESPENT,
case when date_diff(current_date(),date(H.Last_Visited),day) >= 180 then 180 else date_diff(current_date(),date(H.Last_Visited),day) end as DAYS_SINCE_LAST_HVA,
H.Last_Visited as LAST_VISITED,
case when C.Multi_Brand_Login is null then 'N' else C.Multi_Brand_Login end as MULTI_BRAND_LOGIN,
case when C.Multi_Device_Login is null then 'N' else C.Multi_Device_Login end as MULTI_DEVICE_LOGIN ,
D.Active_Since AS ACTIVE_SINCE,
CURRENT_DATE() AS INSERT_DATE,
CURRENT_DATE() AS UPDATE_DATE
from
A left join B
on
A.ClientID = B.ClientID
left join C
on
coalesce(A.Gigyaid,A.ClientID) = C.Gigyaid
left join D
on
A.ClientID = D.ClientID
left join 
H 
on A.ClientID = H.ClientID

)
) Y
ON COALESCE(X.GIGYAID,'A') = COALESCE(Y.GIGYAID,'A') AND COALESCE(X.CLIENTID,'A') = COALESCE(Y.CLIENTID,'A') and X.Brand = Y.Brand and X.Country_Code = Y.Country_Code and X.Region = Y.Region and X.SECTOR = Y.SECTOR
WHEN MATCHED THEN
UPDATE set 
 X.Last_Visited = Y.Last_Visited
,X.Device = Y.Device
,X.Browser = Y.Browser
,X.total_Sessions = X.total_Sessions + Y.total_Sessions
,X.total_pagecount = X.total_pagecount + Y.total_pagecount 
,X.total_eventcalls = X.total_eventcalls + Y.total_eventcalls
,X.TOTAL_TIMESPENT = X.TOTAL_TIMESPENT + Y.TOTAL_TIMESPENT
,X.Non_Bounce_Sessions = X.Non_Bounce_Sessions + Y.Non_Bounce_Sessions
,X.BOUNCE_SESSIONS = X.BOUNCE_SESSIONS + Y.BOUNCE_SESSIONS
,X.Multi_Brand_Login = case when X.Multi_Brand_Login = 'N' then Y.Multi_Brand_Login else X.Multi_Brand_Login end 
,X.Multi_Device_Login = case when X.Multi_Device_Login = 'N' then Y.Multi_Device_Login else X.Multi_Device_Login end 
,X.Days_Since_Last_HVA = Y.Days_Since_Last_HVA
,X.UPDATE_DATE = CURRENT_DATE()
WHEN NOT MATCHED THEN
INSERT (
CLIENTID	,
GIGYAID	,
BRAND	,
REGION	,
SECTOR	,
DEVICE	,
BROWSER	,
TOTAL_SESSIONS	,
BOUNCE_SESSIONS	,
NON_BOUNCE_SESSIONS	,
TOTAL_PAGECOUNT	,
TOTAL_EVENTCALLS	,
TOTAL_TIMESPENT	,
DAYS_SINCE_LAST_HVA	,
LAST_VISITED	,
MULTI_BRAND_LOGIN	,
MULTI_DEVICE_LOGIN	,
ACTIVE_SINCE	,
COUNTRY_CODE	,
INSERT_DATE
) VALUES 
(
Y.CLIENTID,
Y.GIGYAID,
Y.BRAND,
Y.REGION,
Y.SECTOR,
Y.DEVICE,
Y.BROWSER,
Y.TOTAL_SESSIONS,
Y.BOUNCE_SESSIONS,
Y.NON_BOUNCE_SESSIONS,
Y.TOTAL_PAGECOUNT,
Y.TOTAL_EVENTCALLS,
Y.TOTAL_TIMESPENT,
Y.DAYS_SINCE_LAST_HVA,
Y.LAST_VISITED,
Y.MULTI_BRAND_LOGIN,
Y.MULTI_DEVICE_LOGIN,
Y.ACTIVE_SINCE,
Y.COUNTRY_CODE,
CURRENT_DATE()
)


