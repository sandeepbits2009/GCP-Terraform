MERGE staging_layer.DEVICE_AFFINITY X
USING 
(
with 

delta_records AS
(
select distinct clientid from `hmp-emea-reporting.234507856.ga_sessions_*` 
	where _table_suffix= FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))

),

--fetching gigyaid for all clientids
gigya as
(
	select 
    CLIENTID
    ,GIGYAID
    ,BRAND
    ,COUNTRY_CODE
    ,REGION
    ,SECTOR
     from staging_layer.ID_RESOLUTION  
	where clientid is not null 
    AND if(GIGYAID=clientid,1,0)=0 AND GIGYAID is not null
	AND GIGYAID in (select distinct GIGYAID from staging_layer.ID_RESOLUTION 
	where clientid in (select distinct clientid from delta_records))
	AND upper(BRAND        )="HUGGIES"	
	AND upper(COUNTRY_CODE )="UK" 	  
	AND upper(REGION       )="EMEA"   
	AND upper(SECTOR       )="BCC" 
),

entire_data_for_delta_records AS
(
select 
ga.clientid as final_clientid
,gigya.gigyaid as final_gigyaid,
COALESCE(gigya.gigyaid,ga.clientid) as Gigyaid_or_clientid
,if((lower(device.deviceCategory)) in ("mobile", "tablet"), "Mobile",
if((lower(device.deviceCategory)) in ("desktop"), "Desktop",null)) as DeviceSlot
,totals,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits
from `hmp-emea-reporting.234507856.ga_sessions_*` ga
left join gigya on ga.clientid=gigya.clientid
where (ga.clientid in (select distinct clientid from Gigya) or ga.clientid in (select distinct clientid from delta_records))
AND ( _table_suffix between FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY))
	AND FORMAT_DATE('%Y%m%d',DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)))
),

--SFMC DeviceSlot and SFMC_Device_Score for each SubscriberKey/GigyaID

sfmc_fc as
(
select gigya.clientid as sfmc_clientid, * from (
select SubscriberKey,lastopen_DeviceSlot,(A+B+C+D)/4 as SFMC_Device_Score from(
select sub_open.SubscriberKey,lastopen_DeviceSlot
,lastopen_count,lastclick_count
,t_lastopen_date,t_LastSend_Date,t_LastClick_Date
,round(safe_divide(lastopen_count,t_LastSend_Date)*5) as A
,round(safe_divide(lastclick_count,t_lastopen_date)*5) as B
,round(safe_divide(lastopen_count,t_lastopen_date)*5) as C
,round(safe_divide(lastclick_count,t_LastClick_Date)*5) as D
from
(select SubscriberKey, 
if(LastOpen_Device in ('PC', 'Macintosh'), "Desktop","Mobile") as lastopen_DeviceSlot
, count(1) as lastopen_count
from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
where lower(BRAND)='huggies'
group by SubscriberKey,lastopen_DeviceSlot 
)sub_open

join (
select SubscriberKey,
if(LastClick_Device in ('PC', 'Macintosh'), "Desktop","Mobile") as lastClick_DeviceSlot
, count(1) as lastClick_count
from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
where lower(BRAND)='huggies'
group by SubscriberKey,lastClick_DeviceSlot 
)sub_click
on sub_open.SubscriberKey =sub_click.SubscriberKey and sub_open.lastopen_DeviceSlot=sub_click.lastClick_DeviceSlot
--and sub_click.BRAND=sub_open.BRAND
join (
select SubscriberKey, 
countif(lastopen_date is not null)      as t_lastopen_date
, countif(LastSend_Date is not null )   as t_LastSend_Date
, countif(LastClick_Date is not null )  as t_LastClick_Date
from `refined_layer.SUBSCRIBER_TRACKING_DATA_VALIDATED`
where lower(brand)='huggies'
group by SubscriberKey 
)sub_agg
on sub_open.SubscriberKey =sub_agg.SubscriberKey
)sub_Device
)sfmc left join gigya on sfmc.SubscriberKey=gigya.GIGYAID
),

--calculating aggregated data for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B_DeviceSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,DeviceSlot
, count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid,DeviceSlot) as DeviceSlot_total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid,DeviceSlot) as DeviceSlot_no_non_bounce_session
,
(
    (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) 
) as preTime
,hits.time as currTime
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid) total_timeOnSite
,sum(totals.timeOnSite) OVER (PARTITION BY Gigyaid_or_clientid,DeviceSlot) DeviceSlot_total_timeOnSite
,count(distinct visitNumber) OVER (PARTITION BY Gigyaid_or_clientid) total_num_sessions
,count(distinct case when totals.bounces is null then visitNumber END) OVER (PARTITION BY Gigyaid_or_clientid) no_non_bounce_session
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid) as total_hits
, count(hits.hitnumber) OVER (PARTITION BY Gigyaid_or_clientid,DeviceSlot) as DeviceSlot_total_hits
,countif(split(lower(hits.page.pagePath),'?')[SAFE_OFFSET(0)] is not null ) OVER (PARTITION BY Gigyaid_or_clientid) as total_pagepath_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid) as total_page_count
,count(totals.pageviews) OVER (PARTITION BY Gigyaid_or_clientid,DeviceSlot) as DeviceSlot_total_page_count
,
(
(case when hits.type = "PAGE" then (LAG(hits.time) OVER (PARTITION BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date
 ORDER BY Gigyaid_or_clientid,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber ASC)) END)
)
 as preTime1
  ,case when hits.type = "PAGE" then hits.time else null END as currTime1
--,hits.time,hits.type,visitId,visitStartTime,date,hits.hitnumber
,hits.type as hits_type
,fullVisitorId,visitId,visitnumber,visitStartTime,date,hits.hitnumber
FROM entire_data_for_delta_records as ga , unnest(hits) hits

where  DeviceSlot is not null 
),

--recalculating aggregated data from above data block for GA clientid or gigyaid for various hits, total counts, time spend, sessions, etc

B1_DeviceSlot as
(
select distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
,DeviceSlot
,DeviceSlot_total_num_sessions
,DeviceSlot_no_non_bounce_session
,DeviceSlot_total_hits
,total_timeOnSite
,total_num_sessions	
,no_non_bounce_session
,total_hits
,total_pagepath_count
,total_page_count
,DeviceSlot_total_page_count
,DeviceSlot_total_timeOnSite
--,SUM(COALESCE(round(safe_divide((currTime-preTime),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,deviceSlot) as DeviceSlot_total_timeOnSite
,SUM(COALESCE(round(safe_divide((case when hits_type = "PAGE" then currTime-preTime ELSE 0 END),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid,DeviceSlot) as DeviceSlot_Pageview_time
,SUM(COALESCE(round(safe_divide((currTime1-preTime1),1000)),0)) OVER (PARTITION BY Gigyaid_or_clientid) as total_Pageview_time  
from B_DeviceSlot
),

--calculating various GA scores percentage for clientid or gigyaid

inter_DeviceSlot as
(
select 
distinct
final_clientid
,final_gigyaid,
Gigyaid_or_clientid
--,A.Gigyaid_or_clientid_nm
,DeviceSlot
,total_page_count
,DeviceSlot_total_page_count
,round(safe_divide(DeviceSlot_total_page_count,total_page_count)*5,2) as DeviceSlot_total_page_count_score
,DeviceSlot_Pageview_time
,total_Pageview_time
,round(safe_divide(DeviceSlot_Pageview_time,total_Pageview_time)*5,2) as DeviceSlot_Pageview_time_score
,DeviceSlot_total_timeOnSite
,total_timeOnSite
,round(safe_divide(DeviceSlot_total_timeOnSite,total_timeOnSite)*5,2) as DeviceSlot_total_timeOnSite_score
,DeviceSlot_no_non_bounce_session
,DeviceSlot_total_num_sessions
,round(safe_divide(DeviceSlot_no_non_bounce_session,DeviceSlot_total_num_sessions)*5,2) as DeviceSlot_no_non_bounce_session_score
,DeviceSlot_total_num_sessions as DeviceSlot_total_num_visits
,total_num_sessions as total_num_visits
,round(safe_divide(DeviceSlot_no_non_bounce_session,total_num_sessions)*5,2) as DeviceSlot_total_num_visits_score
,DeviceSlot_total_hits
,total_hits
,round(safe_divide(DeviceSlot_total_hits,total_hits)*5,2) as DeviceSlot_total_hits_score
from B1_DeviceSlot
)
,

--calculating final score percentage for clientid or gigyaid by combining GA and SFMC data for Deviceslot

final_DeviceSlot as
(

select distinct
COALESCE(final_clientid,sfmc_fc.sfmc_clientid) as final_clientid
,COALESCE(final_gigyaid,sfmc_fc.SubscriberKey) as final_gigyaid,
COALESCE(Gigyaid_or_clientid,sfmc_fc.SubscriberKey) as Gigyaid_or_clientid
--,Gigyaid_or_clientid_nm
,COALESCE(DeviceSlot,sfmc_fc.lastopen_DeviceSlot) as DEVICE_SLOT
,DeviceSlot_total_page_count_score
,DeviceSlot_Pageview_time_score
,DeviceSlot_total_timeOnSite_score
,DeviceSlot_no_non_bounce_session_score
,DeviceSlot_total_num_visits_score
,DeviceSlot_total_hits_score
,SFMC_Device_Score
,round(safe_divide(
(
COALESCE(DeviceSlot_total_page_count_score,0) +
COALESCE(DeviceSlot_Pageview_time_score,0) + 
COALESCE(DeviceSlot_total_timeOnSite_score,0) + 
COALESCE(DeviceSlot_no_non_bounce_session_score,0) + 
COALESCE(DeviceSlot_total_num_visits_score,0) + 
COALESCE(DeviceSlot_total_hits_score,0) +
COALESCE(SFMC_Device_Score,0)
),(6+COALESCE(if(SFMC_Device_Score is null,0,null),1))),2)
as DEVICE_SCORE
from inter_DeviceSlot as inter
full join sfmc_fc 
on COALESCE(inter.Gigyaid_or_clientid,inter.final_gigyaid)=sfmc_fc.SubscriberKey
 and inter.deviceSlot=sfmc_fc.lastopen_deviceSlot
)

select distinct
final_clientid as CLIENTID
,final_gigyaid as GIGYAID
,"Huggies" as BRAND
,"UK" as COUNTRY_CODE
,"EMEA" as REGION
,"BCC" as SECTOR
,DEVICE_SLOT
,DEVICE_SCORE
,CURRENT_DATETIME() AS INSERT_DTM
,CURRENT_DATETIME() AS UPDATE_DTM
from final_DeviceSlot
where DEVICE_SLOT is not null
) Y
ON COALESCE(X.GIGYAID,'A') = COALESCE(Y.GIGYAID,'A') AND COALESCE(X.CLIENTID,'A') = COALESCE(Y.CLIENTID,'A') AND X.BRAND = Y.BRAND AND X.COUNTRY_CODE = Y.COUNTRY_CODE AND X.REGION = Y.REGION AND X.SECTOR = Y.SECTOR AND  X.DEVICE_SLOT = Y.DEVICE_SLOT
WHEN MATCHED THEN
UPDATE SET 
 X.DEVICE_SCORE = Y.DEVICE_SCORE
,X.UPDATE_DTM = Y.UPDATE_DTM
WHEN NOT MATCHED THEN
INSERT (
CLIENTID
,GIGYAID
,BRAND
,COUNTRY_CODE
,REGION
,SECTOR
,DEVICE_SLOT
,DEVICE_SCORE
,INSERT_DTM
,UPDATE_DTM
) VALUES 
(
Y.CLIENTID
,Y.GIGYAID
,Y.BRAND
,Y.COUNTRY_CODE
,Y.REGION
,Y.SECTOR
,Y.DEVICE_SLOT
,Y.DEVICE_SCORE
,Y.INSERT_DTM
,Y.UPDATE_DTM
)