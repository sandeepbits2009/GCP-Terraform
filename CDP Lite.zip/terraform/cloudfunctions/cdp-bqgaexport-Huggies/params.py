# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the 'License');
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an 'AS IS' BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# ------------------------------------------------------------------

# GA Details
GA_ACCOUNT_ID = "116546868"   # requierd for DI only
GA_PROPERTY_ID = "UA-116546868-139"   # required for both DI and MP
GA_DATASET_ID = "SKBp5bsyR5qQGdh4QxgAGw"   # required for DI only
GA_IMPORT_METHOD = "di"   # "di" - Data Import or "mp" - Measurement Protocol

# GA measurement protocol hit details. Add any additional fields which are
# the same for all hits here.
GA_MP_STANDARD_HIT_DETAILS = {
    # mandatory fields below. Do not remove.
    "v": 1, # MP API version
    "tid": GA_PROPERTY_ID,  # ga property id - same as above
    "t": "",  #  hit type
    # optional fields below:
    "ni": 1,   # non interaction hit: 1 or 0,
    "ec": "",  # event category
    "ea": "",  #  event action
    "el": "",  # event label
    "ds": "",  # data source
    "ua": "modem",  # user agent override
}


# BigQuery Query Details - BQML query or normal BQ Query possible
# Ensure that the BQ result headers resemble the data import schema in SELECT
# E.g. If data import schema looks like  - ga:dimension32, ga:dimension1, etc.
# BQ result headers should like SELECT X AS ga_dimension32, Y AS ga_dimension1
BQ_QUERY = """
                     SELECT 
clientID	  as  	ga_dimension1	,
Time_of_Day_1	  as  	ga_dimension14	,
Time_of_Day_2	  as  	ga_dimension15	,
Time_of_Day_3	  as  	ga_dimension16	,
Weekday_vs_weekend	  as  	ga_dimension17	,
CROSS_DEVICE_A_B	  as  	ga_dimension18	,
Media_source_and_Medium_1	  as  	ga_dimension19	,
Media_source_and_Medium_2	  as  	ga_dimension20	,
Media_source_and_Medium_3	  as  	ga_dimension21	,
Product_Affinity_1	  as  	ga_dimension22	,
Product_Affinity_2	  as  	ga_dimension23	,
Product_Affinity_3	  as  	ga_dimension24	,
Product_Category_Affinity	  as  	ga_dimension25	,
Content_Category_Affinity_1	  as  	ga_dimension26	,
Content_Category_Affinity_2	  as  	ga_dimension27	,
Content_Category_Affinity_3	  as  	ga_dimension28	,
Content_Theme_Affinity	  as  	ga_dimension29	,
PRODUCT_AFFINITY_CONTENT_AFFINITY_CONSUMPTION_COUNT	  as  	ga_dimension30	,
BUY_NOW_REGISTRATION_NEWSLETTER_SUBSCRIPTION_COUNT	  as  	ga_dimension31	,
ACTIVE_FOR_LAST_MONTH_COUNT	  as  	ga_dimension32	,
EMAIL_INTERACTION_SCORE_COUNT	  as  	ga_dimension33	,
PAGE_VIEWS_SCORE_COUNT	  as  	ga_dimension34	,
DERIVED_ATTRIBUTES_A1_A2_A3_A4_A5	  as  	ga_dimension35	,
CROSS_BRAND	  as  	ga_dimension36	,
AGG_HVA_SCORE	  as  	ga_dimension37	,
DAYS_SINCE_LAST_HVA	  as  	ga_dimension38	,
OPT_IN	  as  	ga_dimension39	,
ENGAGED_vs_CONSUMER	  as  	ga_dimension40,	
case when trim(CROSS_BRAND_PRODUCT_1) = '' then null else CROSS_BRAND_PRODUCT_1 end as ga_dimension41,
case when trim(CROSS_BRAND_PRODUCT_2) = '' then null else CROSS_BRAND_PRODUCT_2 end as ga_dimension42
from 
kc_viz_ucv_UK.vw_KCC_GA_HUGGIES_UK
  
                     """

# -------------------------------------------------------------------
# Comment for testing Terraform deployment.
# Options for logging & error monitoring
# LOGGING: Create BQ Table for logs with schema as follows -
# time TIMESTAMP, status STRING, error ERROR
ENABLE_BQ_LOGGING = False
# ERROR MONITORING: Sign up for the free Sendgrid API.
ENABLE_SENDGRID_EMAIL_REPORTING = False


# (OPTIONAL) Workflow Logging - BQ details, if enabled
GCP_PROJECT_ID = "prod-ucv-reporting"
BQ_DATASET_NAME = "kc_viz_ucv_UK"
BQ_TABLE_NAME = "vw_KCC_GA_HUGGIES_UK_LOG"


# (OPTIONAL) Email Reporting - Sendgrid details, if enabled
SENDGRID_API_KEY = ""
TO_EMAIL = ""

# -------------------------------------------------------------------

# (OPTIONAL) Email Reporting - Additional Parameters
FROM_EMAIL = "workflow@example.com"
SUBJECT = "FAILED: Audience Upload to GA"
HTML_CONTENT = """
               <p>
               Hi WorkflowUser, <br>
               Your BQML Custom Audience Upload has failed- <br>
               Time: {0} UTC <br>
               Reason: {1}
               </p>
               """
