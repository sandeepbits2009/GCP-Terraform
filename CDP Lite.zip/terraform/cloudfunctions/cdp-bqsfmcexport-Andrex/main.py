from google.cloud import bigquery
from google.cloud import storage
from google.cloud import secretmanager
from datetime import date
import os
import paramiko

def _get_sftp_password():
    sec_client = secretmanager.SecretManagerServiceClient()
    #sec_name = os.environ.get('password_secret')
    sec_name = "projects/425529755727/secrets/kcucv-fc-sftp-password/versions/latest"
    response = sec_client.access_secret_version(name=sec_name)
    sftp_password = response.payload.data.decode("UTF-8")
    return sftp_password


def _connect_post_sftp(file_name, local_path):
    # Paramiko client configuration
    #hostname=os.environ.get('hostname')
    hostname = "ftp.s7.exacttarget.com"
    Port= 22
    #username = os.environ.get('username')
    username = "7328661"
    password = _get_sftp_password()

    # Open a transport
    transport = paramiko.Transport((hostname, Port))
    # Connect to SFTP
    transport.connect(
        None,
        username,
        password
    )
    sftp = paramiko.SFTPClient.from_transport(transport)
    # Upload
    upload_dir = "/Import/CDP_ Lite_UK_Inbound/Andrex/"+file_name
    sftp.put(local_path, upload_dir)
    # Close
    if sftp: sftp.close()
    if transport: transport.close()

def export_to_gcs(data, context):

    file_name= "KCC_SFMC_ANDREX_UK_" + str(date.today()) + ".csv"
    dataset_id = "kc_viz_ucv_UK"
    table_id = "KCC_SFMC_ANDREX_UK"
    #Bigquery
    bq_client = bigquery.Client()
    project = bq_client.project
    #bucket_name = os.environ.get('gcs_bucket_name')
    bucket_name = "sfmc_output_andrex"
    dataset_ref = bigquery.DatasetReference(project, dataset_id)
    table_ref = dataset_ref.table(table_id)
    destination_uri = "gs://{}/{}".format(bucket_name, file_name)

    sql = """create or replace table kc_viz_ucv_UK.KCC_SFMC_ANDREX_UK as
                (
                    Select * from kc_viz_ucv_UK.vw_KCC_SFMC_ANDREX_UK
                );
          """
    query_job = bq_client.query(sql)
    query_job.result()  # Waits for statement to finish
    print("Data loaded to table")

    #extract data to gcs
    extract_job= bq_client.extract_table(
        table_ref,
        destination_uri
    )
    extract_job.result()
    
    #download file from GCS
    local_path = "/tmp/"+file_name
    
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob(file_name)
    blob.download_to_filename(local_path)



    #Send file to SFTP
    _connect_post_sftp(file_name,local_path)
    #remove the file from tmp
    ## Used this approach as this function gets invoked only from PubSub Notification
    os.remove(local_path)

    ##drop BQ table
    query = """drop table kc_viz_ucv_UK.KCC_SFMC_ANDREX_UK;"""
    query_dropjob = bq_client.query(query)
    query_dropjob.result()  # Waits for statement to finish
    print("Table Dropped")