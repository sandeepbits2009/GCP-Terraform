import sys
import pytest
from google.cloud import bigquery
from google.oauth2 import service_account
import constant

@pytest.fixture()
def name(pytestconfig):
    return pytestconfig.getoption("key_path")

def test_drynites_chnlgrp(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select distinct  upper(trim(channelGrouping))  as channelGrouping FROM `181049556.ga_sessions_*` where _TABLE_SUFFIX <= FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) order by 1 """
    query2 = """ select distinct  upper(trim(channel_Grouping)) as channelGrouping from `kc_emeareporting.channel_grouping_f` where BRAND= 'Drynites' order by 1  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2


def test_drynites_sessions(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)   
    query1 = """ select SUM(totals.visits) AS SESSIONS FROM  `181049556.ga_sessions_*` where _TABLE_SUFFIX <= FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY))  """
    query2 = """ SELECT sum(SESSIONS) AS SESSIONS FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Drynites'  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_drynites_bounces(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select  COUNT(DISTINCT 
                CASE WHEN totals.bounces = 1 THEN CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))
                    ELSE  NULL
                END
                ) AS BOUNCES FROM  `181049556.ga_sessions_*` where _TABLE_SUFFIX <=  FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) 
            """
    query2 = """ SELECT sum(BOUNCES) as BOUNCES FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Drynites'  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_drynites_sessionduration(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select SUM(totals.timeOnSite) AS SESSIONDURATION FROM  `181049556.ga_sessions_*` where _TABLE_SUFFIX <=  FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) """
    query2 = """ SELECT sum( SESSIONDURATION) AS SESSIONDURATION FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Drynites'   """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_andrex_chnlgrp(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select distinct  upper(trim(channelGrouping))  as channelGrouping FROM `185006019.ga_sessions_*` where _TABLE_SUFFIX <= FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) order by 1 """
    query2 = """ select distinct  upper(trim(channel_Grouping)) as channelGrouping from `kc_emeareporting.channel_grouping_f` where BRAND= 'Andrex' order by 1  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_andrex_sessions(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select SUM(totals.visits) AS SESSIONS FROM  `185006019.ga_sessions_*` where _TABLE_SUFFIX <= FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY))  """
    query2 = """ SELECT sum(SESSIONS) AS SESSIONS FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Andrex'  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_andrex_bounces(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select  COUNT(DISTINCT 
                CASE WHEN totals.bounces = 1 THEN CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))
                    ELSE  NULL
                END
                ) AS BOUNCES FROM  `185006019.ga_sessions_*` where _TABLE_SUFFIX <=  FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) 
            """
    query2 = """ SELECT sum(BOUNCES) as BOUNCES FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Andrex'  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_andrex_sessionduration(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select SUM(totals.timeOnSite) AS SESSIONDURATION FROM  `185006019.ga_sessions_*` where _TABLE_SUFFIX <=  FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) """
    query2 = """ SELECT sum( SESSIONDURATION) AS SESSIONDURATION FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Andrex'   """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_kleenex_chnlgrp(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select distinct  upper(trim(channelGrouping))  as channelGrouping FROM `183942593.ga_sessions_*` where _TABLE_SUFFIX <= FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) order by 1 """
    query2 = """ select distinct  upper(trim(channel_Grouping)) as channelGrouping from `kc_emeareporting.channel_grouping_f` where BRAND= 'Kleenex' order by 1  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_kleenex_sessions(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select SUM(totals.visits) AS SESSIONS FROM  `183942593.ga_sessions_*` where _TABLE_SUFFIX <= FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY))  """
    query2 = """ SELECT sum(SESSIONS) AS SESSIONS FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Kleenex'  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_kleenex_bounces(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select  COUNT(DISTINCT 
                CASE WHEN totals.bounces = 1 THEN CONCAT(fullVisitorId, CAST(visitStartTime AS STRING))
                    ELSE  NULL
                END
                ) AS BOUNCES FROM  `183942593.ga_sessions_*` where _TABLE_SUFFIX <=  FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) 
            """
    query2 = """ SELECT sum(BOUNCES) as BOUNCES FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Kleenex'  """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2

def test_kleenex_sessionduration(pytestconfig):
    """
    Test that channel_groups match
    """
    credentials = service_account.Credentials.from_service_account_file(
        pytestconfig.getoption('key_path'), scopes=[constant.SCOPE],)
    client = bigquery.Client(credentials=credentials, project=credentials.project_id,)
    query1 = """ select SUM(totals.timeOnSite) AS SESSIONDURATION FROM  `183942593.ga_sessions_*` where _TABLE_SUFFIX <=  FORMAT_DATE("%Y%m%d", DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)) """
    query2 = """ SELECT sum( SESSIONDURATION) AS SESSIONDURATION FROM `kc_emeareporting.channel_grouping_f` where BRAND= 'Kleenex'   """ 
    query_job1 =  client.query(query1)
    query_job2 =  client.query(query2)
    res1 = list(query_job1)
    res2 = list(query_job2)
    assert res1, res2