#!/usr/bin/python
'''
Script to Start/Monitor the pipeline in datafusion instance. It uses CDAP API's to perform the actions . 
StartPipeline - Code will start the pipeline and based on the result , it returns the value
MonitorPipeline - Code will continously monitor the pipeline for the "COMPLETED" status and until that it goes into  loop and 
check the status . It wait for one minutes before querying the results. If the status comes as "FAILED" .Script will
terminate with the failed status

Parameters are required and need to be passed as positional ones

accessKey - Accesskey to connect with the datafusion instance in gcp
pipelineName - Pipeline name to start or monitor in instance
Instanceendpoint - Instance URL to make the api requests
Action - Valid values [StartPipeline,MonitorPipeline]

Example to run : 
Monitor pipeline:

.\Pipeline_utilities.py "accesskey" "DataFusionQuickstart" "https://kc-datafusion-basic-dev-test-dot-usc1.datafusion.googleusercontent.com" "MonitorPipeline"

'''
import requests 
import json
import os
import sys
from time import sleep , gmtime, strftime
from datetime import datetime

#Email Function
# Push Log stamp to Bigquery table

def logPush(accessKey,query):
     print(query)
     projectId = 'gcp-platform-administration'
     url = "https://bigquery.googleapis.com/bigquery/v2/projects/gcp-platform-administration/queries"
     headers = {"Authorization" : "Bearer" + " " + accessKey}
     body = {   "kind": "bigquery#queryResponse",
                "query": query,
                "useLegacySql": "false"
                }
     try:
         
        response = requests.post(url , data=json.dumps(body), headers=headers)
        print (str(response.content))
        print("!! Log Push completed!!")
     except requests.exceptions.RequestException as e: 
        raise SystemExit(e)
        
         

     
     #print(response)    
    

# SEND EMAIL
def sendEmail(email_list):
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase 
    from email import encoders

    
    #Import Template from Jinja
    from jinja2 import Template
    

    
    senderMail = 'senderemail@kcc.com'

    smtpserver = smtplib.SMTP("mailhost.kcc.com")
  
    
    message = MIMEMultipart()
    message['From'] = senderMail
    message['To'] =  "receipients@kcc.com"
    message['Subject'] =  'Test Data Fusion Pipeline Alert!'

    # Email body
    if len(email_list) != 0:
        htmlBody = '''
        <html>
        <head>
        </head>
        <body>
        <h4>Hi,</h4>
        <p>Below is the status of Data Fusion Pipeline alert.</p>
        '''
        
        #i = 0
        dataTask = {}
        for element in email_list:
           
            dataTask["pipeLineName"] = element['Pipeline_Name']
            dataTask["runID"] = element['Run_ID']
            dataTask["execTime"] = element['Execution_Time']
            dataTask["status"] = element['Status']
            dataTask["log"] = element['Logs']
        
            template = '''
                <p><strong>Data Fusion Pipeline Details: </strong>{{ i }}</p>
                <ul>
                <li>Pipeline Name: <i>{{ pipeLineName }}</i></li>
                <li>Run ID: <i>{{ runID }}</i></li>
                <li>Execution Time: <i>{{ execTime }}</i></li>
                <li>Status: <i>{{ status }}</i></li>
                <li>Message: <i>{{ log }}</i></li>
                </ul>
            '''
            # Jinja template
            j2_template = Template(template)
            rendered_html = j2_template.render(dataTask)
            htmlBody += str(rendered_html)

        htmlBody += '''
        <a href="https://console.cloud.google.com/data-fusion/locations/-/instances">Go to Console</a>
        <br>
        <br>
        <h4>Thanks,</h4>
        <p>DevOps Team</p>
        </body>
        </html>
        '''
        
        mail_content = htmlBody
        message.attach(MIMEText(mail_content, 'html'))

        mail_body =  message.as_string()
        smtpserver.sendmail(senderMail, message['To'].split(","), mail_body) 
        smtpserver.close()

        

#Code to Start and Monitor Pipeline
#------------------------

accessKey = sys.argv[1]
pipelineName = sys.argv[2]
instanceEndpoint = sys.argv[3]
env  = sys.argv[4]
projectID = sys.argv[5]
action = sys.argv[6]

#print("PipelineName" + ":" + pipelineName)
#print("Instanceendpoint" + ":" + instanceEndpoint)
#print("Action to perform" + ":" + action)

Start_time = None
End_time = None
Execution_time = None
log_result = None
Mail_res = []
log_message = ""
script_invoketime = strftime("%Y-%m-%d %H:%M:%S", gmtime())

if action == "StartPipeline":
    try:
        pipelineNamewithenv = env + "_" + pipelineName
        fileName = "./pipelineconfiguration/" + pipelineName + "/" +  pipelineNamewithenv + ".json"
        url = instanceEndpoint + "/api/v3/namespaces/default/apps/" + pipelineName + "/workflows/DataPipelineWorkflow/start"
        headers = {"Authorization" : "Bearer" + " " + accessKey}
        print("Starting the pipeline" + " " + pipelineName)
        if os.path.exists(fileName) == True:
            print("Runtime arguements passed to the pipeline")
            contents = open(fileName, 'rb').read()
            response = requests.post(url , data=contents , headers=headers)
        else:
            print("No Runtime arguements passed to the pipeline")
            response = requests.post(url ,  headers=headers)
        
        if response.text == "":
            print("Succesfully started the pipeline" + ":" + pipelineName)
        else:
            raise Exception("Unable to start the pipeline . Please check the below error")
            print(response.text)            
    except requests.exceptions.RequestException as e: 
         raise SystemExit(e)
     
if action == "MonitorPipeline":
    while True:
     try:
        sleep(30)
        print("Monitoring the pipeline" + pipelineName + "Started" )
        url = instanceEndpoint + "/api/v3/namespaces/default/apps/" + pipelineName + "/workflows/DataPipelineWorkflow/runs"
        headers = {"Authorization" : "Bearer" + " " + accessKey}
        response = requests.get(url , headers=headers)
        getrecentjob = response.json()
        latestjob = getrecentjob[0]
        
        #print(latestjob)
        
        status = latestjob.get('status')
        
        #print ("Current status of the pipeline" + " " + status)
        
        run_id = latestjob.get('runid')
        
        #print("Run ID --> "+ run_id)
        
        #Calculate Execution time of the pipeline
        if status == "COMPLETED":
            print("Pipeline run completed succesfully" + pipelineName)
            url = instanceEndpoint + "/api/v3/namespaces/default/apps/" + pipelineName + "/workflows/DataPipelineWorkflow/runs?status=completed&limit=1"
            headers = {"Authorization" : "Bearer" + " " + accessKey}
            response = requests.get(url , headers=headers)
            getrecentjob = response.json()
            test_res=getrecentjob[0]
            start = test_res.get('start')
            end = test_res.get('end')
            
            Start_time = datetime.fromtimestamp(start)
            End_time = datetime.fromtimestamp(end)
            
            Execution_time = End_time - Start_time
            
            '''
            Get the workflow logs of the pipeline.
            The output of the following HTTP method is, by default, formatted as HTML-embeddable text. In order to filter the logs the output has been formatted as JSON by adding a suffix &format=json.
            '''
            url = instanceEndpoint + "/api/v3/namespaces/default/apps/" + pipelineName + "/workflows/DataPipelineWorkflow/runs/" + str(run_id) + "/logs?start="+ str(start) +"&stop="+ str(end) + "&format=json"
            headers = {"Authorization" : "Bearer" + " " + accessKey} 
            response = requests.get(url , headers=headers)
            
            log_result = response.json()    
            
            #Capture the INFO level logs
            for item in log_result:
                if item['log']['logLevel'] == "INFO":
                    log_message += item['log']['message'] + " //> "         #"//>" has been used to identify a newline

            query = "INSERT INTO CloudDataFusion_Pipeline_Info.pipeline_info (Project_ID,Pipeline_Name,Run_ID,Start_Time,End_Time,Execution_Time,Pipeline_Status,Logs,Script_Start_Time) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','Executed sucessfully','{7}');".format(projectID,pipelineName,run_id,Start_time,End_time,Execution_time,status,script_invoketime)
            
            print("Executing Ingestion")
            print(pipelineName, "/n", str(Execution_time), "/n", run_id, "/n", status, "/n", str(Start_time), "/n", str(End_time), "/n", projectID)
            
            logPush(accessKey,query)
           
            Mail_res.append(
            {
                "Pipeline_Name" : pipelineName,
                "Run_ID" : run_id,
                "Execution_Time" : str(Execution_time),
                "Status" : status,
                "Logs" : log_message,
                "starttime" : Start_time,
                "End_time" : End_time
            })
            
            
            #sendEmail(Mail_res, project_Ids)
            
            #sendEmail(Mail_res)

            break
        elif status == "FAILED":
            #Calculate Execution time of the pipeline
            url = instanceEndpoint + "/api/v3/namespaces/default/apps/" + pipelineName + "/workflows/DataPipelineWorkflow/runs?status=failed&limit=1"
            headers = {"Authorization" : "Bearer" + " " + accessKey}
            response = requests.get(url , headers=headers)
            getrecentjob = response.json()
            test_res=getrecentjob[0]
            start = test_res.get('start')
            end = test_res.get('end')
            
            Start_time = datetime.fromtimestamp(start)
            End_time = datetime.fromtimestamp(end)
            
            Execution_time = End_time - Start_time
            
            '''
            Get the workflow logs of the pipeline.
            The output of the following HTTP method is, by default, formatted as HTML-embeddable text. In order to filter the logs the output has been formatted as JSON by adding a suffix &format=json.
            '''
            url = instanceEndpoint + "/api/v3/namespaces/default/apps/" + pipelineName + "/workflows/DataPipelineWorkflow/runs/" + str(run_id) +"/logs?start="+ str(start) +"&stop="+ str(end) + "&format=json"
            headers = {"Authorization" : "Bearer" + " " + accessKey} 
            response = requests.get(url , headers=headers)
            
            log_result = response.json()
            
            #Capture the ERROR level logs
            for item in log_result:
                if item['log']['logLevel'] == "ERROR":
                    log_message += item['log']['message'] + " //> "         #"//>" has been used to identify a newline

            #Construct query for logpush
            
            query = "INSERT INTO CloudDataFusion_Pipeline_Info.pipeline_info (Project_ID,Pipeline_Name,Run_ID,Start_Time,End_Time,Execution_Time,Pipeline_Status,Logs,Script_Start_Time) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}');".format(projectID,pipelineName,run_id,Start_time,End_time,Execution_time,status,log_message,script_invoketime)
            
            #print(Executing Ingestion!!)

            logPush(projectID,query)
            
            #send an alert mail
            
            
            Mail_res.append(
            {
                "Pipeline_Name" : pipelineName,
                "Run_ID" : run_id,
                "Execution_Time" : str(Execution_time),
                "Status" : status,
                "Logs" : log_message   
            })
            
            
            #sendEmail(Mail_res, project_Ids)
            
           # sendEmail(Mail_res)
            break

        else:
            sleep(60)
                    
     except requests.exceptions.RequestException as e: 
        raise SystemExit(e)
            
        

